from scipy.optimize import minimize
import numpy as np
from joblib import Parallel, delayed
from expected_return import exp_return
from variance import var_portfolio
from volatility import volatility

def minimize_func(mean_return, cov_var, esg_scores, esg_threshold, target_returns, guess):

    def esg_constraint(x):
        esg_product = np.dot(x, esg_scores)
        return esg_product - esg_threshold

    weight_list = []

    # Define a function to be executed in parallel
    def optimize_portfolio(target_return):
        obj_func = lambda x: np.sqrt(np.dot(x.T, np.dot(cov_var, x)))
        constraints = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1},
                    {'type': 'ineq', 'fun': lambda x: np.dot(mean_return, x) - target_return - 0.0001},
                    {'type': 'ineq', 'fun': lambda x: target_return + 0.0001 - np.dot(mean_return, x)},
                    {'type': 'ineq', 'fun': esg_constraint}]

        res1 = minimize(obj_func, x0=guess, method='SLSQP', options={'disp': False, 'maxiter' : 1000}, constraints=constraints)
        #if np.sum(res1.x) > 0.997 and np.sum(res1.x) < 1.01:
         #   weight_list.append(res1.x)
        if np.sum(res1.x) > 0.997 and np.sum(res1.x) < 1.01:
            return res1.x

    # Parallelize the optimization process
    n_jobs = -1  # Use all available CPU cores
    results = Parallel(n_jobs=n_jobs)(delayed(optimize_portfolio)(target_return) for target_return in target_returns)

    # Filter out any portfolios with zero weights
    weight_list = [r for r in results if np.sum(r) > 0.997 and np.sum(r) < 1.01]
    weight_list = np.array(weight_list)

    esg_portfolio_returns = exp_return(weight_list, mean_return)
    esg_portfolio_var = var_portfolio(weight_list, cov_var)
    esg_portfolio_vol = volatility(esg_portfolio_var)
    esg_investor_wa = weight_list@esg_scores

    return weight_list, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa