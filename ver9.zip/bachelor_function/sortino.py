import numpy as np
from variance import var_portfolio
from volatility import volatility
from expected_return import exp_return
def sortino(risk_free_rate, mean_return, covar, weights, er, esg_weights, esg_er, esg_scores, e_scores, s_scores, g_scores):
    #First we find those weights with a negative return
    w_negative_returns = weights[er < 0]
    #Afterwards we calculate the downside risk - thus, the volatility of those weights with a negative return - TRADITIONAL INVESTOR
    down_side_variance = var_portfolio(w_negative_returns, covar)
    down_side_risk = volatility(down_side_variance)

    esg_er = np.flip(esg_er)

    #DOWNSIDE RISK FOR THE ESG SENSITIVE INVESTOR
    w_esg_negative_returns = esg_weights[esg_er < 0]
    down_side_variance_esg = var_portfolio(w_esg_negative_returns, covar)
    down_side_risk_esg = volatility(down_side_variance_esg)


    #Expected return of - traditional investor
    mean_expected_return = er.mean()

    mean_expected_return_esg = esg_er.mean()

    #Now we can compute the sortino ratio
    sortino_ratio = -(mean_expected_return - risk_free_rate) / down_side_risk
    sortino_ratio_esg = -(mean_expected_return_esg - risk_free_rate) / down_side_risk_esg

    w_sortino = weights[sortino_ratio.argmin()]
    w_sortino_esg = esg_weights[sortino_ratio_esg.argmin()]

    #Calculating the point of the optimal sortino point - traditional investor
    sortino_exp_return = w_sortino@mean_return
    sortino_variance = w_sortino@covar@w_sortino
    sortino_vol = np.sqrt(sortino_variance)

    #Calculating the point of the optimal sortino point - ESG investor
    sortino_exp_return_esg = w_sortino_esg@mean_return
    sortino_variance_esg = w_sortino_esg@covar@w_sortino_esg
    sortino_vol_esg = np.sqrt(sortino_variance_esg)

    #Optimal Sortino Ratio - traditional investor
    max_sortino_index = np.argmax(sortino_ratio)
    optimal_sortino_ratio = sortino_ratio[max_sortino_index]


    #Optimal Sortino Ratio - ESG investor
    max_sortino_index_esg = np.argmax(sortino_ratio_esg)
    optimal_sortino_ratio_esg = sortino_ratio_esg[max_sortino_index_esg]

    return sortino_ratio, w_sortino, optimal_sortino_ratio, sortino_exp_return, sortino_vol, sortino_ratio_esg, w_sortino_esg, optimal_sortino_ratio_esg, sortino_exp_return_esg, sortino_vol_esg
