import numpy as np
def sharpe_ratio(risk_free_rate, mean_return, cov_var, weights, er, vol, weights_esg, er_esg, vol_esg, esg_score, e_score, s_score, g_score):
    """Function that the SR and ESG SR

  Parameters
  ----------
    risk_free_rate : float
        a float that refers to the rate of return an investor expects to earn on a zero risk asset    
  
    mean_return : Numpy Array
        Numpy array of mean returns for each stock

    cov_var : Pandas Dataframe
        Covariance-variance matrix for the stocks
    
    weights : Numpy Array
        the optimal portfolio weights for the traditional investor

    er : Numpy Array
        Expected return for each of the optimal portfolios for the traditional investor

    vol : Numpy Array
        Optimal portfolios volatility for the traditional investor

    weights_esg : Numpy Array
        Optimal portfolio weights for the responsible investor

    er_esg : Numpy Array
        Expected return for each optimal portfolio for the responisble investor

    er_vol : Numpy Array
        the optimal portfolios volatility for the responsible investor

    esg_score : Numpy Array
        an array consiting of each optimal portfolios Weighted Average ESG score
        Will be used to find the Max ESG SR


  

  Returns
  ------
    Tuple : Numpy Arrays
        Returns the Max SR, and its weights, expected return, volatility and WA ESG score.
        Returns the Max ESG SR, and its weights, expected return, volatility and WA ESG score.
  """

    
    sr = (er - risk_free_rate) / vol

    max_sr_index = np.argmax(sr)
    optimal_sharpe_ratio = sr[max_sr_index]


    sr_esg =   (er_esg - risk_free_rate) / vol_esg 



    max_sr_esg_index = np.argmax(sr_esg)
    optimal_sharpe_ratio_esg = sr_esg[max_sr_esg_index]




    #Computing the weights for the SR and ESG SR
    w_sr = weights[sr.argmax()]
    w_sr_esg = weights_esg[sr_esg.argmax()]





    sr_esg_score = np.dot(w_sr, esg_score)
    sr_e_score = np.dot(w_sr, e_score)
    sr_s_score = np.dot(w_sr, s_score)
    sr_g_score = np.dot(w_sr, g_score)


    sr_esg_esg_score = np.dot(w_sr_esg, esg_score)
    sr_esg_e_score = np.dot(w_sr_esg, e_score)
    sr_esg_s_score = np.dot(w_sr_esg, s_score)
    sr_esg_g_score = np.dot(w_sr_esg, g_score)

    #Computing the expected return for the SR and ESG SR
    sr_er = w_sr@mean_return
    sr_er_esg = w_sr_esg@mean_return


    #Computing the volatility for the ST and ESG SR
    vol_sr = np.sqrt(w_sr@cov_var@w_sr)
    vol_sr_esg = np.sqrt(w_sr_esg@cov_var@w_sr_esg)

    return sr, optimal_sharpe_ratio, w_sr, sr_er, vol_sr, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, sr_esg, optimal_sharpe_ratio_esg, w_sr_esg, sr_er_esg, vol_sr_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score
    