def filter_esg_stocks(df, score_type, threshold=None):
    valid_score_type = ['ESG', 'Environmental', 'Social', 'Governance']
    if score_type not in valid_score_type:
        raise ValueError("Invalid score type. Please choose from ESG, Enviromental, Social or Governance")

    # Filter dataframe based on threshol
    if threshold is not None:
        filtered = df[df[score_type][score_type + ' Score'] >= threshold]

    return filtered