import numpy as np
def w3_rolling(weight1,weight2,alpha):
  """Function that finds all the optimal weights of the efficient frontier

  Parameters
    ----------
  weight1 : list
    A list with the optimal weights of the first portfolio

  weight2 : list
    A list with the optimal weights of the second portfolio

  alpha : list
    A list with values that ranges from -x to x

  Returns
  -------
  weight3 : Tuple
    Returns a numpy array, which holds all the optimal portfolios for the efficient frontier, and a list of expected returns and volatilities for each portfolio
        
  """

  weight3 = []
  for i in alpha:
    weight3.append(i*weight1 + (1-i)*weight2)
  weight3 = np.array(weight3)
  return weight3