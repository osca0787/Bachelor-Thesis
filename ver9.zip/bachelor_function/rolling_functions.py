import numpy as np
from rolling_cov_re import rolling_er_cov
from ones import vector_ones
from mvp import mvp_func
from weights_mvp import mvp_weights
from alpha import alpha
from two_fund_rolling import w3_rolling
from expected_return import exp_return
from variance import var_portfolio
from volatility import volatility
from global_mvp import global_mvp
from max_sr import sharpe_ratio
from esg_investor_weights import minimize_func


def rolling_ef(log_returns, windows, r_f, esg_scores, e_scores, s_scores, g_scores, threshold):

    ret_mean_rolling, cov_rolling, inv_cov_rolling = rolling_er_cov(log_returns, windows)
    vector_one = vector_ones(log_returns.columns)
    def mvp_func_rolling(inv_covs, mean_returns, vec_ones):
        list_a = []
        list_b = []
        list_c = []
        list_d = []
        for i in range(len(inv_covs)):
            inv_cov = inv_covs[i]
            mean_return = mean_returns[i]

            a = np.array(np.dot(np.dot(mean_return.T, inv_cov), vec_ones))
            b = np.array(np.dot(np.dot(mean_return.T, inv_cov), mean_return))
            c = np.array(np.dot(np.dot(vec_ones, inv_cov), vec_ones))
            d = np.array(b*c - a**2)
            list_a.append(a)
            list_b.append(b)
            list_c.append(c)
            list_d.append(d)
        return (list_a, list_b, list_c, list_d)
    
    list_a, list_b, list_c, list_d = mvp_func_rolling(inv_cov_rolling, ret_mean_rolling, vector_one)

    w1_list = []
    w2_list = []

    list_ef_weights = []
    list_exp_return = []
    list_variance = []
    list_volatility = []
    list_wa_esg_score = []
    list_wa_e_score = []
    list_wa_s_score = []
    list_wa_g_score = []

    list_mvp_weights = []
    list_mvp_exp_return = []
    list_mvp_volatility = []
    list_mvp_esg = []

    list_esg_ef_weights = []
    list_target_returns = []

    list_esg_exp_return = []
    list_esg_variance = []
    list_esg_volatility = []
    list_esg_esg_score = []
    list_esg_e_score = []
    list_esg_s_score = []
    list_esg_g_score = []


    list_sr = []
    list_sr_opt = []
    list_sr_esg = []
    list_sr_esg_opt = []
    list_sr_w = []
    list_sr_w_esg = []
    list_sr_er = []
    list_sr_esg_er = []
    list_sr_vol = []
    list_sr_esg_vol = []
    list_sr_score = []
    list_sr_e_score = []
    list_sr_s_score = []
    list_sr_g_score = []
    list_sr_esg_score = []
    list_sr_esg_e_score = []
    list_sr_esg_s_score = []
    list_sr_esg_g_score = []

    for i in range(len(cov_rolling)):
        

        w1, w2 = mvp_weights(list_a[i], list_b[i], list_c[i], list_d[i], inv_cov_rolling[i], vector_one, ret_mean_rolling[i], 0.10, 0.28)
        w1_list.append(w1)
        w2_list.append(w2)

        #Finding the optimal weights for the traditional investor for each rolling window
        ef_weights = w3_rolling(w1_list[i], w2_list[i], alpha([-1]))
        list_ef_weights.append(ef_weights)

        #Calculating the expected return for each optimal portfolio for every rolling window - traditional investor
        list_exp_return.append(list_ef_weights[i]@ret_mean_rolling[i])

        #Variance for each optimal portfolio in every rolling window - traditional investor
        port_variance = var_portfolio(list_ef_weights[i], cov_rolling[i])
        list_variance.append(port_variance)

        #Volatility for optimal portfolios for each window - traditional investor
        port_vol = volatility(list_variance[i])
        list_volatility.append(port_vol)

        #Weighted average ESG score for every portfolio in each rolling window - traditional investor
        wa_esg_score = list_ef_weights[i] @ esg_scores
        list_wa_esg_score.append(wa_esg_score)

        wa_e_score = list_ef_weights[i]@e_scores
        list_wa_e_score.append(wa_e_score)

        wa_s_score = list_ef_weights[i]@s_scores
        list_wa_s_score.append(wa_s_score)

        wa_g_score = list_ef_weights[i]@g_scores
        list_wa_g_score.append(wa_g_score)

        #Minimum Variance Portfolio in each rolling window - traditional investor
        mvp_w, mvp_er, mvp_vol, mvp_esg = global_mvp(list_ef_weights[i], list_volatility[i], ret_mean_rolling[i], cov_rolling[i], esg_scores)
        list_mvp_weights.append(mvp_w)
        list_mvp_exp_return.append(mvp_er)
        list_mvp_volatility.append(mvp_vol)
        list_mvp_esg.append(mvp_esg)


        #Finding target returns for each rolling window
        target_returns = np.arange(-0.4, list_exp_return[i].max(), 0.0004).tolist()
        list_target_returns.append(target_returns)
        #Calculating the optimal weights for each rolling window - ESG sensitive investor
        esg_investor_weights, returns_esg, vol_esg, investor_esg_score = minimize_func(ret_mean_rolling[i], cov_rolling[i], esg_scores, 0.85, list_target_returns[i], list_mvp_weights[i])
        list_esg_ef_weights.append(esg_investor_weights)

        #Calculating the expected return for each portfolio for every rolling window - ESG sensistive investor
        #esg_expected_return = exp_return(list_esg_ef_weights[i], ret_mean_rolling[i])
        list_esg_exp_return.append(returns_esg)

        list_esg_volatility.append(vol_esg)

        list_esg_esg_score.append(investor_esg_score)
        list_esg_e_score.append(list_esg_ef_weights[i]@e_scores)
        list_esg_s_score.append(list_esg_ef_weights[i]@s_scores)
        list_esg_g_score.append(list_esg_ef_weights[i]@g_scores)


        sr, sr_opt, sr_w, sr_er, sr_vol, sr_score, sr_e_score, sr_s_score, sr_g_score, sr_esg, sr_esg_opt, sr_w_esg, sr_er_esg, sr_vol_esg, sr_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score = sharpe_ratio(r_f, ret_mean_rolling[i], cov_rolling[i], list_ef_weights[i], list_exp_return[i], list_volatility[i], list_esg_ef_weights[i], list_esg_exp_return[i], list_esg_volatility[i], esg_scores, e_scores, s_scores, g_scores)
        list_sr.append(sr)
        list_sr_opt.append(sr_opt)
        list_sr_w.append(sr_w)
        list_sr_er.append(sr_er)
        list_sr_vol.append(sr_vol)
        list_sr_score.append(sr_score)
        list_sr_e_score.append(sr_e_score)
        list_sr_s_score.append(sr_s_score)
        list_sr_g_score.append(sr_g_score)
        list_sr_esg.append(sr_esg)
        list_sr_esg_opt.append(sr_esg_opt)
        list_sr_w_esg.append(sr_w_esg)
        list_sr_esg_er.append(sr_er_esg)
        list_sr_esg_vol.append(sr_vol_esg)
        list_sr_esg_score.append(sr_esg_score)
        list_sr_esg_e_score.append(sr_esg_e_score)
        list_sr_esg_s_score.append(sr_esg_s_score)
        list_sr_esg_g_score.append(sr_esg_g_score)
        


    return ret_mean_rolling, cov_rolling, list_ef_weights, list_exp_return, list_volatility, wa_esg_score, list_wa_e_score, list_wa_s_score, list_wa_g_score, list_mvp_weights, list_mvp_exp_return, list_mvp_volatility, list_mvp_esg, list_esg_ef_weights, list_target_returns, list_esg_exp_return, list_esg_variance, list_esg_volatility, list_esg_esg_score, list_esg_e_score, list_esg_s_score, list_esg_g_score, list_sr, list_sr_opt, list_sr_esg, list_sr_esg_opt, list_sr_w, list_sr_w_esg, list_sr_er, list_sr_esg_er, list_sr_vol, list_sr_esg_vol, list_sr_score, list_sr_e_score, list_sr_s_score, list_sr_g_score, list_sr_esg_score, list_sr_esg_e_score, list_sr_esg_s_score, list_sr_esg_g_score 


    
