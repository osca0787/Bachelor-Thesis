import numpy as np
def volatility(variance):
    """Function that computes the volatility of a portfolio

  Parameters
  ----------
  variance : Numpy Array
      A numpy array of each portfolios variance

  Returns
  ------
    variance_list : list
        Returns a numpy array of each portfolios volatility 
    """

    #deriving the volatility by taking the square root of the variance
    vol = np.sqrt(variance)
    return vol.tolist()
