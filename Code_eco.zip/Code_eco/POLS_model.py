import pandas as pd
import numpy as np
import plotly
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import plotly.figure_factory as ff
from plotly.subplots import make_subplots
import ipywidgets as widgets
from IPython.display import display
import yfinance as yf
import dash
from dash import dcc
from dash import html


import statsmodels.api as sm
import statsmodels.formula.api as smf
from linearmodels.panel import compare
from linearmodels import RandomEffects
from linearmodels import PanelOLS
from linearmodels import RandomEffects
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

import seaborn as sns

import math


def POLS_reg(df, summary:True):
    
    #setting up variables
    y_pols = df['Return']
    # X_pols_e = df[['E_Score']]
    # X_pols_s = df[['S_Score']]
    # X_pols_g = df[['G_Score']]
    X_pols_all = df[['E_Score', 'S_Score', 'G_Score']]
    
    
    # X_pols_e = sm.add_constant(X_pols_e)
    # X_pols_s = sm.add_constant(X_pols_s)
    # X_pols_g = sm.add_constant(X_pols_g)
    X_pols_all = sm.add_constant(X_pols_all)



    # pols_ret_e = sm.OLS(y_pols, X_pols_e).fit()
    # pols_ret_s = sm.OLS(y_pols, X_pols_s).fit()
    # pols_ret_g = sm.OLS(y_pols, X_pols_g).fit()
    pols_ret_all = sm.OLS(y_pols, X_pols_all).fit()
    
    if summary == True:
        return pols_ret_all.summary()
    else:
        return pols_ret_all