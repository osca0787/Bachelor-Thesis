import pandas as pd
import numpy as np
        

def cov_matrix(stocks):
    # Extract the data
    labels = stocks.columns
    X = stocks.values
    # Extract the number of rows and columns
    N, M = stocks.shape

    # Calculate the covariance matrix
    cov = np.zeros((M, M))
    for i in range(M):

        # Mean of column "i"
        mean_i = np.sum(X[:, i]) / N

        for j in range(M):

            # Mean of column "j"
            mean_j = np.sum(X[:, j]) / N

            # Covariance between column "i" and column "j"
            cov[i, j] = np.sum((X[:, i] - mean_i) * (X[:, j] - mean_j)) / (N - 1)
        cov_df = pd.DataFrame(cov, index=labels)
        cov_df.columns = labels
    return cov_df