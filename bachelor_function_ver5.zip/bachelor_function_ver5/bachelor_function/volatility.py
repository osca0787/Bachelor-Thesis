import numpy as np
def volatility(variance):
    vol = np.sqrt(variance)
    return vol.tolist()
