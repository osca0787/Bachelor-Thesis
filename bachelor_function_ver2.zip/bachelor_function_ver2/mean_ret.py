import numpy as np

def mean_return(stocks):
    price = stocks.values

    N, M = stocks.shape

    mean_re = np.zeros(M)

    for i in range(N):
        mean_re += price[i] / N
    #mean_re_df = pd.DataFrame(mean_re, index=labels, )
    return mean_re

