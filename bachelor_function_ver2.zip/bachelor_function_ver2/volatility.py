import numpy as np
def volatility(variance):
    return np.sqrt(variance)