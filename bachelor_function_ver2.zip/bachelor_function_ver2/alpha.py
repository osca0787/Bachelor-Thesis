def alpha(emp):
    for i in range(1000):
        #emp.append(round(emp[i]+ 0.002, 3))
        emp.append(emp[i]+ 1/100)
    return emp
