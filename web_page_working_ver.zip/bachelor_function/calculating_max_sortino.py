from scipy.optimize import minimize
import numpy as np
import pandas as pd
def calculate_sortino_ratio(returns : pd.DataFrame, risk_free_rate : float, labels : list, guess : np.ndarray, mean_ret : np.ndarray, covar : np.ndarray, esg_score : np.ndarray, e_scores : np.ndarray, s_scores : np.ndarray, g_scores : np.ndarray):
    """Function that calculates the optimal Sortino Ratio and calculates its weights, Expected return, volatility and ESG, E, S and G scores

    Parameters
    ----------

    returns : Pandas DataFrame
        A Dataframe containing the logarithmic returns for each stock

    risk_free_rate : float
        a float that refers to the rate of return an investor expects to earn on a zero risk asset    
  
    labels : Numpy Array
        used to set the bounds fot each weight in the portfolio

    guess : Numpy Array
        an array consiting of portfolio weights, that serves as a intial guess
  
    mean_ret : Numpy Array
        Numpy array of mean returns for each stock

    cov_var : Pandas Dataframe
        Covariance-variance matrix for the stocks

    esg_score : Numpy Array
        an array consiting of each stocks ESG score

    e_score : Numpy Array
        an array consiting of each stocks E score

    s_score : Numpy Array
        an array consiting of each stocks S score

    g_score : Numpy Array
        an array consiting of each stocks G score
    

    Returns
    ------
        Tuple
        Returns the Max Sortino Ratio, its weights, expected return, volatility and WA ESG, E, S and G score.
        """    

    if not  all(isinstance(i, (np.ndarray)) for i in (mean_ret, covar, esg_score, e_scores, s_scores, g_scores, guess)) or not isinstance(returns, pd.DataFrame) or not isinstance(labels, list) or not isinstance(risk_free_rate, float):
            raise TypeError("Input must correct data types")
        
    else:

            if mean_ret.size == 0 or covar.size == 0 or esg_score.size == 0 or e_scores.size == 0 or s_scores.size == 0 or g_scores.size == 0 or guess.size == 0 or len(labels) == 0 or returns.empty:
                raise ValueError("One or more of the input parameters are empty")


            else:

                #Defining helper function to calculate the sortino ratio
                def sortino_ratio(weights):
                    #Calculating the portfolio return
                    portfolio_return = np.dot(returns.mean(), weights)
                    #Finding the downside returns: negative returns
                    downside_returns = returns[returns<0]
                    downside_risk = np.sqrt(np.mean(np.square(downside_returns)))
                    #Calculating the downside risk
                    sortino_ratio = (portfolio_return - risk_free_rate) / downside_risk
                    return -1*sortino_ratio
                
                #Function to make sure, that the weights sum to one
                def checkSumToOne(x):
                    return np.sum(x)-1


                #Setting the bounds for the weights. Shorting is allowed
                constraintSet = (-1, 1)
                bounds = tuple(constraintSet for asset in range(len(labels)))

                #Defining the constraints of the minimization problem
                constraints = [{'type':'eq', 'fun':checkSumToOne}]

                #Calculating the weights for the optimal Sortino portfolio
                result = minimize(sortino_ratio, guess, method='SLSQP',
                                bounds=bounds, constraints=constraints)
                
                #Obtaining the optimal weights
                optimal_weights = result.x

                #The optimal sortino ratio
                optimal_sortino_ratio = -result.fun

                #Calculating the expected return and volatility
                sortino_exp = optimal_weights@mean_ret
                sortino_vol = np.sqrt(optimal_weights@covar@optimal_weights)

                #Calculating weighted average ESG, E, S and G score for the portfolio
                sortino_score = optimal_weights@esg_score
                sortino_e_score = optimal_weights@e_scores
                sortino_s_score = optimal_weights@s_scores
                sortino_g_score = optimal_weights@g_scores





                return optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score
