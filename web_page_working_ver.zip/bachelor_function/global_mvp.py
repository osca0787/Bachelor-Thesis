import numpy as np
def global_mvp(weight : np.ndarray, volatility : list, mean_return : np.ndarray, cov_matrix : np.ndarray, esg_score : np.ndarray, e_scores : np.ndarray, s_scores : np.ndarray, g_scores : np.ndarray):

    """Function that computes the global minimum variance portfolio

  Parameters
  ----------
    weight : Numpy Array
        A numpy array of portfolio weights
    
    volatility : Numpy Array
        A numpy array of each portfolios volatility

    mean_return : Numpy Array
        A numpy array containing each stocks mean return

    cov_matrix : Numpy Array
        A Pandas Dataframe, which contains the covariance-variance matrix


  Returns
  ------
    mvp_w : Numpy Array
        Returns a numpy array containing the weights of the global minimum variance portfolio
    
    mvp_return : float
        Returns the expected return of the global minimum variance portfolio

    mvp_vol : float
        Returns the volatility of the global minimum variance portfolio
    """
    if not  all(isinstance(i, (np.ndarray)) for i in (weight, mean_return, cov_matrix, esg_score, esg_score, e_scores, s_scores, g_scores) ) or not isinstance(volatility, list):
            raise TypeError("Input must correct data types")
        
    else:

            if weight.size == 0 or len(volatility) == 0 or mean_return.size == 0 or cov_matrix.size == 0 or esg_score.size == 0 or esg_score.size == 0 or e_scores.size == 0 or s_scores.size == 0 or g_scores.size == 0:
                raise ValueError("One or more of the input parameters are empty")


            else:

                #Transforming input into the correct data type
                weight = np.array(weight)
                volatility = np.array(volatility)


                #Minimizing the volatility of the weights to find the global minimum variance portfolio
                mvp_w = weight[volatility.argmin()]

                #Calculating the expected return of the MVP
                mvp_return = mvp_w@mean_return


                #Calculting the volatility of the MVP
                mvp_vol = np.sqrt(mvp_w @ cov_matrix @ mvp_w.T)

                #WA ESG of the MVP
                mvp_esg_score = np.dot(mvp_w, esg_score)
                mvp_e_score = np.dot(mvp_w, e_scores)
                mvp_s_score = np.dot(mvp_w, s_scores)
                mvp_g_score = np.dot(mvp_w, g_scores)


                return (mvp_w, mvp_return, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score)