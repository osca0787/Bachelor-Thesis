import dash
from dash import html, dcc
import dash_bootstrap_components as dbc
from dash.dependencies import Output, Input, State

import sys
sys.path.insert(0, r'/Users/oscaraugustinus/Desktop/bachelor_function')

import dash
from dash import callback
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input, State
import plotly.graph_objs as go
import pandas as pd
from filter_sp500_stocks import filter_esg_stocks
import dash_bootstrap_components as dbc
import plotly.subplots as sp
from portfolio_analysis import calculate_fundemental_functions
from portfolio_analysis import calculate_esg_investor_types
from portfolio_analysis import plot_efficient_frontiers
import plotly.express as px

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.SOLAR])

dataframe = pd.read_excel('data_norm.xlsx', header=[0, 1], index_col=0)

# Define the styles for hiding and showing the plots
log_return_style = {"display": "none"}
histogram_style = {"display": "none"}
portfolio_box_style = {"display": "none"}
efficient_frontier_style = {"display" : "none"}

# Defining the layout of the app
app.layout = html.Div(
    [
        # Add a centered title
        html.H1("JO Sustainable Investment", style={"textAlign": "center"}),
        html.H2("Step 1: Build your portfolio", style={"textAlign" : "left"}),
        html.H6("Choose stocks from the dropdown menu and generate your portfolio", style={"textAlign" : "left"}),
        dbc.Row(
            [
                dbc.Col(
                    [
                        # Defining the ESG threshold widget, such that the user can filter stocks based on an ESG threshold
                        html.H3('ESG Threshold:'),
                        html.Div(id='esg-threshold-value', className="mb-3"),
                        dcc.Slider(
                            id='esg-threshold-slider',
                            className="mb-4",
                            min=dataframe['ESG']['ESG Score'].min(),
                            max=dataframe['ESG']['ESG Score'].max(),
                            step=0.1,
                            value=dataframe['ESG']['ESG Score'].min(),
                            marks={dataframe['ESG']['ESG Score'].min(): str(dataframe['ESG']['ESG Score'].min()),
                                   dataframe['ESG']['ESG Score'].max(): str(dataframe['ESG']['ESG Score'].max())}
                        )
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center'
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        dcc.Dropdown(
                            # Creating the dropdown menu, from which the user can choose between stocks to add to a portfolio
                            id='stock-dropdown',
                            # Looping through each ticker in the dataframe's index to display in the dropdown menu
                            options=[{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()],
                            multi=True,
                            placeholder='Please select stocks for your portfolio'
                        )
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center'
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        html.Button('View Your Portfolio', id='submit-button', n_clicks=0, className="mr-2"),
                        html.Button('Reset Portfolio', id='reset-button', n_clicks=0, className="mt-2"),
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center',
            className="mt-3"
        ),

        dbc.Row(
            [
                dbc.Col(id='portfolio-output', className="mt-4")
            ],
            style=portfolio_box_style
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                    dcc.Graph(
                                        id='log-return-plot',
                                        style={'backgroundColor': 'rgb(28, 32, 47)'}
                                    ),
                                    width=6,
                                    id='log-return-col',
                                    style=log_return_style  # Initially hide the plot
                                ),
                                dbc.Col(
                                    dcc.Graph(
                                        id='histogram-plot',
                                        style={'backgroundColor': 'rgb(28, 32, 47)'}
                                    ),
                                    width=6,
                                    id='histogram-col',
                                    style=histogram_style  # Initially hide the plot
                                ),
                            ],
                            justify='center',
                            className="mt-3"
                        )
                    ]
                )
            ]
        ),
        dbc.Row(
            [ 
                dbc.Col(
                    [html.H2("Step 2: compute the efficient frontiers"),
                        dbc.Row(
                            [
                                dbc.Col(
                                    [
                                        html.H4('Risk-Free Rate:'),
                                        dbc.Input(
                                            id='risk-free-rate-input',
                                            type='number',
                                            placeholder='Enter risk-free rate',
                                            min=0,
                                            step=0.01,
                                            style={'width': '200px'}
                                        )
                                    ],
                                    className='mb-3'
                                ),
                                dbc.Col(
                                    [
                                        html.H4('ESG Threshold:'),
                                        dbc.Input(
                                            id='threshold-input',
                                            type='number',
                                            placeholder='Enter threshold',
                                            min=0,
                                            step=0.01,
                                            style={'width': '200px'}
                                        )
                                    ],
                                    className='mb-3'
                                ),
                                dbc.Col(
                                    [
                                        html.Button('Generate', id='generate-button', n_clicks=0, className="mr-2")
                                    ]
                                )
                            ],
                            justify='center',
                            className="mt-3"
                        )
                    ],
                    width=6,
                    className="mt-3",
                    id="portfolio-box",
                    style=portfolio_box_style
                )
            ],
            justify='center'
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                    dcc.Graph(
                                        id='ef-plot',
                                        style={'backgroundColor': 'rgb(28, 32, 47)'}
                                    ),
                                    width=6,
                                    id='ef-return-col',
                                    style=efficient_frontier_style  # Initially hide the plot
                                ),
                                dbc.Col(
                                    dcc.Graph(
                                        id='ef-plot2',
                                        style={'backgroundColor': 'rgb(28, 32, 47)'}
                                    ),
                                    width=6,
                                    id='ef-return-col2',
                                    style=efficient_frontier_style  # Initially hide the plot
                                ),
                            ],
                            justify='center',
                            className="mt-3"
                        )
                    ]
                )
            ]
        )
    ]
)

# Callback function to update the dropdown menu options, stock dropdown value, and ESG threshold value
@app.callback(
    [
        Output('stock-dropdown', 'options'),
        Output('stock-dropdown', 'value'),
        Output('esg-threshold-value', 'children')
    ],
    [
        Input('esg-threshold-slider', 'value'),
        Input('reset-button', 'n_clicks')
    ],
    [
        State('stock-dropdown', 'value')
    ]
)
def update_portfolio(esg_threshold, reset_clicks, selected_stocks):
    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # Code such that as the user changes the value of the ESG threshold, the dropdown menu is updated with stocks that fulfill the threshold
    if trigger_id == 'esg-threshold-slider':
        # Using the filter_esg_stocks function from the filter_sp500_stocks program
        filtered_df = filter_esg_stocks(dataframe, 'ESG', threshold=esg_threshold)
        # Updating stock options on the dropdown menu
        dropdown_options = [{'label': ticker, 'value': ticker} for ticker in filtered_df.index.tolist()]
        return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    elif trigger_id == 'reset-button':
        # Resetting the whole webpage to default settings if the user clicks on the Reset Portfolio button
        if reset_clicks > 0:
            # Reset the dropdown options to include all tickers
            dropdown_options = [{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()]

            # Reset the selected stocks value to an empty list
            selected_stocks = []

            # Reset the ESG threshold value to the minimum ESG score
            esg_threshold = dataframe['ESG']['ESG Score'].min()

            return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    # If no trigger or invalid trigger, return the initial values
    return dash.no_update, dash.no_update, dash.no_update


@app.callback(
    [
        Output('log-return-plot', 'figure'),
        Output('histogram-plot', 'figure'),
        Output('log-return-col', 'style'),
        Output('histogram-col', 'style'),
        Output('portfolio-box', 'style'),
        Output('ef-plot', 'figure'),
        Output('ef-plot2', 'figure'),
        Output('ef-return-col', 'style'),
        Output('ef-return-col2', 'style')
    ],
    [
        Input('submit-button', 'n_clicks'),
        Input('reset-button', 'n_clicks'),
        Input('generate-button', 'n_clicks'), 
    ],
    [
        State('stock-dropdown', 'value'),
        State('risk-free-rate-input', 'value'),
        State('threshold-input', 'value')
    ]
)



def update_portfolio_output(submit_clicks, reset_clicks, generate_clicks, selected_stocks, risk_free_rate, threshold_value):
    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]


    if trigger_id == 'submit-button':
        if submit_clicks > 0:
            # Create an empty DataFrame to store selected stocks
            portfolio = pd.DataFrame(columns=dataframe.columns)

            # Add selected stocks to the portfolio DataFrame
            for stock in selected_stocks:
                portfolio = pd.concat([portfolio, dataframe.loc[dataframe.index == stock]])

            # Call the first function from the backend file portfolio_analysis
            # This function will calculate all the base metrics and the ESG insensitive investor
            logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks = calculate_fundemental_functions(
                portfolio)

            logarithmic_return.index = pd.to_datetime(logarithmic_return.index)

            # Create a line plot for each ticker
            log_return_fig = go.Figure()

            for column in logarithmic_return.columns:
                log_return_fig.add_trace(go.Scatter(
                    x=logarithmic_return.index,
                    y=logarithmic_return[column],
                    mode='lines',
                    name=column
                ))

            log_return_fig.update_layout(
                title='Logarithmic Returns',
                xaxis_title='Date',
                yaxis_title='Logarithmic Return',
                legend=dict(orientation="h"),
                hovermode='x unified',
                plot_bgcolor='rgb(28, 32, 47)',
                paper_bgcolor='rgb(28, 32, 47)'
            )

            # Plot the histogram for ESG Scores
            histogram_fig = px.histogram(portfolio, x=portfolio.index, y=portfolio['ESG']['ESG Score'])
            histogram_fig.update_layout(
                title='ESG Scores',
                xaxis_title='Ticker',
                yaxis_title='ESG Score',
                showlegend=False,
                plot_bgcolor='rgb(28, 32, 47)',
                paper_bgcolor='rgb(28, 32, 47)'
            )

            # Show the plots
            log_return_style = {"display": "block"}
            histogram_style = {"display": "block"}
            portfolio_output_style = {"display": "block"}
            efficient_frontier_style = {"display" : "none"}

            return log_return_fig, histogram_fig, log_return_style, histogram_style, portfolio_output_style, dash.no_update, dash.no_update, efficient_frontier_style, efficient_frontier_style

    #efficient_frontier_weights_insensitive = expected_return_insensitive = volatility_insensitive = weighted_average_esg_score_insensitive = sr_t_list = mvp_weight = mvp_er = mvp_vol = mvp_esg_score = mvp_e_score = mvp_s_score = mvp_g_score = sr = w_opt = sharpe_exp = sharpe_vol = sr_esg_score = sr_e_score = sr_s_score = sr_g_score = optimal_weights = optimal_sortino_ratio = sortino_exp = sortino_vol = sortino_score = sortino_e_score = sortino_s_score = sortino_g_score = labels = tickers_list = esg_investor_weights = esg_portfolio_returns = esg_portfolio_vol = esg_investor_wa = sr_esg = w_opt_esg = sharpe_exp_esg = sharpe_vol_esg = sr_esg_esg_score = sr_esg_e_score = sr_esg_s_score = sr_esg_g_score = optimal_weights_esg = optimal_sortino_ratio_esg = sortino_exp_esg = sortino_vol_esg = sortino_score_esg = sortino_e_score_esg = sortino_s_score_esg = sortino_g_score_esg = None



            #return efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, labels, tickers_list, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg
    elif trigger_id == 'generate-button':
            if generate_clicks > 0:
                # Create an empty DataFrame to store selected stocks
                portfolio1 = pd.DataFrame(columns=dataframe.columns)

                # Add selected stocks to the portfolio DataFrame
                for stock in selected_stocks:
                    portfolio1 = pd.concat([portfolio1, dataframe.loc[dataframe.index == stock]])
              
                # Call the first function from the backend file portfolio_analysis
                # This function will calculate all the base metrics and the ESG insensitive investor
                logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks = calculate_fundemental_functions(portfolio1)
                

                efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, labels, tickers_list, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg = calculate_esg_investor_types(portfolio1, logarithmic_return, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, esg_np, e_np, s_np, g_np, risk_free_rate, threshold_value)
                
                plot_efficient_frontiers_with_sharpe, plot_efficient_frontiers_with_sortino = plot_efficient_frontiers(efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg, tickers_list)

    
                efficient_frontier_style = {"display" : "block"}
                return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, plot_efficient_frontiers_with_sharpe, plot_efficient_frontiers_with_sortino, efficient_frontier_style, efficient_frontier_style

    elif trigger_id == 'reset-button':
        if reset_clicks > 0:
            # Hide the plots and reset the portfolio box style
            log_return_style = {"display": "none"}
            histogram_style = {"display": "none"}
            portfolio_output_style = {"display": "none"}
            efficient_frontier_style = {"display" : "none"}

            return dash.no_update, dash.no_update, log_return_style, histogram_style, portfolio_output_style, dash.no_update, dash.no_update, efficient_frontier_style, efficient_frontier_style

            
            
            #return dash.no_update, dash.no_update, log_return_style, histogram_style, portfolio_output_style

    return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

if __name__ == "__main__":
    app.run(debug=False, port = 8059)