import numpy as np
def indicators(vector_one : np.ndarray, inv_cov : np.ndarray, mean_re : np.ndarray, r : np.ndarray, esg_np : np.ndarray):
    delta_1 = ( (mean_re.T@inv_cov@esg_np) * (vector_one.T@inv_cov@vector_one) - (vector_one.T@inv_cov@mean_re) * (vector_one.T@inv_cov@esg_np) ) / ( (vector_one.T@inv_cov@vector_one) * (mean_re.T@inv_cov@mean_re) - (vector_one.T@inv_cov@mean_re)**2 )
    #lambda_0 = ( ((mean_re.T@inv_cov@vector_one) * (esg_np.T@inv_cov@vector_one)) - ((vector_one.T@inv_cov@vector_one) * (esg_np.T@inv_cov@mean_re)) ) /  (( esg_np.T - threshold * vector_one.T) @ inv_cov @ vector_one) 
    mvp_rating = (vector_one.T@inv_cov@esg_np) / (vector_one.T@inv_cov@vector_one)
    #output_str = [
     #   "Variable outputs used from the paper",
      #  "------------------------------------",
       # f'Is delta 1 larger than zero: {delta_1 > 0}',
        #"-------------------------------------",
        #f'The value of delta 1 is: {delta_1}',
        #"-------------------------------------",
        #f"The value of Lambda 0 is: {lambda_0}\n",
        #"--------------------------------------",
        #f"ESG score of the MVP is: {mvp_rating}",
        #"--------------------------------------"
    #]
    return delta_1, mvp_rating