import numpy as np
import pandas as pd
import pandas.testing as pd_testing
from log_return import log_returns
from mean_ret import mean_return
from ones import vector_ones
from mvp import mvp_func
from weights_mvp import mvp_weights
from filter import filter_esg_stocks
from alpha import alpha
from variance import var_portfolio
from fetch_score import get_scores
from expected_return import exp_return
from volatility import volatility
from treynor import calculate_treynor
from covariance import cov_matrix
from global_mvp import global_mvp
from two_fun_theorem import w3
from calculate_CvaR import plot_var_cvar_histogram
from calculating_max_sr import calculate_max_sharpe_ratio
from calculating_max_ESG_sr import calculate_max_ESG_sharpe_ratio
import unittest



class TestSum(unittest.TestCase):

##### TESTS FOR LOG RETURN
    def test_log_returns_empty(self):
        empty_df = pd.DataFrame()
        
        with self.assertRaises(ValueError):
            log_returns(empty_df)

    def test_log_returns(self):
        data_test_log = pd.DataFrame([[4.3, 1.2, 1.4], [3.0, 3.1, 4.5], [5.3, 3.3, 5.1]])
        df_result_log = pd.DataFrame([[-1.2763,  0.0328, -0.4738], [ 0.1542,  0.3727,  0.4353]])
        log_result = log_returns(data_test_log)
        log_r = log_result
        pd.testing.assert_frame_equal(log_r.reset_index(drop=True), df_result_log.reset_index(drop=True))


    def test_type_log(self):
        type_test = np.array([1,2,3])
        with self.assertRaises(TypeError) as context:
            log_returns(type_test)
        self.assertEqual(str(context.exception), "Input must be a DataFrame.")


###### TESTS FOR MEAN RETURNS

    def test_mean_returns_empty(self):
        empty_df = pd.DataFrame()
        
        with self.assertRaises(ValueError):
            mean_return(empty_df)

    def test_mean_returns(self):
        data_test_mean_return = pd.DataFrame([[0.09, 0.1, 0.35], [0.5, 0.3, 0.09], [0.35, 0.5, 0.13]])
        df_result_mean_return = np.array([0.31333333, 0.3, 0.19])
        mean_return_result = mean_return(data_test_mean_return)
        self.assertEqual(mean_return_result.all(), df_result_mean_return.all())

    def test_type_mean_return(self):
        type_test = np.array([1,2,3])
        with self.assertRaises(TypeError) as context:
            mean_return(type_test)
        self.assertEqual(str(context.exception), "Input must be a DataFrame.")


###### TESTS FOR VECTOR ONE
    def test_vector_ones_result(self):
        # Prepare input
        labels = pd.DataFrame({'ticker': ['AAPL', 'GOOGL', 'MSFT']})

        # Expected output
        expected_output = np.array([1, 1, 1])

        # Call the function
        result = vector_ones(labels)

        # Assert the result
        np.testing.assert_array_equal(result, expected_output)

    def test_vector_ones_empty(self):
        labels = pd.DataFrame()
        empty_vector_ones_result = vector_ones(labels)
        self.assertEqual(empty_vector_ones_result, None)


##### TEST FOR mvp_func
    def test_mvp_func_result(self):
        inv_cov = np.array([[2, -1], [-1, 2]])
        mean_return = np.array([0.5, 0.7])
        vec_ones = np.array([1, 1])

        expected_a = 1.2
        expected_b = 0.7799999999999999
        expected_c = 2
        expected_d = 0.11999999999999988

        result_a, result_b, result_c, result_d = mvp_func(inv_cov, mean_return, vec_ones)

        self.assertAlmostEqual(result_a, expected_a, places=15)
        self.assertAlmostEqual(result_b, expected_b, places=15)
        self.assertAlmostEqual(result_c, expected_c, places=15)
        self.assertAlmostEqual(result_d, expected_d, places=15)

    def test_mvp_func_inputs_type(self):
        inv_cov = np.array([[2, -1], [-1, 2]])
        mean_return = np.array([0.5, 0.7])
        vec_ones = np.array([1, 1])

        with self.assertRaises(TypeError):
            mvp_func(inv_cov.tolist(), mean_return, vec_ones)

        with self.assertRaises(TypeError):
            mvp_func(inv_cov, mean_return.tolist(), vec_ones)

        with self.assertRaises(TypeError):
            mvp_func(inv_cov, mean_return, vec_ones.tolist())

    def test_mvp_func_inputs_empty(self):
        inv_cov = np.array([])
        mean_return = np.array([0.5, 0.7])
        vec_ones = np.array([1, 1])

        with self.assertRaises(ValueError):
            mvp_func(inv_cov, mean_return, vec_ones)

        inv_cov = np.array([[2, -1], [-1, 2]])
        mean_return = np.array([])
        vec_ones = np.array([1, 1])

        with self.assertRaises(ValueError):
            mvp_func(inv_cov, mean_return, vec_ones)

        inv_cov = np.array([[2, -1], [-1, 2]])
        mean_return = np.array([0.5, 0.7])
        vec_ones = np.array([])

        with self.assertRaises(ValueError):
            mvp_func(inv_cov, mean_return, vec_ones)


###### TEST FOR WEIGHTS_MVP
    def test_data_mvp_weights_types(self):
            a = 1.0
            b = 2.0
            c = 3.0
            d = 4.0
            inv_cov = pd.DataFrame([[1.0, 2.0], [3.0, 4.0]])
            vec_ones = np.array([1, 1])
            mean_return = np.array([0.1, 0.2])
            exp_return_1 = 0.5
            exp_return_2 = '1.0'

            with self.assertRaises(TypeError):
                mvp_weights(a, b, c, d, inv_cov, vec_ones, mean_return, exp_return_1, exp_return_2)

    def test_empty_mvp_weights_inputs(self):
            a = 1.0
            b = 2.0
            c = 3.0
            d = 4.0
            inv_cov = pd.DataFrame([[1.0, 2.0], [3.0, 4.0]])
            vec_ones = np.array([1, 1])
            mean_return = np.array([])
            exp_return_1 = 0.5
            exp_return_2 = 0.6

            with self.assertRaises(ValueError):
                mvp_weights(a, b, c, d, inv_cov, vec_ones, mean_return, exp_return_1, exp_return_2)


    #def test_empty_mvp_weights_result(self):
     #   a = 2.0
      #  b = 3.1
      #  c = 1.1
      #  d = 4.3
      #  inv_cov = pd.DataFrame([[1.0, 2.0], [3.0, 4.0]])
      #  vec_ones = np.array([1, 1])
      #  mean_return = np.array([2.5, 3.5])
      #  exp_return_1 = 0.2
      #  exp_return_1 = 0.3

#MANGLER AT TESTE, AT DEN REGNER KORREKT

    #UNITTEST FOR EXPECTED RETURN FUNCTION
    def test_expected_returns(self):
            w = np.array([[0.8, 0.1, 0.1], [0.6, 0.2, 0.2], [0.4, 0.4, 0.2]])
            R = np.array([0.3, 0.15, 0.47])
            expected_return_result = np.array([0.302, 0.304, 0.274])
            result = exp_return(w, R)
            self.assertEqual(result.all(), expected_return_result.all())

    def test_expected_returns_empty(self):
            w = np.array([[0.8, 0.1, 0.1], [0.6, 0.2, 0.2], [0.4, 0.4, 0.2]])
            R = np.array([])
            with self.assertRaises(ValueError):
                exp_return(w, R)


    def test_expected_returns_type(self):
        w = np.array([[0.8, 0.1, 0.1], [0.6, 0.2, 0.2], [0.4, 0.4, 0.2]])
        R = [0.1, 0.2]
        with self.assertRaises(TypeError):
            exp_return(w, R)


    #UNITTEST FOR FILTERING STOCKS BASED ON ESG SCORES
    def test_filtered_empty(self):
        empty_df = pd.DataFrame()
        with self.assertRaises(ValueError):
                filter_esg_stocks(empty_df, 'ESG', threshold=0.3)

    def test_filtered_type(self):
        type_df = np.array([[1,2,3], [3,4,5]])
        with self.assertRaises(TypeError):
                filter_esg_stocks(type_df, 'ESG', threshold=0.3)


    #Unittest for SP500 filtering


    #UNITTEST FOR ALPHA FUNCTION
    def test_alpha(self):
        emp = [0.0]
        result = alpha(emp)
        results =  [round(x, 3) for x in result]
        expected = [0.0] + [i / 100 for i in range(1, 601)]
        # print(results)
        # print(expected)
        self.assertEqual(results, expected)
        
    def test_alpha_int(self):
        emp = []
        with self.assertRaises(ValueError):
            alpha(emp)        

    def test_alpha_type(self):
        df_alpha = pd.DataFrame([1,2,3])
        with self.assertRaises(TypeError):
            alpha(df_alpha)
            
    #UNITTEST FOR VARIANCE 
    def test_variance_empty(self):
        weights = np.array([])
        covar_matrix = np.array([])
        with self.assertRaises(ValueError):
            var_portfolio(weights, covar_matrix)
        
    def test_variance_type(self):
        weights = pd.DataFrame([1,2,3])   
        covar_matrix = pd.DataFrame([2,3,6])
        with self.assertRaises(TypeError):
            var_portfolio(weights, covar_matrix) 
        
    def test_variance_correctness(self):
        weight = np.array([[2,5,6], [1,2,3]])
        covar_matrix =   np.array([[1.0, 0.4, 0.1],[0.22, 1.0, 0.3],[0.12, 0.45, 1.0]])
        results = var_portfolio(weight, covar_matrix)
        expected = np.array([96.34, 20.400000000000002])
        self.assertEqual(results.all(), expected.all())

    #UNITTEST FOR VOLATILITY 
    def test_volatility_empty(self):
        variance = np.array([])
        with self.assertRaises(ValueError):
            volatility(variance)
        
    def test_volatility_type(self):
        variance = pd.DataFrame([1,2,3])   
        with self.assertRaises(TypeError):
            volatility(variance) 
        
    def test_volatility_correctness(self):
        variance = np.array([0.6111, 0.333, 0.45])
        results = volatility(variance)
        expected = np.array([0.78172885, 0.57706152, 0.67082039])
        #self.assertAlmostEqual(results, expected.tolist())
        np.testing.assert_allclose(results, expected)

    #UNITTEST FOR FETCH_SCORE
    def test_get_score_empty(self):
        df = pd.DataFrame([])
        with self.assertRaises(ValueError):
            get_scores(df)
        
    def test_get_scores_type(self):
        df = np.array([1,2,3])   
        with self.assertRaises(TypeError):
            get_scores(df) 


    #UNITTEST FOR TREYNOR
    def test_treynor_empty(self):
        lookback_years = 10
        portfolio_returns = pd.DataFrame()
        weights = np.array([0.1, 0.3, 0.6])
        benchmark_returns = pd.DataFrame([[0.3, 0.4, 0.5], [0.4, 0.55, 0.3]])
        risk_free_rate = 0.03
        with self.assertRaises(ValueError):
            calculate_treynor(lookback_years, portfolio_returns, weights, benchmark_returns, risk_free_rate)
    
    def test_treynor_type(self):
        lookback_years = 10.0
        portfolio_returns = np.array([[0.1, 0.3, 0.4], [0.5, 0.1, 0.3]])
        weights = np.array([0.1, 0.3, 0.6])
        benchmark_returns = pd.DataFrame([[0.3, 0.4, 0.5], [0.4, 0.55, 0.3]])
        risk_free_rate = 1
        with self.assertRaises(TypeError):
            calculate_treynor(lookback_years, portfolio_returns, weights, benchmark_returns, risk_free_rate)


    #MISSING TEST FOR CORRECTNESS OF TREYNOR

    #UNIT TEST FOR COVARIANCE FUNCTION

    def test_covariance_empty(self):
        df = pd.DataFrame()
        with self.assertRaises(ValueError):
            cov_matrix(df)

    def test_covariance_type(self):
        array = np.array([1,2,3])
        with self.assertRaises(TypeError):
            cov_matrix(array)

    #UNIT TEST FOR GLOBAL MVP FUNCTION
    def test_global_mvp_empty(self):
        w = np.array([[0.3, 0.5, 0.2], [0.3, 0.3, 0.4]])
        vol = [0.2, 0.25]
        mean_return = np.array([0.3, 0.4])
        cov_matrix = np.array([[0.1, 0.2], [0.3, 0.4]])
        esg_score = np.array([0.35, 0.4])
        e_score = np.array([0.25, 0.13])
        s_score = np.array([0.4, 0.1])
        #g_score = np.array(0.5, 0.7)
        g_score = np.array([])
        with self.assertRaises(ValueError):
            global_mvp(w, vol, mean_return, cov_matrix, esg_score, e_score, s_score, g_score)

    def test_global_mvp_type(self):
        w = np.array([[0.3, 0.5, 0.2], [0.3, 0.3, 0.4]])
        vol = [0.2, 0.25]
        mean_return = np.array([0.3, 0.4])
        cov_matrix = np.array([[0.1, 0.2], [0.2, 0.1]])
        esg_score = np.array([0.35, 0.4])
        e_score = np.array([0.25, 0.13])
        s_score = np.array([0.4, 0.1])
        #g_score = np.array(0.5, 0.7)
        g_score = [0.1, 0.2]
        with self.assertRaises(TypeError):
            global_mvp(w, vol, mean_return, cov_matrix, esg_score, e_score, s_score, g_score)

    def test_global_mvp_correctness(self):
        w = np.array([[0.3, 0.5, 0.2], [0.3, 0.3, 0.4]])
        vol = [0.2, 0.25]
        mean_return = np.array([0.3, 0.2, 0.4])
        cov_matrix = np.array([[0.1, 0.2, 0.4], [0.2, 0.1, 0.4], [0.3,0.01, 0.03]])
        esg_score = np.array([0.35, 0.1, 0.4])
        e_score = np.array([0.25, 0.11, 0.13])
        s_score = np.array([0.4, 0.5, 0.1])
        g_score = np.array([0.1, 0.3, 0.2])

        expected_mvp_w = [0.3, 0.5, 0.2]
        expected_mvp_r = 0.27
        expected_mvp_vol = 0.422137418384
        expected_mvp_esg = 0.235000
        expected_mvp_e = 0.156
        expected_mvp_s = 0.39
        expected_mvp_g = 0.22

        weight, ret, volatil, esg, e, s, g = global_mvp(w, vol, mean_return, cov_matrix, esg_score, e_score, s_score, g_score)
        np.testing.assert_allclose(np.array(expected_mvp_w), np.array(weight))
        self.assertAlmostEqual(expected_mvp_r, ret, places=10)
        self.assertAlmostEqual(expected_mvp_vol, volatil, places=10)
        self.assertAlmostEqual(expected_mvp_esg, esg, places=10)
        self.assertAlmostEqual(expected_mvp_e, e, places=10)
        self.assertAlmostEqual(expected_mvp_s, s, places=10)
        self.assertAlmostEqual(expected_mvp_g, g, places=10)


    #UNITTEST ON TWO_FUND_THEOREM FUNCTION
    def test_tft_empty(self):
        mean_return = np.array([0.2, 0.3])
        cov_matrix = np.array([[0.3, 0.2], [0.2, 0.3]])
        esg_score = np.array([0.35, 0.2])
        alpha = [0.01, 0.03, 0.04]
        w1 = np.array([0.1, 0.2])
        w2 = np.array([])

        with self.assertRaises(ValueError):
            w3(w1, w2, alpha, mean_return, cov_matrix, esg_score)

    def test_tft_type(self):
        mean_return = np.array([0.2, 0.3])
        cov_matrix = np.array([[0.3, 0.2], [0.2, 0.3]])
        esg_score = np.array([0.35, 0.2])
        alpha = np.array([0.01, 0.03, 0.04])
        w1 = np.array([0.1, 0.2])
        w2 = np.array([0.2, 0.15])

        with self.assertRaises(TypeError):
            w3(w1, w2, alpha, mean_return, cov_matrix, esg_score)


    def test_tft_correctness(self):
        mean_return = np.array([0.2, 0.3])
        cov_matrix = np.array([[0.3, 0.2], [0.2, 0.3]])
        esg_score = np.array([0.35, 0.2])
        alpha = [0.01, 0.03, 0.04]
        w1 = np.array([0.1, 0.2])
        w2 = np.array([0.2, 0.15])

        expected_ef_weights = np.array([[0.199, 0.1505], [0.197, 0.1515], [0.196, 0.152]])
        expected_return = np.array([0.08495, 0.08485, 0.0848 ])
        expected_volatility = np.array([0.17508619305, 0.174546770236, 0.17427793893])
        expected_esg_scores = np.array([0.09975, 0.09925, 0.099  ])

        ef_weights, er, vol, esg_s = w3(w1, w2, alpha, mean_return, cov_matrix, esg_score)
        np.testing.assert_allclose(expected_ef_weights, ef_weights)
        np.testing.assert_allclose(expected_return, er)
        np.testing.assert_allclose(expected_volatility, vol)
        np.testing.assert_allclose(expected_esg_scores, esg_s)

    #UNITTEST FOR CALCULATE CVaR
    def test_CVaR_empty(self):
        returns = pd.DataFrame([0.2, 0.3, 0.4])
        alpha = 0.95
        weights = np.array([])
        lookback_days = 100

        with self.assertRaises(ValueError):
            plot_var_cvar_histogram(returns, weights, alpha, lookback_days)

    def test_CVaR_type(self):
        returns = pd.DataFrame([0.2, 0.3, 0.4])
        alpha = 0.95
        weights = [0.3, 0.4, 0.3]
        lookback_days = 100

        with self.assertRaises(TypeError):
            plot_var_cvar_histogram(returns, weights, alpha, lookback_days)


    #UNITTEST FOR CALCULATE MAX SR
    def test_max_sr_empty(self):
        mean_returns = np.array([0.3, 0.4, 0.2])
        cov_var = np.array([[0.3, 0.4, 0.3], [0.4, 0.1, 0.3], [0.3,0.2,0.4]])
        esg_score = np.array([0,14, 0.25, 0.4])
        e_score = np.array([])
        s_score = np.array([])
        g_score = np.array([0.1, 0.3, 0.55])
        guess = np.array([0.3, 0.4, 0.3])
        labels = [0.1, 0.3, 0.3]
        risk_free_rate = 0.3

        with self.assertRaises(ValueError):
            calculate_max_sharpe_ratio(risk_free_rate, mean_returns, cov_var, esg_score, e_score, s_score, g_score, guess, labels)
        
    def test_max_sr_type(self):
        mean_returns = np.array([0.3, 0.4, 0.2])
        cov_var = np.array([[0.3, 0.4, 0.3], [0.4, 0.1, 0.3], [0.3,0.2,0.4]])
        esg_score = np.array([0,14, 0.25, 0.4])
        e_score = np.array([0.1, 0.2, 0.4])
        s_score = [0.3, 0.4, 0.1]
        g_score = np.array([0.1, 0.3, 0.55])
        guess = np.array([0.3, 0.4, 0.3])
        labels = [0.1, 0.3, 0.3]
        risk_free_rate = 0.3

        with self.assertRaises(TypeError):
            calculate_max_sharpe_ratio(risk_free_rate, mean_returns, cov_var, esg_score, e_score, s_score, g_score, guess, labels)
        
    def test_max_sr_sum_to_one(self):
        mean_returns = np.array([0.3, 0.4, 0.2])
        cov_var = np.array([[0.3, 0.4, 0.3], [0.4, 0.1, 0.3], [0.3,0.2,0.4]])
        esg_score = np.array([0.14, 0.25, 0.35])
        e_score = np.array([0.1, 0.2, 0.4])
        s_score = np.array([0.3, 0.4, 0.1])
        g_score = np.array([0.1, 0.3, 0.55])
        guess = np.array([0.3, 0.4, 0.3])
        labels = [0.1, 0.3, 0.3]
        risk_free_rate = 0.3

        sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score = calculate_max_sharpe_ratio(risk_free_rate, mean_returns, cov_var, esg_score, e_score, s_score, g_score, guess, labels)
        self.assertAlmostEqual(1, sum(w_opt), places=3)


    #UNITTEST FOR CALCULATE MAX ESG SR
    def test_max_esg_sr_empty(self):
        mean_returns = np.array([0.3, 0.4, 0.2])
        cov_var = np.array([[0.3, 0.4, 0.3], [0.4, 0.1, 0.3], [0.3,0.2,0.4]])
        esg_score = np.array([0,14, 0.25, 0.4])
        e_score = np.array([])
        s_score = np.array([])
        g_score = np.array([0.1, 0.3, 0.55])
        guess = np.array([0.3, 0.4, 0.3])
        labels = [0.1, 0.3, 0.3]
        risk_free_rate = 0.3
        threshold = 0.03

        with self.assertRaises(ValueError):
            calculate_max_ESG_sharpe_ratio(risk_free_rate, mean_returns, cov_var, esg_score, e_score, s_score, g_score, guess, labels, threshold)
        
    def test_max_esg_sr_type(self):
        mean_returns = np.array([0.3, 0.4, 0.2])
        cov_var = np.array([[0.3, 0.4, 0.3], [0.4, 0.1, 0.3], [0.3,0.2,0.4]])
        esg_score = np.array([0,14, 0.25, 0.4])
        e_score = np.array([0.1, 0.2, 0.4])
        s_score = [0.3, 0.4, 0.1]
        g_score = np.array([0.1, 0.3, 0.55])
        guess = np.array([0.3, 0.4, 0.3])
        labels = [0.1, 0.3, 0.3]
        risk_free_rate = 0.3
        threshold = 0.03

        with self.assertRaises(TypeError):
            calculate_max_ESG_sharpe_ratio(risk_free_rate, mean_returns, cov_var, esg_score, e_score, s_score, g_score, guess, labels, threshold)
        
    def test_max_esg_sr_sum_to_one(self):
        mean_returns = np.array([0.3, 0.4, 0.2])
        cov_var = np.array([[0.3, 0.4, 0.3], [0.4, 0.1, 0.3], [0.3,0.2,0.4]])
        esg_score = np.array([0.14, 0.25, 0.35])
        e_score = np.array([0.1, 0.2, 0.4])
        s_score = np.array([0.3, 0.4, 0.1])
        g_score = np.array([0.1, 0.3, 0.55])
        guess = np.array([0.3, 0.4, 0.3])
        labels = [0.1, 0.3, 0.3]
        risk_free_rate = 0.3
        threshold = 0.03

        sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score = calculate_max_ESG_sharpe_ratio(risk_free_rate, mean_returns, cov_var, esg_score, e_score, s_score, g_score, guess, labels, threshold)
        self.assertAlmostEqual(1, sum(w_opt_esg), places=3)


    def test_max_esg_sr_higher_or_equal_to_threshold(self):
        mean_returns = np.array([0.3, 0.4, 0.2])
        cov_var = np.array([[0.1, 0.1, 0.1], [0.1, 0.1, 0.1], [0.1, 0.1, 0.1]])
        esg_score = np.array([0.14, 0.25, 0.35])
        e_score = np.array([0.1, 0.2, 0.4])
        s_score = np.array([0.3, 0.4, 0.1])
        g_score = np.array([0.1, 0.3, 0.55])
        guess = np.array([0.3, 0.4, 0.3])
        labels = [0.1, 0.3, 0.3]
        risk_free_rate = 0.3
        threshold = 0.03

        sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score = calculate_max_ESG_sharpe_ratio(risk_free_rate, mean_returns, cov_var, esg_score, e_score, s_score, g_score, guess, labels, threshold)
        self.assertGreaterEqual(sr_esg_esg_score, threshold)




        


if __name__ == '__main__':
    unittest.main()


#def test_functions(dataframe):
 #   return log_returns(dataframe)


#test_df = pd.DataFrame()
#test_functions(test_df)
