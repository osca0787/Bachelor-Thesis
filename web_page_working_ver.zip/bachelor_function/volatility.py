import numpy as np
def volatility(variance : np.ndarray):
    """Function that computes the volatility of a portfolio

  Parameters
  ----------
  variance : Numpy Array
      A numpy array of each portfolios variance

  Returns
  ------
    variance_list : list
        Returns a numpy array of each portfolios volatility 
    """
    if not isinstance(variance, np.ndarray):
        raise TypeError("Input must be a numpy array")
    
    else:

        if variance.size == 0:
            raise ValueError('One or more parameters are empty')
        
        else:
            #deriving the volatility by taking the square root of the variance
            vol = np.sqrt(variance)
            return vol.tolist()
