import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input, State
import pandas as pd
from filter_sp500_stocks import filter_esg_stocks

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.SOLAR])

dataframe = pd.read_excel('data_norm.xlsx', header=[0, 1], index_col=0)

# Define the styles for hiding and showing the plots
log_return_style = {"display": "none"}
histogram_style = {"display": "none"}
portfolio_box_style = {"display": "none"}
efficient_frontier_style = {"display" : "none"}

# Defining the layout of the app
app.layout = html.Div(
    [
        # Add a centered title
        html.H1("JO Sustainable Investment", style={"textAlign": "center"}),
        html.H2("Step 1: Build your portfolio", style={"textAlign": "left"}),
        html.H6("Choose stocks from the dropdown menu and generate your portfolio", style={"textAlign": "left"}),
        dbc.Row(
            [
                dbc.Col(
                    [
                        # Defining the ESG threshold widget, such that the user can filter stocks based on an ESG threshold
                        html.H3('ESG Threshold:'),
                        html.Div(id='esg-threshold-value', className="mb-3"),
                        dcc.Slider(
                            id='esg-threshold-slider',
                            className="mb-4",
                            min=dataframe['ESG']['ESG Score'].min(),
                            max=dataframe['ESG']['ESG Score'].max(),
                            step=0.1,
                            value=dataframe['ESG']['ESG Score'].min(),
                            marks={dataframe['ESG']['ESG Score'].min(): str(dataframe['ESG']['ESG Score'].min()),
                                   dataframe['ESG']['ESG Score'].max(): str(dataframe['ESG']['ESG Score'].max())}
                        )
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center'
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        dcc.Dropdown(
                            # Creating the dropdown menu, from which the user can choose between stocks to add to a portfolio
                            id='stock-dropdown',
                            # Looping through each ticker in the dataframe's index to display in the dropdown menu
                            options=[{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()],
                            multi=True,
                            placeholder='Please select stocks for your portfolio'
                        )
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center'
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        html.Button('View Your Portfolio', id='submit-button', n_clicks=0, className="mr-2"),
                        html.Button('Reset Portfolio', id='reset-button', n_clicks=0, className="mt-2"),
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center',
            className="mt-3"
        ),

        dbc.Row(
            [
                dbc.Col(id='portfolio-output', className="mt-4")
            ],
            style=portfolio_box_style
        )
    ]
)

# Callback function to update the dropdown menu options, stock dropdown value, and ESG threshold value
@app.callback(
    [
        Output('stock-dropdown', 'options'),
        Output('stock-dropdown', 'value'),
        Output('esg-threshold-value', 'children')
    ],
    [
        Input('esg-threshold-slider', 'value'),
        Input('reset-button', 'n_clicks')
    ],
    [
        State('stock-dropdown', 'value')
    ]
)
def update_portfolio(esg_threshold, reset_clicks, selected_stocks):
    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # Code such that as the user changes the value of the ESG threshold, the dropdown menu is updated with stocks that fulfill the threshold
    if trigger_id == 'esg-threshold-slider':
        # Using the filter_esg_stocks function from the filter_sp500_stocks program
        filtered_df = filter_esg_stocks(dataframe, 'ESG', threshold=esg_threshold)
        # Updating stock options on the dropdown menu
        dropdown_options = [{'label': ticker, 'value': ticker} for ticker in filtered_df.index.tolist()]
        return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    elif trigger_id == 'reset-button':
        # Resetting the whole webpage to default settings if the user clicks on the Reset Portfolio button
        if reset_clicks > 0:
            # Reset the dropdown options to include all tickers
            dropdown_options = [{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()]

            # Reset the selected stocks value to an empty list
            selected_stocks = []

            # Reset the ESG threshold value to the minimum ESG score
            esg_threshold = dataframe['ESG']['ESG Score'].min()

            return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    # If no trigger or invalid trigger, return the initial values
    return dash.no_update, dash.no_update, dash.no_update


@app.callback(
    Output('portfolio-output', 'data'),
    [Input('submit-button', 'n_clicks')],
    [State('stock-dropdown', 'value')]
)
def return_portfolio_constructed(submit_clicks, selected_stocks):
    if submit_clicks > 0:
        # Create an empty DataFrame to store selected stocks
        portfolio = pd.DataFrame(columns=dataframe.columns)

        # Add selected stocks to the portfolio DataFrame
        for stock in selected_stocks:
            portfolio = pd.concat([portfolio, dataframe.loc[dataframe.index == stock]])

        return portfolio.to_dict('records')

    else:
        return None


if __name__ == "__main__":
    app.run(debug=True, port = 8060)