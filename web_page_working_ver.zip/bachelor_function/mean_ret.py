import numpy as np
import pandas as pd

def mean_return(stocks : pd.DataFrame):
    """Function that computes the mean returns of a list of stocks

    Parameters
    ----------
    Stocks : float
        Pandas Dataframe which contains the logarithmic price of a certain amount of stocks
    

    Returns
    -------
    Pandas Dataframe
        a Numpy Array of the mean returns of each selected stock
    """
    if not isinstance(stocks, pd.DataFrame):
        raise TypeError("Input must be a DataFrame.")
    
    else:

        if stocks.empty:
            raise ValueError("Dataframe is empty")

        else:
            #Getting the values for each of the stocks from the Pandas Dataframe
            price = stocks.values

            #Extracting the shape from the Pandas Dataframe
            N, M = stocks.shape

            #Iniziating the return variable to be a vector of zeroes with shape M
            mean_re = np.zeros(M)

            for i in range(N):
                #Computing the mean return of each stock
                mean_re += price[i] / N
            #mean_re_df = pd.DataFrame(mean_re, index=labels, )
            return mean_re

