import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Define trading strategy
def backtest(data, weights, short_window, long_window):
        #First we calculate the portfolios return

    sum_return = []
    for i in range(len(data)):
            returns = weights@data.iloc[i]
            sum_return.append(returns)
    
    df_return = pd.DataFrame(sum_return)
    df_return = df_return.set_index(data.index)
    df_return.columns = ['return']


    def sma_crossover(data, short_window, long_window):
            signals = pd.DataFrame(index=data.index)
            signals['signal'] = 0
            signals['short_mavg'] = data['return'].rolling(window=short_window, min_periods=1, center=False).mean()
            signals['long_mavg'] = data['return'].rolling(window=long_window, min_periods=1, center=False).mean()
            signals['signal'][short_window:] = np.where(signals['short_mavg'][short_window:] > signals['long_mavg'][short_window:], 1.0, 0.0)
            signals['positions'] = signals['signal'].diff()

            return signals

        # Backtest trading strategy
    signals = sma_crossover(df_return, short_window=50, long_window=200)
    initial_capital = float(100000.0)
    positions = pd.DataFrame(index=signals.index).fillna(0.0)
    positions['return'] = 100 * signals['signal']
    portfolio = positions.multiply(df_return.values, axis=0)
    pos_diff = positions.diff()
    portfolio['holdings'] = (positions.multiply(df_return.values, axis=0)).sum(axis=1)
    portfolio['cash'] = initial_capital - (pos_diff.multiply(df_return.values, axis=0)).sum(axis=1).cumsum()
    portfolio['total'] = portfolio['cash'] + portfolio['holdings']
    portfolio['ret'] = portfolio['total'].pct_change()

    # Compute key performance metrics
    print('Total Return: ', portfolio['ret'][-1])
    print('Average Daily Return: ', portfolio['ret'].mean())
    print('Standard Deviation of Daily Return: ', portfolio['ret'].std())
    print('Maximum Drawdown: ', ((portfolio['total'].cummax() - portfolio['total']) / portfolio['total'].cummax()).max())

    # Visualize backtesting results
    fig = plt.figure(figsize=(12, 8))
    ax1 = fig.add_subplot(111, ylabel='Portfolio value in $')
    portfolio['total'].plot(ax=ax1, lw=2.)
    ax1.plot(portfolio.loc[signals.positions == 1.0].index, portfolio.total[signals.positions == 1.0],
                '^', markersize=10, color='g')
    ax1.plot(portfolio.loc[signals.positions == -1.0].index, portfolio.total[signals.positions == -1.0],
            'v', markersize=10, color='r')
    plt.legend(['Portfolio', 'Buy Signal', 'Sell Signal'])
    return fig