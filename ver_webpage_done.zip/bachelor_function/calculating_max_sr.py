import numpy as np
from scipy.optimize import minimize
from joblib import Parallel, delayed
def calculate_max_sharpe_ratio(risk_free_rate : float, mean_return : np.ndarray, cov_var : np.ndarray, esg_score : np.ndarray, e_score : np.ndarray, s_score : np.ndarray, g_score : np.ndarray, guess : np.ndarray, labels : list):
    """Function that calculates the optimal Sharpe Ratio and calculates its weights, Expected return, volatility and ESG, E, S and G scores

    Parameters
    ----------
    risk_free_rate : float
        a float that refers to the rate of return an investor expects to earn on a zero risk asset    
  
    mean_return : Numpy Array
        Numpy array of mean returns for each stock

    cov_var : Pandas Dataframe
        Covariance-variance matrix for the stocks

    esg_score : Numpy Array
        an array consiting of each stocks ESG score

    e_score : Numpy Array
        an array consiting of each stocks E score

    s_score : Numpy Array
        an array consiting of each stocks S score

    g_score : Numpy Array
        an array consiting of each stocks G score
    
    guess : Numpy Array
        an array consiting of portfolio weights, that serves as a intial guess

    labels : Numpy Array
        used to set the bounds fot each weight in the portfolio



  

    Returns
    ------
        Tuple : Tuple
        Returns the Max ESG SR, its weights, expected return, volatility and WA ESG, E, S and G score.
        """
    

    if not  all(isinstance(i, (np.ndarray)) for i in (mean_return, cov_var, esg_score, e_score, s_score, g_score, guess)) or not isinstance(labels, list) or not isinstance(risk_free_rate, float):
            raise TypeError("Input must correct data types")
        
    else:

            if mean_return.size == 0 or cov_var.size == 0 or mean_return.size == 0 or esg_score.size == 0 or e_score.size == 0 or s_score.size == 0 or g_score.size == 0 or len(labels) == 0:
                raise ValueError("One or more of the input parameters are empty")


            else:

                #Helper function used as a constraint
                def checkSumToOne(w):
                    return np.sum(w)-1

                #We use a minimizer so we create a helper function find the negative sharpe ratio,
                def negativeSR(w):
                    w = np.array(w)
                    V = np.sqrt(w.T @ cov_var @ w)
                    R = np.sum(mean_return * w)
                    SR = R /V
                    return -1*SR
                

                #Setting the bounds for the weights. Shorting is allowed
                constraintSet = (-1,1)
                bounds = tuple(constraintSet for asset in range(len(labels)))


                #Defining the constraints
                constraints = ({'type':'eq', 'fun':checkSumToOne})
                #Calculating the weights of the optimal Sharpe Ratio
                w_opt = minimize(negativeSR, guess, method='SLSQP', bounds=bounds, constraints=constraints).x

                #Calculating the expected return and volatility 
                sharpe_exp = w_opt@mean_return
                sharpe_vol = np.sqrt(w_opt.T@cov_var@w_opt)

                #Computing the optimal Sharpe Ratio
                sr = (sharpe_exp - risk_free_rate) / sharpe_vol

                #Calculating the weighted average ESG score of the portfolio
                sr_esg_score = np.dot(w_opt, esg_score)
                sr_e_score = np.dot(w_opt, e_score)
                sr_s_score = np.dot(w_opt, s_score)
                sr_g_score = np.dot(w_opt, g_score)





                return sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score
