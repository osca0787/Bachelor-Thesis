import numpy as np

def var_portfolio(weights : np.ndarray, covar_matrix : np.ndarray):
    """Function that computes the variance of a portfolio

    Parameters
    ----------
    weights : Numpy Array
        A numpy array of the portfolio's weights

    covar_matrix : Numpy Array
        A numpy array consisting of the stocks' covariance-variance matrix

    Returns
    ------
    variance_list : Numpy Array
        Returns a numpy array of each portfolio's variance 
    """
    if not all(isinstance(x, np.ndarray) for x in (weights, covar_matrix)):
        raise TypeError("Input must be a numpy array.")
    else:
        if weights.size == 0 or covar_matrix.size == 0:
            raise ValueError('One or more parameters are empty')
        else:
            variance_list = []
            for i in range(len(weights)):
                portfolio_variance = np.dot(weights[i].T, np.dot(covar_matrix, weights[i]))
                variance_list.append(portfolio_variance)
            return np.array(variance_list)
