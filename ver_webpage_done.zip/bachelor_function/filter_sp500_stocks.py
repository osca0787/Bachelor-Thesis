import pandas as pd
import numpy as np
def filter_esg_stocks(df : pd.DataFrame, score_type : str, threshold : float):
    valid_score_type = ['ESG', 'Environmental', 'Social', 'Governance']
    valid_score_type = ['ESG', 'Enviromental', 'Social', 'Governance']
    if not isinstance(df, pd.DataFrame):
        raise TypeError("Input must be a Pandas DataFrame")
    else:
        if df.empty:
            raise ValueError("DataFrame is empty")

        else:
            if score_type not in valid_score_type:
                raise ValueError("Invalid score type. Please choose from ESG, Enviromental, Social or Governance")
            else:
                # Filter dataframe based on threshol
                if threshold is not None:
                    filtered = df[df[score_type][score_type + ' Score'] >= threshold]
    return filtered