import dash
from dash import html, dcc
import dash_bootstrap_components as dbc
from dash.dependencies import Output, Input, State

import sys
sys.path.insert(0, r'/Users/oscaraugustinus/Desktop/bachelor_function')

import dash
from dash import callback
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input, State
import plotly.graph_objs as go
import pandas as pd
from filter_sp500_stocks import filter_esg_stocks
import dash_bootstrap_components as dbc
import plotly.subplots as sp
from portfolio_analysis import calculate_fundemental_functions
from portfolio_analysis import calculate_esg_investor_types
from portfolio_analysis import plot_efficient_frontiers
from portfolio_analysis import risk_for_investor_types
from portfolio_analysis import portfolio_performance
from log_return import log_returns
import plotly.express as px
import numpy as np

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.SOLAR])

dataframe = pd.read_excel('data_norm.xlsx', header=[0, 1], index_col=0)
benchmark = pd.read_excel("sp500_bench.xlsx", index_col=0)

# Define the styles for hiding and showing the plots
log_return_style = {"display": "none"}
histogram_style = {"display": "none"}
volatility_chart_style = {"display" : "none"}
correlation_matrix_style = {"display" : "none"}
table_style = {"display" : "none"}
portfolio_box_style = {"display": "none"}
efficient_frontier_style = {"display" : "none"}
ef_plots_dropdown_style = {"display" : "none"}
cvar_box_style = {"display" : "none"}
cvar_plots_style = {"display" : "none"}
cvar_plots2_style = {"display" : "none"}
performance_box_style = {"display" : "none"}
performance_plot_style = {"display" : "none"}
performance_table_style = {"display" : "none"}

# Defining the layout of the app
app.layout = html.Div(
    [
        # Add a centered title
        html.H1("JO Sustainable Investments", style={"textAlign": "center"}),
        html.H2("Step 1: Build your portfolio", style={"textAlign" : "left"}),
        html.H6("Choose stocks from the dropdown menu and generate your portfolio. Filter thorugh the stocks in the dropdown menu by setting an ESG criteria", style={"textAlign" : "left"}),
       dbc.Row(
    [
        dbc.Col(
            [
                html.H3('ESG Threshold:'),
                html.Div(id='esg-threshold-value', className="mb-3"),
                dcc.Slider(
                    id='esg-threshold-slider',
                    className="mb-4",
                    min=dataframe['ESG']['ESG Score'].min(),
                    max=dataframe['ESG']['ESG Score'].max(),
                    step=0.1,
                    value=dataframe['ESG']['ESG Score'].min(),
                    marks={dataframe['ESG']['ESG Score'].min(): str(dataframe['ESG']['ESG Score'].min()),
                           dataframe['ESG']['ESG Score'].max(): str(dataframe['ESG']['ESG Score'].max())}
                ),
                dcc.Dropdown(
                    id='stock-dropdown',
                    options=[{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()],
                    multi=True,
                    placeholder='Please select stocks for your portfolio',
                    searchable=True,
                    search_value='',
                )
            ],
            width=6,
            className="mt-3"
        )
    ],
    justify='center'
),

        dbc.Row(
            [
                dbc.Col(
                    [
                        html.Button('View Your Portfolio', id='submit-button', n_clicks=0, className="mr-2"),
                        html.Button('Reset Portfolio', id='reset-button', n_clicks=0, className="mt-2"),
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center',
            className="mt-3"
        ),

        dbc.Row(
            [
                dbc.Col(id='portfolio-output', className="mt-4")
            ],
            style=portfolio_box_style
        ),

        dbc.Row(
    [
        dbc.Col(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            dcc.Graph(
                                id='log-return-plot',
                                style={'backgroundColor': 'rgb(28, 32, 47)'}
                            ),
                            width=6,
                            id='log-return-col',
                            style=log_return_style  # Initially hide the plot
                        ),
                        dbc.Col(
                            dcc.Graph(
                                id='histogram-plot',
                                style={'backgroundColor': 'rgb(28, 32, 47)'}
                            ),
                            width=6,
                            id='histogram-col',
                            style=histogram_style  # Initially hide the plot
                        ),
                    ],
                    justify='center',
                    className="mt-3"
                )
            ]
        )
    ]
),

dbc.Row(
    [
        dbc.Col(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            dcc.Graph(
                                id='volatility-chart',
                                style={'backgroundColor': 'rgb(28, 32, 47)'}
                            ),
                            width=6,
                            id='volatility-col',
                            style=volatility_chart_style  # Initially hide the plot
                        ),
                        dbc.Col(
                            dcc.Graph(
                                id='correlation-matrix',
                                style={'backgroundColor': 'rgb(28, 32, 47)'}
                            ),
                            width=6,
                            id='correlation-col',
                            style=correlation_matrix_style  # Initially hide the plot
                        ),
                    ],
                    justify='center',
                    className="mt-3"
                )
            ]
        )
    ]
),
dbc.Row(
    [
        dbc.Col(
            [
                html.H2("Step 2: Compute the efficient frontiers", style={"textAlign": "left"}),
                html.H6("In the table above you are provided with information about the trade-off between risk-aversion and ESG score, and the MVP ESG score. Based on this, you are now asked to pick the ESG threshold for each of your portfolios on the efficient frontier. Furthermore, choose a risk free rate and generate your ESG Efficient Froniter. ", style={"textAlign": "left"}),
                dbc.Table(
                    [
                        html.Thead(html.Tr([html.Th("Trade of between risk-aversion and ESG score"), html.Th("Minimum Variance Portfolio ESG score")])),
                        html.Tbody(
                            [
                                html.Tr([html.Td(id='delta1-value'), html.Td(id='mvp-rating-value')])
                            ]
                        ),
                    ],
                    id='portfolio-table',
                    bordered=True,
                    dark=True,
                    striped=True,
                    responsive=True,
                    hover=True,
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.H4('Risk-Free Rate:'),
                                dbc.Input(
                                    id='risk-free-rate-input',
                                    type='number',
                                    placeholder='Enter risk-free rate',
                                    min=0,
                                    step=0.01,
                                    style={'width': '200px'}
                                )
                            ],
                            className='mb-3'
                        ),
                        dbc.Col(
                            [
                                html.H4('ESG Threshold:'),
                                dbc.Input(
                                    id='threshold-input',
                                    type='number',
                                    placeholder='Enter threshold',
                                    min=0,
                                    step=0.01,
                                    style={'width': '200px'}
                                )
                            ],
                            className='mb-3'
                        ),
                        dbc.Col(
                            [
                                html.Button('Generate', id='generate-button', n_clicks=0, className="mr-2")
                            ]
                        )
                    ],
                    justify='center',
                    className="mt-3"
                )
            ],
            width=6,
            className="mt-3",
            id="portfolio-box",
            style=portfolio_box_style

        )
    ],
    justify='center'
),
      dbc.Row(
    [
        dbc.Col(
            dcc.Dropdown(
                id='graph-dropdown',
                options=[
                    {'label': 'Efficient frontiers with Sharpe Ratio', 'value': 'graph1'},
                    {'label': 'Efficient frontiers with Sortino Ratio', 'value': 'graph2'}
                ],
                value='graph1',
                clearable=False,
                multi=False,
                disabled=False,
                placeholder='Please choose a plot',
                style={'width': '1000px'}  # Set the width to match the graph width
            ),
            width=6,
            className="mt-3",
            style={'margin': 'auto'}  # Center the dropdown horizontally
        )
    ],
    justify='center',
    id='dropdown-row',
    style=ef_plots_dropdown_style,
),

dbc.Row(
    [
        dbc.Col(
            dcc.Graph(
                id='ef-plot',
                style={'backgroundColor': 'rgb(28, 32, 47)'}
            ),
            width=6,
            id='ef-return-col',
            style=efficient_frontier_style  # Initially hide the plot
        ),
        dbc.Col(
            dcc.Graph(
                id='ef-plot2',
                style={'backgroundColor': 'rgb(28, 32, 47)'}
            ),
            width=6,
            id='ef-return-col2',
            style=efficient_frontier_style  # Initially hide the plot
        ),
    ],
    justify='center',
    className="mt-3"
),
dbc.Row(
    [
        dbc.Col(
            [
                html.H2("Step 3: Compute the Conditional Value-At-Risk for your ESG Tangency portfolio", style={"textAlign": "left"}),
                html.H6("It is now time to analyze the expected shortfall of your ESG Tangency Portfolio and the Tangency portfolio. Please select a confidence interval and a time-frame for the analysis.", style={"textAlign": "left"}),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.H4('Confidence Interval:'),
                                dbc.Input(
                                    id='confidence-input',
                                    type='number',
                                    placeholder='Enter confidence interval',
                                    min=0,
                                    max=100,
                                    step=0.01,
                                    style={'width': '200px'}
                                )
                            ],
                            className='mb-3'
                        ),
                        dbc.Col(
                            [
                                html.H4('Period (days):'),
                                dbc.Input(
                                    id='days-input',
                                    type='number',
                                    placeholder='Enter timeframe',
                                    min=500,
                                    max=2500,
                                    step=1,
                                    style={'width': '200px'}
                                )
                            ],
                            className='mb-3'
                        ),
                        dbc.Col(
                            [
                                html.Button('Generate CVaR', id='cvar-generate-button', n_clicks=0, className="mr-2")
                            ]
                        )
                    ],
                    justify='center',
                    className="mt-3"
                )
            ],
            width=6,
            className="mt-3",
            id="cvar-box",
            style=cvar_box_style

        )
    ],
    justify='center'
),

dbc.Row(
    [
        dbc.Col(
            [
                dbc.Row(
                    [
                        dbc.Col(
                        dcc.Graph(
                            id='cvar-plot-insensitive',
                            style={'backgroundColor': 'rgb(28, 32, 47)'}
                        ),
                        width=6,
                        id='cvar-col',
                        style=cvar_plots_style  # Initially hide the plot
                        ),
                        dbc.Col(
                            dcc.Graph(
                                id='cvar-plot-sensitive',
                                style={'backgroundColor': 'rgb(28, 32, 47)'}
                            ),
                            width=6,
                            id='cvar2-col',
                            style=cvar_plots2_style  # Initially hide the plot
                        ),
                    ],
                    justify='center',
                    className="mt-3"
                )
            ]
        )
    ]
),
dbc.Row(
    [
        dbc.Col(
            [
                html.H2("Step 4: Evaluate the performance of your ESG Tangency Portfolio versus the Tangency portfolios", style={"textAlign": "left"}),
                html.H6("It is now time to analyze the performance of your ESG Tangency Portfolio and the Tangency portfolio. To do so, you should once again choose a risk-free rate, and a time frame for the performance analysis. This time it is measured in years. In the table generated, the two Tangency Portfolios are compared to a market portfolio (SP500)", style={"textAlign": "left"}),
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                html.H4('Risk-free rate:'),
                                dbc.Input(
                                    id='risk-free-rate-input2',
                                    type='number',
                                    placeholder='Enter a risk-free rate',
                                    min=0,
                                    max=1,
                                    step=0.01,
                                    style={'width': '200px'}
                                )
                            ],
                            className='mb-3'
                        ),
                        dbc.Col(
                            [
                                html.H4('Period (years):'),
                                dbc.Input(
                                    id='years-input',
                                    type='number',
                                    placeholder='Enter timeframe',
                                    min=1,
                                    max=14,
                                    step=1,
                                    style={'width': '200px'}
                                )
                            ],
                            className='mb-3'
                        ),
                        dbc.Col(
                            [
                                html.Button('Evaluate performance', id='performance-generate-button', n_clicks=0, className="mr-2")
                            ]
                        )
                    ],
                    justify='center',
                    className="mt-3"
                )
            ],
            width=6,
            className="mt-3",
            id="performance-box",
            style=performance_box_style

        )
    ],
    justify='center'
),

dbc.Row(
    [
        dbc.Col(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            dbc.Table(
                                [
                                    html.Thead(html.Tr([html.Th(""), html.Th("Jensens Alpha"), html.Th("Beta"), html.Th("Timing")])),
                                    html.Tbody(
                                        [
                                            html.Tr([html.Td("Your ESG Tangency Portfolio"), html.Td(id='alpha-value'), html.Td(id='beta-value'), html.Td(id='timing-value')]),
                                            html.Tr([html.Td("ESG Tangency Portfolio"), html.Td(id='alpha-insensitive-value'), html.Td(id='beta-insensitive-value'), html.Td(id='timing-insensitive-value')])
                                        ]
                                    ),
                                ],
                                id='performance-table',
                                bordered=True,
                                dark=True,
                                striped=True,
                                responsive=True,
                                hover=True,
                                style=performance_box_style
                            ),
                            width=6,
                            className="mt-3",
                        ),
                    ],
                    justify='center'
                ),
                dbc.Row(
                    [
                        dbc.Col(
                            dcc.Graph(
                                id='performance-plot',
                                style={'backgroundColor': 'rgb(28, 32, 47)'}
                            ),
                            width=6,
                            id='performance-col',
                            style=performance_plot_style
                        ),
                    ],
                    justify='center',
                    className="mt-3"
                )
            ]
        )
    ]
)







    ]
)


# Callback function to update the dropdown menu options, stock dropdown value, and ESG threshold value
@app.callback(
    [
        Output('stock-dropdown', 'options'),
        Output('stock-dropdown', 'value'),
        Output('esg-threshold-value', 'children')
    ],
    [
        Input('esg-threshold-slider', 'value'),
        Input('reset-button', 'n_clicks')
    ],
    [
        State('stock-dropdown', 'value')
    ]
)
def update_portfolio(esg_threshold, reset_clicks, selected_stocks):
    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # Code such that as the user changes the value of the ESG threshold, the dropdown menu is updated with stocks that fulfill the threshold
    if trigger_id == 'esg-threshold-slider':
        # Using the filter_esg_stocks function from the filter_sp500_stocks program
        filtered_df = filter_esg_stocks(dataframe, 'ESG', threshold=esg_threshold)
        # Updating stock options on the dropdown menu
        dropdown_options = [{'label': ticker, 'value': ticker} for ticker in filtered_df.index.tolist()]
        return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    elif trigger_id == 'reset-button':
        # Resetting the whole webpage to default settings if the user clicks on the Reset Portfolio button
        if reset_clicks > 0:
            # Reset the dropdown options to include all tickers
            dropdown_options = [{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()]

            # Reset the selected stocks value to an empty list
            selected_stocks = []

            # Reset the ESG threshold value to the minimum ESG score
            esg_threshold = dataframe['ESG']['ESG Score'].min()

            return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    # If no trigger or invalid trigger, return the initial values
    return dash.no_update, dash.no_update, dash.no_update


@app.callback(
    [
        Output('log-return-plot', 'figure'),
        Output('histogram-plot', 'figure'),
        Output('log-return-col', 'style'),
        Output('histogram-col', 'style'),
        Output('volatility-chart', 'figure'),
        Output('volatility-col' , 'style'),
        Output('correlation-matrix', 'figure'),
        Output('correlation-col', 'style'),
        Output('portfolio-table', 'style'),
        Output('portfolio-box', 'style'),
        Output('delta1-value', 'children'),
        Output('mvp-rating-value', 'children'),
        Output('ef-plot', 'figure'),
        Output('ef-plot2', 'figure'),
        Output('ef-return-col', 'style'),
        Output('ef-return-col2', 'style'),
        Output('dropdown-row', 'style'),
        Output('cvar-box', 'style'),
        Output('cvar-plot-insensitive', 'figure'),
        Output('cvar-col', 'style'),
        Output('cvar-plot-sensitive', 'figure'),
        Output('cvar2-col', 'style'),
        Output('performance-box', 'style'),
        Output('performance-plot', 'figure'),
        Output('performance-col', 'style'),
        Output('alpha-value', 'children'),
        Output('beta-value', 'children'),
        Output('timing-value', 'children'),
        Output('performance-table', 'style'),
        Output('alpha-insensitive-value', 'children'),
        Output('beta-insensitive-value', 'children'),
        Output('timing-insensitive-value', 'children')
    ],
    [
        Input('submit-button', 'n_clicks'),
        Input('reset-button', 'n_clicks'),
        Input('generate-button', 'n_clicks'), 
        Input('graph-dropdown', 'value'),
        Input('cvar-generate-button', 'n_clicks'),
        Input('performance-generate-button', 'n_clicks'),
    ],
    [
        State('stock-dropdown', 'value'),
        State('risk-free-rate-input', 'value'),
        State('threshold-input', 'value'),
        State('confidence-input', 'value'),
        State('days-input', 'value'),
        State('risk-free-rate-input2', 'value'),
        State('years-input', 'value'),
    ]
)



def update_portfolio_output(submit_clicks, reset_clicks, generate_clicks, selected_ef_graph,  generate_cvar, generate_performance, selected_stocks, risk_free_rate, threshold_value, confidence_interval, days, rf, years):
    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]


    if trigger_id == 'submit-button':
        if submit_clicks > 0:
            # Create an empty DataFrame to store selected stocks
            portfolio = pd.DataFrame(columns=dataframe.columns)

            # Add selected stocks to the portfolio DataFrame
            for stock in selected_stocks:
                portfolio = pd.concat([portfolio, dataframe.loc[dataframe.index == stock]])

            # Call the first function from the backend file portfolio_analysis
            # This function will calculate all the base metrics and the ESG insensitive investor
            logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, delta1, mvp_rating = calculate_fundemental_functions(
                portfolio)

            logarithmic_return.index = pd.to_datetime(logarithmic_return.index)

            # Create a line plot for each ticker
            log_return_fig = go.Figure()

            for column in logarithmic_return.columns:
                log_return_fig.add_trace(go.Scatter(
                    x=logarithmic_return.index,
                    y=logarithmic_return[column],
                    mode='lines',
                    name=column
                ))

            log_return_fig.update_layout(
                title='Logarithmic Returns',
                xaxis_title='Date',
                yaxis_title='Logarithmic Return',
                legend=dict(orientation="h"),
                hovermode='x unified',
                plot_bgcolor='rgb(28, 32, 47)',
                paper_bgcolor='rgb(28, 32, 47)',
                font = dict(color="white")
            )

            # Plot the histogram for ESG Scores
            histogram_fig = px.histogram(portfolio, x=portfolio.index, y=portfolio['ESG']['ESG Score'])
            histogram_fig.update_layout(
                title='ESG Scores',
                xaxis_title='Ticker',
                yaxis_title='ESG Score',
                showlegend=False,
                plot_bgcolor='rgb(28, 32, 47)',
                paper_bgcolor='rgb(28, 32, 47)',
                font = dict(color="white")
            )

            covariance = logarithmic_return.cov()
            covariance_matrix_plot = px.imshow(covariance)
            covariance_matrix_plot.update_layout(
            title='Covariance Matrix',
            xaxis_title='Stocks',
            yaxis_title='Stocks',
            plot_bgcolor='rgb(28, 32, 47)',
            paper_bgcolor='rgb(28, 32, 47)',
            coloraxis_colorbar=dict(title='Correlation'),
            font = dict(color="white")
            )

            correlation = logarithmic_return.corr()
            # Create the correlation matrix plot using px.imshow()
            correlation_matrix = px.imshow(correlation)

            # Update the layout with the desired background colors
            correlation_matrix.update_layout(
                title='Correlation Matrix',
                xaxis_title='Stocks',
                yaxis_title='Stocks',
                coloraxis_colorbar=dict(title='Correlation'),
                plot_bgcolor='rgb(28, 32, 47)',
                paper_bgcolor='rgb(28, 32, 47)',
                font = dict(color="white")
)


            # Show the plots
            log_return_style = {"display": "block"}
            histogram_style = {"display": "block"}
            volatility_chart_style = {"display" : "block"}
            correlation_matrix_style = {"display" : "block"}
            table_style = {"display" : "block"}
            portfolio_output_style = {"display": "block"}
            efficient_frontier_style = {"display" : "none"}
            ef_plots_dropdown_style = {"display" : "none"}
            cvar_box_style = {"display" : "none"}
            cvar_plots_style = {"display" : "none"}
            cvar_plots2_style = {"display" : "none"}
            performance_box_style = {"display" : "none"}
            performance_plot_style = {"display" : "none"}
            performance_table_style = {"display" : "none"}

            return log_return_fig, histogram_fig, log_return_style, histogram_style, covariance_matrix_plot, volatility_chart_style, correlation_matrix, correlation_matrix_style, table_style, portfolio_output_style, delta1, mvp_rating, dash.no_update, dash.no_update, efficient_frontier_style, efficient_frontier_style, ef_plots_dropdown_style, cvar_box_style, dash.no_update, cvar_plots_style, dash.no_update, cvar_plots2_style, performance_box_style, dash.no_update, performance_plot_style, '', '', '', performance_table_style, '', '', ''

    #efficient_frontier_weights_insensitive = expected_return_insensitive = volatility_insensitive = weighted_average_esg_score_insensitive = sr_t_list = mvp_weight = mvp_er = mvp_vol = mvp_esg_score = mvp_e_score = mvp_s_score = mvp_g_score = sr = w_opt = sharpe_exp = sharpe_vol = sr_esg_score = sr_e_score = sr_s_score = sr_g_score = optimal_weights = optimal_sortino_ratio = sortino_exp = sortino_vol = sortino_score = sortino_e_score = sortino_s_score = sortino_g_score = labels = tickers_list = esg_investor_weights = esg_portfolio_returns = esg_portfolio_vol = esg_investor_wa = sr_esg = w_opt_esg = sharpe_exp_esg = sharpe_vol_esg = sr_esg_esg_score = sr_esg_e_score = sr_esg_s_score = sr_esg_g_score = optimal_weights_esg = optimal_sortino_ratio_esg = sortino_exp_esg = sortino_vol_esg = sortino_score_esg = sortino_e_score_esg = sortino_s_score_esg = sortino_g_score_esg = None



            #return efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, labels, tickers_list, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg
    elif trigger_id == 'generate-button':
            if generate_clicks > 0:
                # Create an empty DataFrame to store selected stocks
                portfolio1 = pd.DataFrame(columns=dataframe.columns)

                # Add selected stocks to the portfolio DataFrame
                for stock in selected_stocks:
                    portfolio1 = pd.concat([portfolio1, dataframe.loc[dataframe.index == stock]])
              
                # Call the first function from the backend file portfolio_analysis
                # This function will calculate all the base metrics and the ESG insensitive investor
                logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, delta1, mvp_rating = calculate_fundemental_functions(portfolio1)
                
            

                efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, labels, tickers_list, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg = calculate_esg_investor_types(portfolio1, logarithmic_return, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, esg_np, e_np, s_np, g_np, risk_free_rate, threshold_value)
                
                plot_efficient_frontiers_with_sharpe, plot_efficient_frontiers_with_sortino = plot_efficient_frontiers(efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg, tickers_list)
            
            
                ef_plots_dropdown_style = {"display" : "block"}
                cvar_box_style = {"display" : "block"}

                if selected_ef_graph == 'graph1':
                    return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, plot_efficient_frontiers_with_sharpe, plot_efficient_frontiers_with_sortino, {"display" : "block"}, {"display" : "none"}, ef_plots_dropdown_style, cvar_box_style, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, '', '', '', dash.no_update, '', '', ''

                elif selected_ef_graph == 'graph2':
                    return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, plot_efficient_frontiers_with_sharpe, plot_efficient_frontiers_with_sortino, {"display" : "none"}, {"display" : "block"}, ef_plots_dropdown_style, cvar_box_style, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update , '', '', '', dash.no_update, '', '', ''

                else:
                    return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, plot_efficient_frontiers_with_sharpe, plot_efficient_frontiers_with_sortino, dash.no_update, dash.no_update, ef_plots_dropdown_style, cvar_box_style, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, '', '', '', dash.no_update, '', '', ''
    
    elif trigger_id =='cvar-generate-button':
        if generate_cvar > 0:
                portfolio2 = pd.DataFrame(columns=dataframe.columns)

                # Add selected stocks to the portfolio DataFrame
                for stock in selected_stocks:
                    portfolio2 = pd.concat([portfolio2, dataframe.loc[dataframe.index == stock]])
              
                # Call the first function from the backend file portfolio_analysis
                # This function will calculate all the base metrics and the ESG insensitive investor
                logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, delta1, mvp_rating = calculate_fundemental_functions(portfolio2)
                
            
                #Calculate the two investor types again.
                efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, labels, tickers_list, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg = calculate_esg_investor_types(portfolio2, logarithmic_return, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, esg_np, e_np, s_np, g_np, risk_free_rate, threshold_value)
                
                cvar_plot_insensitive = risk_for_investor_types(portfolio2, w_opt, confidence_interval, days)
                # Update the layout
                cvar_plot_insensitive.update_layout(
                    xaxis_title='Returns',
                    yaxis_title='Frequency',
                    legend=dict(x=0.7, y=1),
                    title=f'Returns Distribution with VaR and CVaR for Tangency Portfolio',
                    barmode='stack',
                    plot_bgcolor='rgb(28, 32, 47)',
                    paper_bgcolor='rgb(28, 32, 47)',
                    font = dict(color="white") 
)   


                cvar_plot_sensitive = risk_for_investor_types(portfolio2, w_opt_esg, confidence_interval, days)
                cvar_plot_sensitive.update_layout(
                    xaxis_title='Returns',
                    yaxis_title='Frequency',
                    legend=dict(x=0.7, y=1),
                    title=f'Returns Distribution with VaR and CVaR for your ESG Tangency Portfolio',
                    barmode='stack',
                    plot_bgcolor='rgb(28, 32, 47)',
                    paper_bgcolor='rgb(28, 32, 47)',
                    font = dict(color="white")
)   



                cvar_plots_style = {'display' : 'block'}
                cvar_plots2_style = {'display' : 'block'}
                performance_box_style = {'display' : 'block'}

                return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, cvar_plot_insensitive, cvar_plots_style, cvar_plot_sensitive, cvar_plots2_style, performance_box_style, dash.no_update, dash.no_update, '', '', '', dash.no_update, '', '', ''


    elif trigger_id ==  'performance-generate-button':
        if generate_performance > 0:
            portfolio3 = pd.DataFrame(columns=dataframe.columns)

                # Add selected stocks to the portfolio DataFrame
            for stock in selected_stocks:
                    portfolio3 = pd.concat([portfolio3, dataframe.loc[dataframe.index == stock]])
              
                # Call the first function from the backend file portfolio_analysis
                # This function will calculate all the base metrics and the ESG insensitive investor
            logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, delta1, mvp_rating = calculate_fundemental_functions(portfolio3)
            log_market_returns = log_returns(benchmark)

            
            #Calculate the two investor types again.
            efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, labels, tickers_list, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg = calculate_esg_investor_types(portfolio3, logarithmic_return, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, esg_np, e_np, s_np, g_np, risk_free_rate, threshold_value)
               
            #jensens_alpha_insensitive, beta_insensitive, timing_insensitive = portfolio_performance(years, logarithmic_return, w_opt, log_market_returns, rf)
            fig, jensens_alpha_insensitive, beta_insensitive,timing_insensitive, jensens_alpha_sensitive, beta_sensitive,timing_sensitive = portfolio_performance(portfolio3, years, logarithmic_return, w_opt, w_opt_esg, log_market_returns, rf)

            performance_plot_style = {'display' : 'block'}
            performance_table_style = {'display' : 'block'}


            fig.update_layout(
            title='Portfolio Adjusted Close price',
            xaxis=dict(title='Years'),
            yaxis=dict(title='Adj Close price'),
            plot_bgcolor='rgb(28, 32, 47)',
            paper_bgcolor='rgb(28, 32, 47)',
            font = dict(color="white")
             )

            #fig.show()


            return  dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, fig, performance_plot_style, jensens_alpha_insensitive, beta_insensitive, timing_insensitive, performance_table_style, jensens_alpha_sensitive, beta_sensitive,timing_sensitive
            

            

    elif trigger_id == 'reset-button':
        if reset_clicks > 0:
            # Hide the plots and reset the portfolio box style
            log_return_style = {"display": "none"}
            histogram_style = {"display": "none"}
            volatility_chart_style = {"display" : "none"}
            correlation_matrix_style = {"display" : "none"}
            table_style = {'display' : "none"}
            portfolio_output_style = {"display": "none"}
            efficient_frontier_style = {"display" : "none"}
            ef_plots_dropdown_style = {"display" : "none"}
            cvar_box_style = {"display" : "none"}
            cvar_plots_style = {"display" : "none"}
            cvar_plots2_style = {"display" : "none"}
            performance_box_style = {"display" : "none"}
            performance_plot_style = {"display" : "none"}
            performance_table_style = {"display" : "none"}


       

            return dash.no_update, dash.no_update, log_return_style, histogram_style, dash.no_update, volatility_chart_style, dash.no_update, correlation_matrix_style, table_style, portfolio_output_style, '', '', dash.no_update, dash.no_update, efficient_frontier_style, efficient_frontier_style, ef_plots_dropdown_style, cvar_box_style, dash.no_update, cvar_plots_style, dash.no_update, cvar_plots2_style, performance_box_style, dash.no_update, performance_plot_style, '','','', performance_table_style, '','',''

            
            
            #return dash.no_update, dash.no_update, log_return_style, histogram_style, portfolio_output_style

    return dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update, dash.no_update

if __name__ == "__main__":
    app.run(debug=False, port = 8059)