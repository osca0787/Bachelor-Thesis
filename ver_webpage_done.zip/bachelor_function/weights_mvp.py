import numpy as np
def mvp_weights(a : float, b : float, c : float, d : float, inv_cov : np.ndarray, vec_ones : np.ndarray, mean_return : np.ndarray, exp_return_1 : float, exp_return_2 : float):
    """Function that computes two optimal weights with different expected returns

    Parameters
    ----------

    a : float
        Scalar that is used to calculate the two optimal weights

    b : float
        Scalar that is used to calculate the two optimal weights

    c : float
        Scalar that is used to calculate the two optimal weights

    d : float
        Scalar that is used to calculate the two optimal weights

    inv_cov : Pandas Dataframe
        An inverse covariance matrix
    
    vec_ones : Numpy Array
        A numpy array vector of ones. Has the same length as mean_return 

    mean_return : Numpy Array
        A numpy array consisting of the mean return of some selected stocks

    exp_return_1 : float
        The expected return of the first optimal weight

    exp_return_2 : float
        The expected return of the second optimal weight
    

    Returns
    -------
    Scalar: float
        Returns two optimal weights with different expected return, which is located on the efficient frontier
        
    """
    
    if inv_cov.size == 0 or mean_return.size == 0 or vec_ones.size == 0:
        raise ValueError("One or more of the input parameters are empty")
    else:

        if not all(isinstance(x, np.ndarray) for x in (inv_cov, vec_ones, mean_return)) or not all(isinstance(i, (float, int)) for i in (exp_return_1, exp_return_2)):
            raise TypeError("Input must be a Numpy Array and exp_return_1, exp_return_2 must be float or int.")
    
    
        else:
            g = 1/d*(b*inv_cov@vec_ones - a*inv_cov@mean_return)
            h = 1/d*(c*inv_cov@mean_return - a*inv_cov@vec_ones)
            weight_1 = g + h * exp_return_1
            weight_2 = g + h * exp_return_2
            return weight_1, weight_2
