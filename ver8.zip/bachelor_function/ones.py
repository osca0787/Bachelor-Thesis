import numpy as np
def vector_ones(labels):
    """Function that creates a numpy array of ones

    Parameters
    ----------
    labels : str
        Pandas Dataframe which contains the tickers (index) of a selected amount of stocks
    

    Returns
    -------
    Pandas Dataframe
        A vector of ones, which is the same length as the Pandas Dataframe of tickers.
    """

    return np.ones(len(labels))