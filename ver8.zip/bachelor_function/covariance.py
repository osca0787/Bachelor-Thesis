import pandas as pd
import numpy as np
        

def cov_matrix(stocks):
    """Function that computes the covariance-variance matrix

    Parameters
    ----------
    Stocks : float
        Pandas Dataframe which contains the logarithmic returns of a certain amount of stocks
    

    Returns
    -------
    Pandas Dataframe
        a Dataframe of the covariance-variance each selected stock
    """




    # Extract the data
    labels = stocks.columns
    X = stocks.values

    # Extract the number of rows and columns
    N, M = stocks.shape

    # Calculate the covariance matrix
    cov = np.zeros((M, M))
    for i in range(M):

        # Mean of column "i"
        mean_i = np.sum(X[:, i]) / N

        for j in range(M):

            # Mean of column "j"
            mean_j = np.sum(X[:, j]) / N

            # Covariance between column "i" and column "j"
            cov[i, j] = np.sum((X[:, i] - mean_i) * (X[:, j] - mean_j)) / (N - 1)
            
        #Form the data so it is contained in a Pandas Dataframe
        cov_df = pd.DataFrame(cov, index=labels, )
        cov_df.columns = labels
    return cov_df