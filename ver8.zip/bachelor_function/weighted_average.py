import numpy as np
def aw_esg(esg_mean, weight, assets):
    list_wa = np.zeros(len(weight))
    for i in range(len(weight)):
        sum_weights = 0
        for j in range(len(assets)):
            #print(i)
            #print(j)
            #print(weight[i][j])
            #print(esg[j])
            list_wa[i] += esg_mean[j] * weight[i][j]
            #print(list_wa[i])
            sum_weights += weight[i][j]
            #print(sum_weights)
        list_wa[i] /= sum_weights
    return list_wa