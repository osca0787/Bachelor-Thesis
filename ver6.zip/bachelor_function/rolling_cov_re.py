from covariance import cov_matrix
from mean_ret import mean_return
import numpy as np

def rolling_er_cov(stocks, window):
    """Function that computes the covariance-variance matrix, mean returns and inverse covariance-variance matrix of a list of stocks

    Parameters
    ----------
    Stocks : float
        Pandas Dataframe which contains the logarithmic price of a certain amount of stocks
    Window : Int
        A parameter that indicates how many rolling windows we are working with
    
        
    Imported function
    -----------------

    cov_matrix
        This function is used to compute the covariance-variance matrix and inverse covariance-variance matrix for each rolling window. Check the file covariance.py for a description of the function

    mean_return
        This function is used to compute the mean returns for each rolling window. Check the file mean_ret.py for a description of the function

    Returns
    -------
    Pandas Dataframe
        A Pandas dataframe for a covariance-variance matrix and the inverse covariance-variance matrix for each rolling window
    
    Numpy Array
        A Numpy array containing the mean returns of each stock for every rolling window
    """

    #creating lists, that will store our results for each rolling windows
    rolling_er = []
    rolling_cov = []
    rolling_inv_cov = []
    for i in range(len(stocks) - window + 1):
        #rolling_er.append(mean_return(stocks[i:i+window]))
        #rolling_cov.append(cov_matrix(stocks[i:i+window]))
        rolling_er.append(mean_return(stocks[i:i+window]))
        rolling_cov.append(cov_matrix(stocks[i:i+window]))
        rolling_inv_cov.append(np.linalg.inv(cov_matrix(stocks[i:i+window])))
        
    return rolling_er, rolling_cov, rolling_inv_cov


