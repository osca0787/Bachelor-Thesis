import ipywidgets as widgets
from IPython.display import display
import pandas as pd
import numpy as np
def create_portfolio1(dataframe):
    """
    Function to interactively create a portfolio of stocks from a DataFrame.

    Parameters:
        dataframe : Pandas Dataframe
            DataFrame containing stock tickers, last prices, and ESG scores.

    Returns:
        pd.DataFrame: DataFrame containing selected stocks with their respective variables and scores.
    """

    #Creating a copy of the input stock Dataframe to avoid modifying orginal data
    stock_data_copy = dataframe.copy()


    #Creating an empty Dataframe to store selected stocks in
    portfolio = pd.DataFrame(columns=dataframe.columns)

    ticker_list = list(dataframe.index)


    # Create widgets for user input
    num_stocks_widget = widgets.IntSlider(
        value=1,
        min=1,
        max=len(dataframe),
        step=1,
        description='Number of stocks:',
        continuous_update=False
    )
    stock_dropdown_widget = widgets.Dropdown(
        options=ticker_list,
        description='Stocks:',
        continuous_update=False,
        layout=widgets.Layout(width='300px')
    )
    add_button = widgets.Button(description='Add stock')
    exit_button = widgets.Button(description='Exit')
    output = widgets.Output()
    
    # Define button click event handlers
    def add_stock(button):
        nonlocal stock_data_copy, portfolio

        #Here we get the selected ticker from the dropdown menu
        stock_ticker = stock_dropdown_widget.value

        #Now we need to check whether the selected stock is in the portfolio
        if stock_ticker in portfolio.index:
            #If the stock is in the portfolio the user will recieve an message
            print(f"Stock {stock_ticker} is already placed in your portfolio. Please choose another stock")
        else:
            #If the stock isn't already present in the portfolio it will be added to the users portfolio.
            stock_data = dataframe.loc[stock_ticker]
            portfolio.loc[stock_ticker] = stock_data
            print(f"Stock {stock_ticker} has been added to your portfolio")

        #Lastly, we need to remove the added stock from the dropdown menu
        ticker_list.remove(stock_ticker)
        stock_dropdown_widget.options = ticker_list
        
            
            
            # Adding the selected stock to the users portfolio 
            #stock_ticker = stock_data_copy[stock_data_copy.loc[stock_ticker] == stock_ticker]
            #portfolio = pd.concat([portfolio, stock_ticker])

            #Now we need to remove the stock from the dropdown menu
            #stock_data_copy = stock_data_copy[stock_data_copy.loc[stock_ticker] != stock_ticker]
            #stock_dropdown_widget.options = dataframe.index

            #with output:
             #   print(f"Added stock to portfolio: {stock_ticker}")
              #  display(stock_ticker)

       #else:
        #    with output:
         #       print(f"Stock {stock_ticker} is already in your portfolio")




        #stock_data = dataframe.loc[stock_ticker]
        #portfolio.loc[stock_ticker] = stock_data
        #print(f'Stock {stock_ticker} added to portfolio.')

    def exit(button):
        display(portfolio)
        return


    #Creating a reset button, from which the user can clear the portfolio
    reset_button = widgets.Button(description='Reset portfolio')
    reset_output = widgets.Output()


    def reset_portfolio(button):
        nonlocal stock_data_copy, portfolio

        #Clearing the portfolio and reseting the dropdown menu options
        portfolio = pd.DataFrame(columns=dataframe.columns)
        stock_data_copy = dataframe.copy()
        stock_dropdown_widget.options = dataframe.index

        #Clear the output
        with reset_output:
            print("Your portfolio has been reset.")
            display(pd.DataFrame())

    #Adding the reset button
    reset_button.on_click(reset_portfolio)



    # Assign event handlers to buttons
    add_button.on_click(add_stock)
    exit_button.on_click(exit)

    # Display widgets
    display(num_stocks_widget)
    display(stock_dropdown_widget)
    display(add_button)
    #display(output)
    display(exit_button)
    display(reset_button)
    display(reset_output)

    return portfolio