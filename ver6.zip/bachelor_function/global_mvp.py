import numpy as np
def global_mvp(weight, volatility, mean_return, cov_matrix):

    """Function that computes the global minimum variance portfolio

  Parameters
  ----------
    weight : Numpy Array
        A numpy array of portfolio weights
    
    volatility : Numpy Array
        A numpy array of each portfolios volatility

    mean_return : Numpy Array
        A numpy array containing each stocks mean return

    cov_matrix : Pandas Dataframe
        A Pandas Dataframe, which contains the covariance-variance matrix


  Returns
  ------
    mvp_w : Numpy Array
        Returns a numpy array containing the weights of the global minimum variance portfolio
    
    mvp_return : float
        Returns the expected return of the global minimum variance portfolio

    mvp_vol : float
        Returns the volatility of the global minimum variance portfolio
    """


    #Transforming input into the correct data type
    weight = np.array(weight)
    volatility = np.array(volatility)


    #Minimizing the volatility of the weights to find the global minimum variance portfolio
    mvp_w = weight[volatility.argmin()]

    #Calculating the expected return of the MVP
    mvp_return = mvp_w@mean_return


    #Calculting the volatility of the MVP
    mvp_vol = np.sqrt(mvp_w @ cov_matrix.values @ mvp_w.T)

    return (mvp_w, mvp_return, mvp_vol)