import numpy as np
def var_portfolio(weights,covar_matrix):
  """Function that computes the variance of a portfolio

  Parameters
  ----------
  weights : Numpy Array
      A numpy array of the portfolios weights

  covar_matrix : Numpy Array
      A numpy array consiting of the stocks covariance-variance matrix

  

  Returns
  ------
    variance_list : Numpy Array
        Returns a numpy array of each portfolios variance 
  """


  # Compute portfolio variance using matrix multiplication
  variance_list = []
  for i in weights:
    # We use the variance of a portfolio formula:
    variance_list.append(i@covar_matrix@i.T)
  return np.array(variance_list)
