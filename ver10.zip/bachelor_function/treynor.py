from sklearn.linear_model import LinearRegression
import numpy as np
def treynor(lookback_years, port_returns, weights, benchmark_returns, risk_free_rate):
    #Define the regression
    reg = LinearRegression()
    #First we find the portfolios return during x years
    portfolio_returns = port_returns.iloc[-lookback_years:].dot(weights)
    np_portfolio_returns = np.array(portfolio_returns)

    Y = np_portfolio_returns.reshape(-1,1) - risk_free_rate

    benchmark = benchmark_returns.to_numpy()
    X = benchmark[-lookback_years:].reshape(-1,1) - risk_free_rate



    X_square = X**2
    #Now we need to stack X and X_square

    stacked = np.hstack((X, X_square))

    #Compile the regression
    reg.fit(stacked, Y)

    return reg.intercept_[0], reg.coef_[0,0], reg.coef_[0,1]