import numpy as np
from var import value_at_risk
def cvar(value_invested, returns, weights, alpha=0.95, lookback_years=17):
    # Call out to our existing function
    var = value_at_risk(value_invested, returns, weights, alpha, lookback_years=lookback_years)
    portfolio_returns = returns.iloc[-lookback_years:].dot(weights)
    
    # Get back to a return rather than an absolute loss
    var_pct_loss = var / value_invested
    
    return value_invested * np.nanmean(portfolio_returns[portfolio_returns < var_pct_loss])