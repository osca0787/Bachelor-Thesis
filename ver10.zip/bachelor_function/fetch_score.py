def get_scores(data_sample):
    esg = data_sample['ESG']['ESG Score']
    esg_np = esg.to_numpy()
    e = data_sample['Environmental']['Environmental Score']
    e_np = e.to_numpy()
    s = data_sample['Social']['Social Score']
    s_np = s.to_numpy()
    g = data_sample['Governance']['Governance Score']
    g_np = g.to_numpy()
    return esg_np, e_np, s_np, g_np