import numpy as np
def test_functions():
    res = 0
