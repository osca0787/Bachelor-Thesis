def alpha(emp):
    """Gives us a list with values between any given value 

    Parameters
    ----------
    emp : list
        A list with values between any given value

    Returns
    -------
    emp : list
        Returns a list of real numbers with, which ranges from -x to x (where -x and x is the two value we have calculated in between). 
        
    """

    for i in range(600):
        #emp.append(round(emp[i]+ 0.002, 3))
        emp.append(emp[i]+ 1/100)
    return emp
