from scipy.optimize import minimize
import numpy as np
def optimize_sortino_ratio(returns, risk_free_rate, labels, guess, mean_ret, covar, esg_score, e_scores, s_scores, g_scores, esg_threshold):
    def sortino_ratio(weights):
        portfolio_return = np.dot(returns.mean(), weights)
        downside_returns = np.minimum(returns, 0)
        downside_risk = np.sqrt(np.mean(np.square(downside_returns)))
        sortino_ratio = (portfolio_return - risk_free_rate) / downside_risk
        return -1*sortino_ratio
    

    def checkSumToOne(x):
        return np.sum(x)-1

    def esg_constraint(x):
        esg_product = np.dot(x, esg_score)
        return esg_product - esg_threshold

    constraintSet = (-1, 1)
    bounds = tuple(constraintSet for asset in range(len(labels)))

    #For the traditional investor
    constraints = [{'type':'eq', 'fun':checkSumToOne}]
    result = minimize(sortino_ratio, guess, method='SLSQP',
                      bounds=bounds, constraints=constraints)
    optimal_weights = result.x
    optimal_sortino_ratio = -result.fun
    sortino_exp = optimal_weights@mean_ret
    sortino_vol = np.sqrt(optimal_weights@covar@optimal_weights)
    sortino_score = optimal_weights@esg_score
    sortino_e_score = optimal_weights@e_scores
    sortino_s_score = optimal_weights@s_scores
    sortino_g_score = optimal_weights@g_scores


    constraints_esg = [{'type':'eq', 'fun':checkSumToOne},
                    {'type': 'ineq', 'fun': esg_constraint}]
    w_opt_esg = minimize(sortino_ratio, guess, method='SLSQP',
                      bounds=bounds, constraints=constraints_esg)
    optimal_weights_esg = w_opt_esg.x
    optimal_sortino_ratio_esg = -w_opt_esg.fun
    sortino_exp_esg = optimal_weights_esg@mean_ret
    sortino_vol_esg = np.sqrt(optimal_weights_esg@covar@optimal_weights_esg)
    sortino_score_esg = optimal_weights_esg@esg_score
    sortino_e_score_esg = optimal_weights_esg@e_scores
    sortino_s_score_esg = optimal_weights_esg@s_scores
    sortino_g_score_esg = optimal_weights_esg@g_scores


    return optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg
