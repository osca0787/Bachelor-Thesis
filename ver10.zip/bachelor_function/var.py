import numpy as np
def value_at_risk(value_invested, returns, weights, alpha=0.95, lookback_years=8):
    # Multiply asset returns by weights to get one weighted portfolio return
    port_r = returns.iloc[-lookback_years:].dot(weights)
    #portfolio_returns = returns.iloc[-lookback_days:].T@weights
    # Compute the correct percentile loss and multiply by value invested
    return np.percentile(port_r, 100 * (1-alpha)) * value_invested