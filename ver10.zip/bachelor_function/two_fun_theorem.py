import numpy as np
from expected_return import exp_return
from variance import var_portfolio
from volatility import volatility
def w3(weight1,weight2,alpha, mean_return, cov_matrix, scores):
  """Function that finds all the optimal weights of the efficient frontier

  Parameters
    ----------
  weight1 : list
    A list with the optimal weights of the first portfolio

  weight2 : list
    A list with the optimal weights of the second portfolio

  alpha : list
    A list with values that ranges from -x to x

  Returns
  -------
  weight3 : Tuple
    Returns a numpy array, which holds all the optimal portfolios for the efficient frontier, and a list of expected returns and volatilities for each portfolio
        
  """

  weight3 = []
  for i in alpha:
    weight3.append(i*weight1 + (1-i)*weight2)
  weight3 = np.array(weight3)

  portfolio_expected_return = exp_return(weight3, mean_return)
  portfolio_variance = var_portfolio(weight3, cov_matrix)
  portfolio_volatility = volatility(portfolio_variance)
  portfolio_score = np.dot(weight3, scores)
  return weight3, portfolio_expected_return, portfolio_volatility, portfolio_score

