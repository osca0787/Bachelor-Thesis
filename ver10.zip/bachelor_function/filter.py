import numpy as np
def filter_esg_stocks(df, score_type, threshold=None):
     
    """Function that filters a dataframe based on a threshold for a given scoretype

    Parameters
     ----------
    df : Pandas Dataframe
        a Pandas Dataframe that contains a list of stocks  
  
     score_type : String
        score_type is a string, which indicates which score type the user wishes to filter for
        
    threshold : Pandas Dataframe
        Covariance-variance matrix for the stocks

Returns
------
    Tuple : Numpy Arrays
    Returns the Max SR, and its weights, expected return, volatility and WA ESG score.
    Returns the Max ESG SR, and its weights, expected return, volatility and WA ESG score.
"""
     
    valid_score_type = ['ESG', 'Enviromental', 'Social', 'Governance']
    if score_type not in valid_score_type:
        raise ValueError("Invalid score type. Please choose from ESG, Enviromental, Social or Governance")

    # Filter dataframe based on threshol
    if threshold is not None:
        filtered = df[df[score_type + ' Disc Mean'][score_type + ' Disc mean score'] >= threshold]

    return filtered