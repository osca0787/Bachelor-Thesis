import numpy as np
def mvp_func(inv_cov, mean_return, vec_ones):
    """Function that computes four auxiliary variables, which will help to compute the two optimal weights with different return

    Parameters
    ----------
    inv_cov : Pandas Dataframe
        An inverse covariance matrix
    
    mean_return : Numpy Array
        a numpy array consisting of the mean return of some selected stocks

    vec_ones : Numpy Array
        a numpy array vector of ones. Has the same length as mean_return 
    

    Returns
    -------
    Scalar: float
        Returns four auxiliary variables with the data type float
        
    """

    #Calculate a
    #a = vec_ones@inv_cov@mean_return
    # Now we calculate b: 
    #b = mean_return.T@inv_cov@mean_return
    # c vector:
    #c = vec_ones.T@inv_cov@vec_ones
    # Then d:
    #d = b*c-a**2
     #Calculate a
    a = vec_ones.T@inv_cov@mean_return
    # Now we calculate b: 
    b = mean_return.T@inv_cov@mean_return
    # c vector:
    c = vec_ones.T@inv_cov@vec_ones
    # Then d:
    d = b*c-a**2


    return a, b, c, d
