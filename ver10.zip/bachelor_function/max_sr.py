import numpy as np
from scipy.optimize import minimize

def sharpe_ratio1(risk_free_rate, mean_return, cov_var, weights, er, vol, weights_esg, er_esg, vol_esg, esg_score, e_score, s_score, g_score, guess, labels, esg_threshold):
    """Function that the SR and ESG SR

    Parameters
    ----------
    risk_free_rate : float
        a float that refers to the rate of return an investor expects to earn on a zero risk asset    
  
    mean_return : Numpy Array
        Numpy array of mean returns for each stock

    cov_var : Pandas Dataframe
        Covariance-variance matrix for the stocks
    
    weights : Numpy Array
        the optimal portfolio weights for the traditional investor

    er : Numpy Array
        Expected return for each of the optimal portfolios for the traditional investor

    vol : Numpy Array
        Optimal portfolios volatility for the traditional investor

    weights_esg : Numpy Array
        Optimal portfolio weights for the responsible investor

    er_esg : Numpy Array
        Expected return for each optimal portfolio for the responisble investor

    er_vol : Numpy Array
        the optimal portfolios volatility for the responsible investor

    esg_score : Numpy Array
        an array consiting of each optimal portfolios Weighted Average ESG score
        Will be used to find the Max ESG SR


  

    Returns
    ------
        Tuple : Numpy Arrays
        Returns the Max SR, and its weights, expected return, volatility and WA ESG score.
        Returns the Max ESG SR, and its weights, expected return, volatility and WA ESG score.
        """
    #Helper function used as a constraint
    def checkSumToOne(w):
        return np.sum(w)-1

    #We use a minimizer so we create a helper function find the negative sharpe ratio, which will be the highest
    def negativeSR(w):
        w = np.array(w)
        V = np.sqrt(w.T @ cov_var @ w)
        R = np.sum(mean_return * w)
        SR = R /V
        return -1*SR
    
    def esg_constraint(x):
        esg_product = np.dot(x, esg_score)
        return esg_product - esg_threshold

    constraintSet = (-1,1)
    bounds = tuple(constraintSet for asset in range(len(labels)))


    #Find the optimal point with the highest sharpe ratio
    constraints = ({'type':'eq', 'fun':checkSumToOne})
    w_opt = minimize(negativeSR, guess, method='SLSQP', bounds=bounds, constraints=constraints).x
    sharpe_exp = w_opt@mean_return
    sharpe_vol = np.sqrt(w_opt.T@cov_var@w_opt)

    sr = (sharpe_exp - risk_free_rate) / sharpe_vol

    sr_esg_score = np.dot(w_opt, esg_score)
    sr_e_score = np.dot(w_opt, e_score)
    sr_s_score = np.dot(w_opt, s_score)
    sr_g_score = np.dot(w_opt, g_score)



    constraints_esg = [{'type':'eq', 'fun':checkSumToOne},
                    {'type': 'ineq', 'fun': esg_constraint}]
    obj_func = lambda x: negativeSR(x)
    w_opt_esg = minimize(negativeSR, guess, method='SLSQP', bounds=bounds, constraints=constraints_esg).x
    sharpe_exp_esg = w_opt_esg@mean_return
    sharpe_vol_esg = np.sqrt(w_opt_esg.T@cov_var@w_opt_esg)

    sr_esg_esg_score = np.dot(w_opt_esg, esg_score)
    sr_esg_e_score = np.dot(w_opt_esg, e_score)
    sr_esg_s_score = np.dot(w_opt_esg, s_score)
    sr_esg_g_score = np.dot(w_opt_esg, g_score)
    
    sr_esg = (sharpe_exp_esg - risk_free_rate) / sharpe_vol_esg



    return sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score