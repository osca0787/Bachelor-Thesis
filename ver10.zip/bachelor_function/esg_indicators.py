import numpy as np
def indicators(vector_one, inv_cov, mean_re, r, esg_np, threshold):
    delta_0 = ( (mean_re.T@inv_cov@mean_re)*(vector_one.T@inv_cov@esg_np) - (vector_one.T@inv_cov@mean_re) * (mean_re.T@inv_cov@esg_np) ) / ( (vector_one.T@inv_cov@vector_one) * (mean_re.T@inv_cov@mean_re) - (vector_one.T@inv_cov@mean_re)**2 )
    delta_1 = ( (mean_re.T@inv_cov@esg_np) * (vector_one.T@inv_cov@vector_one) - (vector_one.T@inv_cov@mean_re) * (vector_one.T@inv_cov@esg_np) ) / ( (vector_one.T@inv_cov@vector_one) * (mean_re.T@inv_cov@mean_re) - (vector_one.T@inv_cov@mean_re)**2 )
    phi_0 = delta_0 + delta_1*r
    lambda_0 = ( ((mean_re.T@inv_cov@vector_one) * (esg_np.T@inv_cov@vector_one)) - ((vector_one.T@inv_cov@vector_one) * (esg_np.T@inv_cov@mean_re)) ) /  (( esg_np.T - threshold * vector_one.T) @ inv_cov @ vector_one) 
    gamma_0 = (( (mean_re.T@inv_cov@esg_np)*(vector_one.T@inv_cov@esg_np) - (vector_one.T@inv_cov@mean_re) * (esg_np.T@inv_cov@esg_np) ) / ( (vector_one.T@inv_cov@esg_np)**2 - (vector_one.T@inv_cov@vector_one) * (esg_np.T@inv_cov@esg_np) )) + threshold * (( (vector_one.T@inv_cov@mean_re) * (vector_one.T@inv_cov@esg_np) - (vector_one.T@inv_cov@vector_one) * (mean_re.T@inv_cov@esg_np) ) / ( (vector_one.T@inv_cov@esg_np)**2 - (vector_one.T@inv_cov@vector_one) * (esg_np.T@inv_cov@esg_np) ))
    gamma_1 = (mean_re.T@inv_cov@mean_re) + ( ((vector_one.T@inv_cov@mean_re)**2) * (esg_np.T@inv_cov@esg_np) + ((mean_re.T@inv_cov@esg_np)**2) * (vector_one.T@inv_cov@vector_one) - 2*(vector_one.T@inv_cov@mean_re)*(mean_re.T@inv_cov@esg_np)*(vector_one.T@inv_cov@esg_np) ) / ( ((vector_one.T@inv_cov@esg_np)**2) - (vector_one.T@inv_cov@vector_one)*(esg_np.T@inv_cov@esg_np)  )
    gamma_2 = ( (-esg_np.T @ inv_cov @ esg_np) + 2*threshold * (vector_one.T@inv_cov@esg_np)-(vector_one.T@inv_cov@vector_one) * threshold**2 ) / ( ((vector_one.T@inv_cov@esg_np)**2) - (vector_one.T@inv_cov@vector_one) * (esg_np.T@inv_cov@esg_np) )
    mvp_rating = (vector_one.T@inv_cov@esg_np) / (vector_one.T@inv_cov@vector_one)
    E_0 = 1 / (vector_one.T@inv_cov@vector_one) * (mean_re.T@inv_cov@vector_one + 1/lambda_0 * ((mean_re.T@inv_cov@mean_re)*(vector_one.T@inv_cov@vector_one)-(mean_re.T@inv_cov@vector_one)**2) )
    V_0 =  1 / (vector_one.T @ inv_cov @ vector_one)   * (1 + (1 /  (lambda_0**2))  * (( mean_re.T @ inv_cov @ mean_re ) * ( vector_one.T @ inv_cov @ vector_one) - (mean_re.T @ inv_cov @ vector_one)**2))
    #vol_0 = np.sqrt(V_0)

    output_str = [
        "Variable outputs used from the paper",
        "------------------------------------",
        f'the value of delta 0 is: {delta_0}\n',
        "-------------------------------------",
        f'Is delta 1 larger than zero: {delta_1 > 0}',
        "-------------------------------------",
        f'The value of delta 1 is: {delta_1}\n',
        "-------------------------------------",
        f"The value of Lambda 0 is: {lambda_0}\n",
        "-------------------------------------",
        f"The value of gamma 0 is: {gamma_0}\n",
        "-------------------------------------",
        f"The value of gamma 1 is: {gamma_1}\n",
        "-------------------------------------",
        f"The value of gamma 2 is: {gamma_2}\n",
        "--------------------------------------",
        f"Is MVP ESG rating higher than ESG threshold: {mvp_rating > threshold}",
        "--------------------------------------",
        f"the ESG score of the MVP is: {mvp_rating}\n",
        "--------------------------------------",
        f"the WA ESG score for traditional investor portfolios is: {phi_0}"
    ]
    print('\n'.join(output_str))
    return E_0, V_0