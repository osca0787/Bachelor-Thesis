import numpy as np
def w3(weight1,weight2,alpha):
  """Function that finds all the optimal weights of the efficient frontier

  Parameters
    ----------
  weight1 : list
    A list with the optimal weights of the first portfolio

  weight2 : list
    A list with the optimal weights of the second portfolio

  alpha : list
    A list with values that ranges from -x to x

  Returns
  -------
  weight3 : Numpy Array
    Returns a numpy array, which holds all the optimal portfolios for the efficient frontier
        
  """

  
  weight3 = []
  for i in alpha:
    weight3.append(i*weight1 + (1-i)*weight2)
  return np.array(weight3)