import pandas as pd
import numpy as np

def log_returns(stocks):
    """Function that computes the logarithmic returns of a list of stocks

    Parameters
    ----------
    Stocks : float
        Pandas Dataframe which contains the last price of a certain amount of stocks
    

    Returns
    -------
    Pandas Dataframe
        a Dataframe of the logarithmic return of each selected stock
    """
    # Dividing the log price of the current index by the log price of the previous log price
    return np.log(stocks / stocks.shift(axis=1))