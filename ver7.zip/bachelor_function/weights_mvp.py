def mvp_weights(a, b, c, d, inv_cov, vec_ones, mean_return, exp_return_1, exp_return_2):
    """Function that computes two optimal weights with different expected returns

    Parameters
    ----------

    a : float
        Scalar that is used to calculate the two optimal weights

    b : float
        Scalar that is used to calculate the two optimal weights

    c : float
        Scalar that is used to calculate the two optimal weights

    d : float
        Scalar that is used to calculate the two optimal weights

    inv_cov : Pandas Dataframe
        An inverse covariance matrix
    
    vec_ones : Numpy Array
        A numpy array vector of ones. Has the same length as mean_return 

    mean_return : Numpy Array
        A numpy array consisting of the mean return of some selected stocks

    exp_return_1 : float
        The expected return of the first optimal weight

    exp_return_2 : float
        The expected return of the second optimal weight
    

    Returns
    -------
    Scalar: float
        Returns two optimal weights with different expected return, which is located on the efficient frontier
        
    """


    g = 1/d*(b*inv_cov@vec_ones - a*inv_cov@mean_return)
    h = 1/d*(c*inv_cov@mean_return - a*inv_cov@vec_ones)
    weight_1 = g + h * exp_return_1
    weight_2 = g + h * exp_return_2
    return weight_1, weight_2


