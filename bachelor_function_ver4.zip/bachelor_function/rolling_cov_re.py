from covariance import cov_matrix
from mean_ret import mean_return
import numpy as np

def rolling_er_cov(stocks, window):
    rolling_er = []
    rolling_cov = []
    rolling_inv_cov = []
    for i in range(len(stocks) - window + 1):
        #rolling_er.append(mean_return(stocks[i:i+window]))
        #rolling_cov.append(cov_matrix(stocks[i:i+window]))
        rolling_er.append(mean_return(stocks[i:i+window]))
        rolling_cov.append(cov_matrix(stocks[i:i+window]))
        rolling_inv_cov.append(np.linalg.inv(cov_matrix(stocks[i:i+window])))
        
    return rolling_er, rolling_cov, rolling_inv_cov


