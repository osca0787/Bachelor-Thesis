import numpy as np
def exp_return(w, R):
  tmp_list = []
  for i in w:
    tmp_list.append(sum(i*R))
  return np.array(tmp_list)
