import numpy as np
def mvp_func(inv_cov, mean_return, vec_ones):
    a = vec_ones@inv_cov@mean_return
    # Now we calculate b: 
    b = mean_return.T@inv_cov@mean_return
    # c vector:
    c = vec_ones.T@inv_cov@vec_ones
    # Then d:
    d = b*c-a**2
    return a, b, c, d
