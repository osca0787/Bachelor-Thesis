import numpy as np
def vector_ones(labels):
    return np.ones(len(labels))