import numpy as np
def mvp_func(inv_cov : np.ndarray, mean_return : np.ndarray, vec_ones : np.ndarray):
    """Function that computes four auxiliary variables, which will help to compute the two optimal weights with different return

    Parameters
    ----------
    inv_cov : Numpy Array
        An inverse covariance matrix
    
    mean_return : Numpy Array
        a numpy array consisting of the mean return of some selected stocks

    vec_ones : Numpy Array
        a numpy array vector of ones. Has the same length as mean_return 
    

    Returns
    -------
    Scalar: float
        Returns four auxiliary variables with the data type float
        
    """
    if not all(isinstance(x, np.ndarray) for x in (inv_cov, mean_return, vec_ones)):
        raise TypeError("Input must be a Numpy Array.")
    
    else:

        if inv_cov.size == 0 or mean_return.size == 0 or vec_ones.size == 0:
            raise ValueError("One or more of the input parameters are empty")


        else:
                    #Calculate a
            a = vec_ones.T@inv_cov@mean_return
            # Now we calculate b: 
            b = mean_return.T@inv_cov@mean_return
            # c vector:
            c = vec_ones.T@inv_cov@vec_ones
            # Then d:
            d = b*c-a**2


            return a, b, c, d
