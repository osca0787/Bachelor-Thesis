import numpy as np
import pandas as pd
def get_scores(data_sample : pd.DataFrame):
    if not isinstance(data_sample, pd.DataFrame) :
        raise TypeError("Input must be a Pandas dataframe.")
    else:
        if data_sample.empty:
            raise ValueError('One or more parameters are empty')
        else:

            esg = data_sample['ESG']['ESG Score']
            esg_np = esg.to_numpy()
            e = data_sample['Environmental']['Environmental Score']
            e_np = e.to_numpy()
            s = data_sample['Social']['Social Score']
            s_np = s.to_numpy()
            g = data_sample['Governance']['Governance Score']
            g_np = g.to_numpy()
            return esg_np, e_np, s_np, g_np
