import pandas as pd

import numpy as np
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller
from scipy.stats import anderson

from scipy.stats import chi2, f

from linearmodels.panel import compare


from statsmodels.compat import lzip

from statsmodels.stats.diagnostic import normal_ad

import matplotlib.pyplot as plt

import scipy.stats as st





#%% Augmented Dickey-Fuller test

def ADF(ADF_data, df_endo):
    """
    Compute the Augmented Dickey-Fuller test.

    Parameters:
        - ADF_data (dict): Dictionary of data.
        - df_endo (DataFrame): DataFrame with explanatory variable.

    Returns:
        - ADF test results (tuple): A tuple containing the following elements:
            - test_statistic (float): The test statistic value.
            - p_value (float): The p-value associated with the test statistic.
            - critical_values (dict): A dictionary of critical values at different confidence levels.
   """


    df_adf = pd.DataFrame(ADF_data)

    # Perform the ADF test on each column
    for column in df_adf.columns:
        result = adfuller(df_adf[column])
        print(f"ADF Test Results for {column}:")
        print(f"Test Statistic: {result[0]}")
        print(f"P-value: {result[1]}")
        print(f"Critical Values:")
        for key, value in result[4].items():
            print(f"  {key}: {value}")
        print("------------------------")
        
    #Perfrom ADF again to extract p-value and statistics
    ret_ADF = adfuller(df_endo)

    test_statistic = ret_ADF[0]
    p_value = ret_ADF[1]
    
    return(print(f"Test Statistic: {test_statistic}"),
        print(f"P-value: {p_value}") )
#%%
def Anderson_Darling(model):
    """
    Perform the Anderson-Darling test for normality on model residuals.

    Inputs:
        - model: The regression model results (statsmodels.regression.linear_model.OLSResults)

    Outputs:
        - result: the Anderson-Darling test results (scipy.stats.anderson) with the following elements:
            - Anderson-Darling test statistic
            - Critical value for the given distribution
            - significance leve for corresponding critical values in precent
    """  
    # Assuming you have the residuals of the FE model stored in a variable called 'residuals'
# 'residuals' should be a 1-dimensional NumPy array or a pandas Series

    # Perform the Anderson-Darling test
    result = anderson(model.resid, dist='norm')

    # Extract the test statistic and critical values
    test_statistic = result.statistic
    critical_values = result.critical_values

    # Print the test statistic and critical values
    print("Anderson-Darling Test Statistic: ", test_statistic)
    print("Critical Values:")
    for i, crit_val in enumerate(critical_values):
        print(f"Level {result.significance_level[i]}: {crit_val}")

    # Determine whether the residuals are normally distributed based on the test statistic and critical values
    if test_statistic > critical_values[2]:
        print("Reject the null hypothesis: Residuals are not normally distributed.")
    else:
        print("Fail to reject the null hypothesis: Residuals are normally distributed.")
    
#%% LM test
    
def LM_test(model_reg, name:str):
    """
    Perform the LM test for heteroscedasticity on model residuals.

    Inputs:
        - model_reg: the regression model object from statmodels
        - name: the name of the model

    Outputs:
        - LM test result (stats.diagnostic.linear_lm) with the following elements:
            - Lagrange Multiplier test statistic
            - p-value of Lagrange Multiplier test
            - results from the F test variant
    """
    
    LM = sm.stats.diagnostic.linear_lm(model_reg.resid, model_reg.model.exog)
    return print('LM test for:', name, LM)

#%% F-test

def f_test_sm(model1, name1:str, model2, name2:str):
    """
    Perform the F-test to compare two models.

    Inputs:
        - model1: the first regression model object from statmodels
        - name1: the name of the first model
        - model2: the second regression model object from statmodels
        - name2: the name of the second model

    Outputs:
        - F-test result with the following elements:
            - print statement of which model is the significant compared to the other model based
              on p-value andsignificance level
            - p-value
            - F-statistic
    """
    # Perform the F-test
    f_test_result = model1.compare_f_test(model2)
    
    # Extract the F-statistic and p-value
    f_statistic = f_test_result[0]
    p_value = f_test_result[1]
    
    significance_level = 0.05
    
    if p_value < significance_level:
        print(f"Reject the null hypothesis: {name1} provides a statistically significant improvement over {name2}.")
        print("p-value:", p_value)
        print("F-statistic:", f_statistic)
    else:
        print(f"Fail to reject the null hypothesis: {name1}is not significantly different from {name2}.")
        print("p-value:", p_value)
        print("F-statistic:", f_statistic)

        
        
#%% Breusch-Pagan test

def BreuschPagan(reg_model):
    """
    Perform the Breusch-Pagan test for heteroscedasticity.

    Inputs:
        - reg_model: the regression model object from statsmodels

    Outputs:
        - Breusch-Pagan test results (statsmodels.stats.diagnostic.het_breuschpagan) with the following elememts:
            - Lagrange Multiplier statistic
            - p-value of lagrange multiplier test
            - f-statistic of the hypothesis that the error variance does not depend on x
            - p-value for the f-statistic
    """
    breusch_pagan_test = sm.stats.diagnostic.het_breuschpagan(reg_model.resid, reg_model.model.exog)
    labels = ['LM Statistic', 'LM-Test p-value', 'F-Statistic', 'F-Test p-value']
    return print(lzip(labels, breusch_pagan_test))


#%%Hausman Test



#%% Hausman test

def hausman_test(fe_model, re_model, lin:True):
    """
    Compute the Hausman test for the difference between fixed effects and random effects estimators.
    Inputs:
        - fe_model: model regression results from linearmodel
        - re_model model regression results from statsmodels
        - beta_fe: an array of fixed effects coefficients
        - vcov_fe: the covariance matrix of the fixed effects estimator
        - beta_re: an array of random effects coefficients
        - vcov_re: the covariance matrix of the random effects estimator
    Outputs:
        - hausman_stat: the test statistic for the Hausman test
        - p_value: the p-value for the test statistic
    """
    if lin == True:
        beta_fe = fe_model.params.values
        vcov_fe = (fe_model.cov).to_numpy()
        beta_re = re_model.params.values
        vcov_re = (re_model.cov_params()).to_numpy()
        
        # Compute the difference between the fixed effects and random effects estimators
        beta_diff = beta_fe - beta_re

        # Compute the variance-covariance matrix of the difference
        vcov_diff = vcov_fe - vcov_re

        # Compute the test statistic
        hausman_stat = np.dot(beta_diff, np.linalg.inv(vcov_diff)).dot(beta_diff)
        dof = beta_diff.shape[0]  # degrees of freedom
        p_value = 1 - chi2.cdf(hausman_stat, dof)

        return hausman_stat, dof, p_value

    else:
        beta_fe, vcov_fe = fe_model.params.values, fe_model.cov_params().values
        beta_re, vcov_re = re_model.params.values, re_model.cov_params().values

        n_fe_params = beta_fe.shape[0]
        n_re_params = beta_re.shape[0]

        beta_diff = beta_fe[:n_re_params] - beta_re
        vcov_diff = vcov_fe[:n_re_params, :n_re_params] - vcov_re

        hausman_stat = np.dot(beta_diff, np.linalg.inv(vcov_diff)).dot(beta_diff)
        dof = n_re_params
        p_value = 1 - chi2.cdf(hausman_stat, dof)
        return hausman_stat, dof, p_value
    
    
#%% QQ plot   
def QQ_plot(list_residuals, name_list):
    """
    Perform plot of QQ plot to check normality.

    Inputs:
        - list_residuals: list of residuals from a regression result
        - list of names accordingly to the explanatory variables

    Outputs:
        - Plot of residuals vs. normal distribution
    """
    residuals_list = list_residuals  # List of residuals for different plots
    names = name_list  # List of names for the plots

    fig, axes = plt.subplots(1, len(residuals_list), figsize=(15, 5))

    for residuals, name, ax in zip(residuals_list, names, axes):
        ax.set_title(f'QQ Plot {name}')
        sm.qqplot(residuals, line='45', fit=True, ax=ax)

    plt.tight_layout()
    plt.show()
#%% Breusch-Godfrey test

def Breusch_Godfrey(model, lags):
    """
    Perform the Breusch-Godfrey test for autocorrelation.

    Inputs:
        - reg_model: the regression model object from statsmodels

    Outputs:
        - Breusch-Pagan test results (statsmodels.stats.diagnostic.het_breusch_godfrey) with the following elememts:
            - Lagrange Multiplier statistic
            - p-value of lagrange multiplier test
            - F-statistic of the hypothesis that the error variance does not depend on x
            - p-value for the f-statistic
    """
    results = sm.stats.diagnostic.acorr_breusch_godfrey(model, nlags= lags)
    return results

#%% Variance Inflation Factor
    
def variance_inflation_factor(exog):
    '''
    Parameters
    ----------
    exog : pandas dataframe,
        dataframe with all explanatory variables, as used in
        regression.

    Returns
    -------
    VIF : Series
        variance inflation factors
    '''
    exog = sm.add_constant(exog)
    vifs = pd.Series(
        [1 / (1. - sm.OLS(exog[col].values, exog.loc[:, exog.columns != col].values).fit().rsquared) 
         for col in exog],
        index=exog.columns,
        name='VIF'
    )
    return vifs

#%% Wooldridge Score Test
def Wool_test(data_exog ,df_all, fe_formula_depend:str, fe_formula_exog_with_lag:list, aux_lag_formula:list, w_start:int, w_end:int):
    """
    Perform the Wooldridge Score test.

    Inputs:
        - data_exog: Dataframe with explanatory variables
        - df_all: Dateframe for the whole model
        - fe_formula_depend: Define the formula for the regression for dependent variable as a string
        - fe_formula_exog_with_lag: Define the formula for the regression for explanatory variable with lags as list
        - aux_lag_formula: Define the formula for the auxilliary model as list
        - w_start: Start value for slicing datasample to sub-sample as integer
        - w_end: End value for slicing datasample to sub-sample as integer

    Outputs:
        - Breusch-Pagan test results (statsmodels.stats.diagnostic.het_breusch_godfrey) with the following elememts:
            - Lagrange Multiplier statistic
            - p-value of lagrange multiplier test
    """
    
    # Subsample and leading one
    lagged_vars = data_exog.iloc[w_start:w_end:].shift(1)

    # Rename the lagged variables with a suffix to indicate the lag
    lagged_vars.columns = [col + '_lag1' for col in lagged_vars.columns]

    df_lagged = pd.DataFrame()
    # Combine the original variables and lagged variables into a new DataFrame
    df_lagged = pd.concat([df_all, lagged_vars], axis=1).dropna()
    
    # formula_fe = 'Return ~ E_Score , S_Score , G_Score , E_Score_lag1 , S_Score_lag1 , G_Score_lag1 '
    fe_model = sm.OLS(df_lagged[fe_formula_depend], df_lagged[fe_formula_exog_with_lag]).fit()

    residuals_fe = fe_model.resid

    # auxilliary formula = 'residuals_fe ~ lagged_x_subset'
    aux_model = sm.OLS(residuals_fe, df_lagged[aux_lag_formula]).fit()

    n = len(df_lagged[fe_formula_depend])  # Number of observations
    k = len(df_lagged[fe_formula_exog_with_lag].columns)  # Number of independent variables
    df_num = k
    df_denom = n - k
 

    lm_statistic = aux_model.rsquared * len(df_lagged)
    p_value = 1 - chi2.cdf(lm_statistic, df_num, df_denom)  # Degrees of freedom: 1

    print("Wooldridge Score Test Results:")
    print("LM Statistic:", lm_statistic)
    print("P-value:", p_value)