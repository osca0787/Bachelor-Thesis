import ipywidgets as widgets
from IPython.display import display
import pandas as pd
import numpy as np
def create_portfolio1(dataframe : pd.DataFrame):
    """
    Function to interactively create a portfolio of stocks from a DataFrame.

    Parameters:
        dataframe : Pandas Dataframe
            DataFrame containing stock tickers, last prices, and ESG scores.

    Returns:
        pd.DataFrame: DataFrame containing selected stocks with their respective variables and scores.
    """

    # Creating a copy of the input stock DataFrame to avoid modifying the original data
    stock_data_copy = dataframe.copy()

    # Creating an empty DataFrame to store selected stocks in
    portfolio = pd.DataFrame(columns=dataframe.columns)

    ticker_list = list(dataframe.index)

    # Create widgets for user input
    num_stocks_widget = widgets.IntSlider(
        value=1,
        min=1,
        max=len(dataframe),
        step=1,
        description='Number of stocks:',
        continuous_update=False
    )

    stock_dropdown_widget = widgets.Dropdown(
        options=ticker_list,
        description='Stocks:',
        continuous_update=False,
        layout=widgets.Layout(width='300px')
    )
    add_button = widgets.Button(description='Add stock')
    exit_button = widgets.Button(description='Exit')
    output = widgets.Output()

    def add_stock(button):
        nonlocal stock_data_copy, portfolio, ticker_list

        stock_ticker = stock_dropdown_widget.value

        if stock_ticker in portfolio.index:
            print(f"Stock {stock_ticker} is already placed in your portfolio. Please choose another stock")
        elif len(portfolio) >= num_stocks_widget.value:
            confirm_widget = widgets.Dropdown(
                options=[('Yes', True), ('No', False)],
                value=False,
                description='Do you want to update the number of stocks?',
                layout=widgets.Layout(width='200px')
            )
            display(confirm_widget)

            def handle_confirm(change):
                if change['new']:
                    new_num_stocks_widget = widgets.IntText(value=len(portfolio), description='New number of stocks:')
                    display(new_num_stocks_widget)

                    def update_num_stocks(button):
                        new_num_stocks = new_num_stocks_widget.value
                        if new_num_stocks > len(portfolio):
                            num_stocks_widget.value = new_num_stocks
                            print("Number of stocks updated. You can now add the stock to your portfolio.")
                        else:
                            print("Invalid input. Number of stocks should be greater than the current portfolio size.")

                    update_button = widgets.Button(description='Update')
                    display(update_button)
                    update_button.on_click(update_num_stocks)
                else:
                    print("You have chosen not to update the number of stocks. Portfolio remains unchanged.")

            confirm_widget.observe(handle_confirm, names='value')
        else:
            stock_data = dataframe.loc[stock_ticker]
            portfolio.loc[stock_ticker] = stock_data
            print(f"Stock {stock_ticker} has been added to your portfolio")

        if stock_ticker in ticker_list:
            ticker_list.remove(stock_ticker)
            stock_dropdown_widget.options = ticker_list

    def exit(button):
        display(portfolio)
        return

    # Creating a reset button, from which the user can clear the portfolio
    reset_button = widgets.Button(description='Reset portfolio')
    reset_output = widgets.Output()

    def reset_portfolio(button):
        nonlocal stock_data_copy, portfolio

        # Clearing the portfolio and resetting the dropdown menu options
        portfolio = pd.DataFrame(columns=dataframe.columns)
        stock_data_copy = dataframe.copy()
        stock_dropdown_widget.options = dataframe.index

        # Clear the output
        with reset_output:
            print("Your portfolio has been reset.")
            display(pd.DataFrame())

    # Adding the reset button
    reset_button.on_click(reset_portfolio)

    # ESG Threshold widget
    esg_threshold_widget = widgets.FloatSlider(
        value=dataframe['ESG']['ESG Score'].min(),
        min=dataframe['ESG']['ESG Score'].min(),
        max=dataframe['ESG']['ESG Score'].max(),
        step=0.01,
        description='ESG Threshold:',
        continuous_update=False
    )
    esg_output = widgets.Output()

    def handle_esg_threshold(change):
        filtered_tickers = dataframe[dataframe['ESG']['ESG Score'] >= esg_threshold_widget.value].index
        stock_dropdown_widget.options = filtered_tickers

    esg_threshold_widget.observe(handle_esg_threshold, names='value')

    # Assign event handlers to buttons
    add_button.on_click(add_stock)
    exit_button.on_click(exit)

    # Display widgets
    display(num_stocks_widget)
    display(esg_output)
    with esg_output:
        display(esg_threshold_widget)
    display(stock_dropdown_widget)
    display(add_button)
    display(exit_button)
    display(reset_button)
    display(reset_output)

    return portfolio