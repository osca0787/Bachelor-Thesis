import pandas as pd
import numpy as np
import plotly
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import plotly.figure_factory as ff
from plotly.subplots import make_subplots
import ipywidgets as widgets
from IPython.display import display
import yfinance as yf
import dash
from dash import dcc
from dash import html
import matplotlib.pyplot as plt

DEBUG = False

def calculate_fundemental_functions(Portfolio : pd.DataFrame):

    #Importing module log_return
    import log_return

    #Calculating logarithmic return for the data sample
    logarithmic_return = log_return.log_returns(Portfolio['Adj Close'])


    #Importing module fetch_score
    from fetch_score import get_scores

    #Fetching ESG, E, S and G score from the data sample and storing them in a numpy array
    esg_np, e_np, s_np, g_np = get_scores(Portfolio)


    #Importing module covariance
    from covariance import cov_matrix

    #Calculating the covariance-variance matrix
    covariance_matrix = cov_matrix(logarithmic_return)

    #Computing the inverse covariance-variance matrix
    inverse_covariance_matrix = np.linalg.inv(covariance_matrix)


    #Importing module mean_ret
    from mean_ret import mean_return
    mean_return_of_stocks = mean_return(logarithmic_return)
    
    #Importing module esg_indicators
    from esg_indicators import indicators

    #Importing module vector_ones
    from ones import vector_ones

    #Computing a vector of ones    
    vector_of_ones = vector_ones(Portfolio)

    #Calculating trade-off between risk aversion and ESG Score
    delta_1, mvp_rating = indicators(vector_of_ones, inverse_covariance_matrix, mean_return_of_stocks, esg_np)
    #print(indicator)

    return logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks, delta_1, mvp_rating

def calculate_esg_investor_types(portfolio : pd.DataFrame, log_return : pd.DataFrame, covariance_matrix : np.ndarray, inverse_covariance_matrix : np.ndarray, mean_return_of_stocks : np.ndarray, esg_score : np.ndarray, e_score : np.ndarray, s_score : np.ndarray, g_score : np.ndarray, risk_free_rate : float, esg_threshold : float):
   
    #Importing module vector_ones
    from ones import vector_ones

    #Computing a vector of ones    
    vector_of_ones = vector_ones(portfolio)

    #Importing module mvp_func
    from mvp import mvp_func

    #Calculating auxilirairy variables used to calculate the two optimal portfolios
    a, b, c, d = mvp_func(inverse_covariance_matrix, mean_return_of_stocks, vector_of_ones)


    #Importing module weights_mvp
    from weights_mvp import mvp_weights

    #Calculating two optimal portfolios with different expected return
    w1, w2 = mvp_weights(a, b, c, d, inverse_covariance_matrix, vector_of_ones, mean_return_of_stocks, 0.10, 0.26)
    if DEBUG:
        print(w1)


    #Importing module alpha
    from alpha import alpha 

    #Constructing a list from -3.5 to 3.5
    alpha_list = alpha([-3.5])

    #Importing module two_fun_theorem
    from two_fun_theorem import w3

    #Calculating the optimal portfolios for the ESG insensitive investor
    efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive = w3(w1, w2, alpha_list, mean_return_of_stocks, covariance_matrix, esg_score)


    #Constructing a tickerslist
    tickers_list = []
    labels = log_return.columns
    for i in range(len(efficient_frontier_weights_insensitive)):
        #assets = np.random.choice(list(labels), len(labels), replace=False)
        assets = list(labels)
        tickers_list.append(assets)
    sr_t_list = list(labels)


    #Importing module global_mvp
    from global_mvp import global_mvp

    #Computing the global minimum variance portfolio
    mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score = global_mvp(efficient_frontier_weights_insensitive, volatility_insensitive, mean_return_of_stocks, covariance_matrix, esg_score, e_score, s_score, g_score)

    #Importing module calculating_max_sr
    from calculating_max_sr import calculate_max_sharpe_ratio

    #Calculating maximum Sharpe Ratio Portfolio
    sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score = calculate_max_sharpe_ratio(risk_free_rate, mean_return_of_stocks,  covariance_matrix, esg_score, e_score, s_score, g_score, mvp_weight, log_return.columns.tolist())


    #importing module calculating_max_sortino
    from calculating_max_sortino import calculate_sortino_ratio
    optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score = calculate_sortino_ratio(log_return, risk_free_rate, log_return.columns.tolist(), mvp_weight, mean_return_of_stocks, covariance_matrix, esg_score, e_score, s_score, g_score)


    #Importing module esg_investor_weights
    from esg_investor_weights import calculate_esg_sensitive_investor

    #Calculating the optimal portfolio for the ESG sensitive investor
    list_target_returns = np.arange(expected_return_insensitive.min(), expected_return_insensitive.max(), 0.0016).tolist()
    esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa  = calculate_esg_sensitive_investor(mean_return_of_stocks, covariance_matrix, esg_score, esg_threshold, list_target_returns, mvp_weight)


    #Importing moduel calculating_max_ESG_sr
    from calculating_max_ESG_sr import calculate_max_ESG_sharpe_ratio
    sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score = calculate_max_ESG_sharpe_ratio(risk_free_rate, mean_return_of_stocks, covariance_matrix, esg_score, e_score, s_score, g_score, mvp_weight, log_return.columns.tolist(), esg_threshold)
    print(sr_esg)

    #Importing module calculate_max_ESG_sortino
    from calculate_max_ESG_sortino import calculate_ESG_sortino_ratio
    optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg = calculate_ESG_sortino_ratio(log_return, risk_free_rate, log_return.columns.tolist(), mvp_weight, mean_return_of_stocks, covariance_matrix, esg_score, e_score, s_score, g_score, esg_threshold)


    #Returning everything
    return efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, labels, tickers_list, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg



def plot_efficient_frontiers(efficient_frontier_weights_insensitive, expected_return_insensitive, volatility_insensitive, weighted_average_esg_score_insensitive, sr_t_list,  mvp_weight, mvp_er, mvp_vol, mvp_esg_score, mvp_e_score, mvp_s_score, mvp_g_score, sr, w_opt, sharpe_exp, sharpe_vol, sr_esg_score, sr_e_score, sr_s_score, sr_g_score, optimal_weights, optimal_sortino_ratio, sortino_exp, sortino_vol, sortino_score, sortino_e_score, sortino_s_score, sortino_g_score, esg_investor_weights, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa, sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score, optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg, tickers_list):


    #Importing module 
    from plot_ef import ef_plot

    #Plotting the efficient frontiers with optimal sharpe ratio portfolio
    plot_efficient_frontiers_with_sharpe = ef_plot(tickers_list, sr_t_list, 
            efficient_frontier_weights_insensitive, volatility_insensitive, expected_return_insensitive, weighted_average_esg_score_insensitive, 
            esg_investor_weights, esg_portfolio_vol, esg_portfolio_returns, esg_investor_wa, 
            w_opt, sharpe_vol, sharpe_exp, sr, sr_esg_score,
            w_opt_esg, sharpe_vol_esg, sharpe_exp_esg, sr_esg, sr_esg_esg_score,
            mvp_weight, mvp_vol, mvp_er, mvp_esg_score, 
            optimal_weights, sortino_vol, sortino_exp, optimal_sortino_ratio, sortino_score,
            optimal_weights_esg, sortino_vol, sortino_exp_esg, optimal_sortino_ratio_esg, sortino_score_esg,
            ratio='Sharpe Ratio')
    
    #Plotting the efficient frontiers with optimal sortino ratio portfolio
    plot_efficient_frontiers_with_sortino = ef_plot(tickers_list, sr_t_list, 
            efficient_frontier_weights_insensitive, volatility_insensitive, expected_return_insensitive, weighted_average_esg_score_insensitive, 
            esg_investor_weights, esg_portfolio_vol, esg_portfolio_returns, esg_investor_wa, 
            w_opt, sharpe_vol, sharpe_exp, sr, sr_esg_score,
            w_opt_esg, sharpe_vol_esg, sharpe_exp_esg, sr_esg, sr_esg_score,
            mvp_weight, mvp_vol, mvp_er, mvp_esg_score, 
            optimal_weights, sortino_vol, sortino_exp, optimal_sortino_ratio, sortino_score,
            optimal_weights_esg, sortino_vol_esg, sortino_exp_esg, optimal_sortino_ratio_esg, sortino_score_esg,
            ratio='Sortino Ratio')
    
    return plot_efficient_frontiers_with_sharpe, plot_efficient_frontiers_with_sortino


def risk_for_investor_types(portfolio : pd.DataFrame, weights : np.ndarray, alpha : float, lookback_days : int):

    #Importing module log_return
    import log_return

    #Calculating logarithmic return for the data sample
    logarithmic_return_daily = log_return.log_returns(portfolio['Adj Close Daily'])

    demeand_log_returns = logarithmic_return_daily - logarithmic_return_daily.mean(skipna=True)
    
    from calculate_CvaR import plot_var_cvar_histogram
    plot = plot_var_cvar_histogram(demeand_log_returns, weights, alpha, lookback_days)


    return plot

def portfolio_performance(portfolio : pd.DataFrame, lookback_years : int, daily_returns_log, weights_insensitive : np.ndarray, weights_sensitive : np.ndarray, benchmark : pd.DataFrame, risk_free_rate : float):
    from treynor import calculate_treynor
    jensens_alpha_insensitive, beta_insensitive,timing_insensitive = calculate_treynor(lookback_years, daily_returns_log, weights_insensitive, benchmark, risk_free_rate)

    jensens_alpha_sensitive, beta_sensitive,timing_sensitive = calculate_treynor(lookback_years, daily_returns_log, weights_sensitive, benchmark, risk_free_rate)

    portfolio_returns_insensitive = portfolio['Adj Close'].T.iloc[-lookback_years:].dot(weights_insensitive)

    portfolio_returns_sensitive = portfolio['Adj Close'].T.iloc[-lookback_years:].dot(weights_sensitive)


    fig = go.Figure()
    fig.add_trace(go.Scatter(x=portfolio_returns_insensitive.index, y=portfolio_returns_insensitive.values, mode='lines', name='Tangency Portfolio'))
    fig.add_trace(go.Scatter(x=portfolio_returns_sensitive.index, y=portfolio_returns_sensitive.values, mode='lines', name='Your ESG Tangency Portfolio'))


    #return fig, jensens_alpha_insensitive, beta_insensitive,timing_insensitive, jensens_alpha_sensitive, beta_sensitive,timing_sensitive
    return fig, jensens_alpha_insensitive, beta_insensitive,timing_insensitive, jensens_alpha_sensitive, beta_sensitive,timing_sensitive