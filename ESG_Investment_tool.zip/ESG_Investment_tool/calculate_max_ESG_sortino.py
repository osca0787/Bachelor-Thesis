from scipy.optimize import minimize
import numpy as np
import pandas as pd
def calculate_ESG_sortino_ratio(returns : pd.DataFrame, risk_free_rate : float, labels : list, guess : np.ndarray, mean_ret : np.ndarray, covar : np.ndarray, esg_score : np.ndarray, e_scores : np.ndarray, s_scores : np.ndarray, g_scores : np.ndarray, esg_threshold : float):

    """Function that calculates the optimal ESG Sortino Ratio and calculates its weights, Expected return, volatility and ESG, E, S and G scores

    Parameters
    ----------

    returns : Pandas DataFrame
        A Dataframe containing the logarithmic returns for each stock

    risk_free_rate : float
        a float that refers to the rate of return an investor expects to earn on a zero risk asset    
  
    labels : Numpy Array
        used to set the bounds fot each weight in the portfolio

    guess : Numpy Array
        an array consiting of portfolio weights, that serves as a intial guess
  
    mean_ret : Numpy Array
        Numpy array of mean returns for each stock

    cov_var : Pandas Dataframe
        Covariance-variance matrix for the stocks

    esg_score : Numpy Array
        an array consiting of each stocks ESG score

    e_score : Numpy Array
        an array consiting of each stocks E score

    s_score : Numpy Array
        an array consiting of each stocks S score

    g_score : Numpy Array
        an array consiting of each stocks G score

    esg_threshold : Float
        a float, which represents the ESG threshold the investor desires
    

    Returns
    ------
        Tuple
        Returns the Max ESG Sortino Ratio, its weights, expected return, volatility and WA ESG, E, S and G score.
        """    
    if not  all(isinstance(i, (np.ndarray)) for i in (mean_ret, covar, esg_score, e_scores, s_scores, g_scores, guess)) or not isinstance(returns, pd.DataFrame) or not isinstance(labels, list) or not isinstance(risk_free_rate, float) or not isinstance(esg_threshold, float):
            raise TypeError("Input must correct data types")
        
    else:

            if mean_ret.size == 0 or covar.size == 0 or esg_score.size == 0 or e_scores.size == 0 or s_scores.size == 0 or g_scores.size == 0 or guess.size == 0 or len(labels) == 0 or returns.empty:
                raise ValueError("One or more of the input parameters are empty")


            else:

                #Defining helper function to calculate the sortino ratio
                def sortino_ratio(weights):
                    #Calculating the portfolio return
                    portfolio_return = np.dot(returns.mean(), weights)
                    #Finding the downside returns: negative returns
                    downside_returns = returns[returns<0]

                    #Calculating the downside risk
                    downside_risk = np.sqrt(np.mean(np.square(downside_returns)))

                    #Sortino ratio, which needs to be minimized
                    sortino_ratio = (portfolio_return - risk_free_rate) / downside_risk
                    return -1*sortino_ratio
                
                #Function to make sure, that the weights sum to one
                def checkSumToOne(x):
                    return np.sum(x)-1

                #Defining the ESG constraint, such that the Optimal Sortino portfolio has a higher weighted average ESG score, than the threshold
                def esg_constraint(x):
                    esg_product = np.dot(x, esg_score)
                    return esg_product - esg_threshold

                #Setting the bounds for the weights. Shorting is allowed
                constraintSet = (-1, 1)
                bounds = tuple(constraintSet for asset in range(len(labels)))

                #Defining the constraints of the minimization problem
                constraints_esg = [{'type':'eq', 'fun':checkSumToOne},
                                {'type': 'ineq', 'fun': esg_constraint}]
                
                #Calculating the weights for the optimal Sortino portfolio
                w_opt_esg = minimize(sortino_ratio, guess, method='SLSQP',
                                bounds=bounds, constraints=constraints_esg)
                
                #Obtaining the optimal weights
                optimal_weights_esg = w_opt_esg.x

                #The optimal sortino ratio
                optimal_sortino_ratio_esg = -w_opt_esg.fun


                #Calculating the expected return and volatility
                sortino_exp_esg = optimal_weights_esg@mean_ret
                sortino_vol_esg = np.sqrt(optimal_weights_esg@covar@optimal_weights_esg)

                #Calculating weighted average ESG, E, S and G score for the portfolio
                sortino_score_esg = optimal_weights_esg@esg_score
                sortino_e_score_esg = optimal_weights_esg@e_scores
                sortino_s_score_esg = optimal_weights_esg@s_scores
                sortino_g_score_esg = optimal_weights_esg@g_scores


                return optimal_weights_esg, optimal_sortino_ratio_esg, sortino_exp_esg, sortino_vol_esg, sortino_score_esg, sortino_e_score_esg, sortino_s_score_esg, sortino_g_score_esg
