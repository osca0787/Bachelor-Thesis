import subprocess

def install_libraries():
    libraries = ['numpy', 'pandas', 'plotly', 'dash', 'matplotlib', 'ipywidgets', 'IPython', 'scipy', 'joblib', 'dash_core_components', 'dash_html_components', 'dash_bootstrap_components', 'sklearn', 'statsmodels', 'linearmodels', 'seaborn','scipy.optimize' ]  # List of libraries to install
    
    for library in libraries:
        try:
            subprocess.check_call(['pip', 'install', library])  # Use 'pip' or 'pip3' to install the library
            print(f'Successfully installed {library}')
        except subprocess.CalledProcessError as e:
            print(f'Failed to install {library}: {e}')
        
if __name__ == '__main__':
    install_libraries()