import numpy as np
from expected_return import exp_return
from variance import var_portfolio
from volatility import volatility
def w3(weight1 : np.ndarray, weight2 : np.ndarray, alpha : list, mean_return : np.ndarray, cov_matrix : np.ndarray, scores : np.ndarray):
  """Function that finds all the optimal weights of the efficient frontier

  Parameters
    ----------
  weight1 : Numpy array
    A list with the optimal weights of the first portfolio

  weight2 : Numpy array 
    A list with the optimal weights of the second portfolio

  alpha : list
    A list with values that ranges from -x to x

  mean_return : Numpy Array
    A numpy array containing mean returns of certain stocks

  cov_matrix : Numpy Array
    A numpy array containg covariance variance matrix of certain stocks

  
  scores : Numpy Array
    A numpy array containing ESG scores of certain stocks 

  Returns
  -------
  weight3 : Numpy array
    Returns a numpy array, which holds all the optimal portfolios for the efficient frontier, and a list of expected returns and volatilities for each portfolio
        
  """
  if not  all(isinstance(i, (np.ndarray)) for i in (weight1, weight2, mean_return, cov_matrix, scores)) or not isinstance(alpha, list):
            raise TypeError("Input must correct data types")
        
  else:

            if weight1.size == 0 or weight2.size == 0 or mean_return.size == 0 or cov_matrix.size == 0 or scores.size == 0 or len(alpha) == 0:
                raise ValueError("One or more of the input parameters are empty")


            else:


              weight3 = []
              for i in alpha:
                weight3.append(i*weight1 + (1-i)*weight2)
              weight3 = np.array(weight3)

              portfolio_expected_return = exp_return(weight3, mean_return)
              portfolio_variance = var_portfolio(weight3, cov_matrix)
              portfolio_volatility = volatility(portfolio_variance)
              portfolio_score = np.dot(weight3, scores)
              return weight3, portfolio_expected_return, portfolio_volatility, portfolio_score

