import numpy as np
import pandas as pd
def vector_ones(df : pd.DataFrame):
    """Function that creates a numpy array of ones

    Parameters
    ----------
    labels : str
        Pandas Dataframe which contains the tickers (index) of a selected amount of stocks
    

    Returns
    -------
    Numpy Array
        A vector of ones, which is the same length as the Pandas Dataframe of tickers.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError("Input must be a DataFrame.")
    
    else:

        if df.empty:
            print("Dataframe is empty")


        else:
                labels = df.index

                return np.ones(len(labels))