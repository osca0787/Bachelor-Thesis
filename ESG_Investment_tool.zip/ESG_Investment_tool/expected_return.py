import numpy as np
def exp_return(w : np.ndarray, R : np.ndarray):
  """Function that computes the expected return of a portfolio

  Parameters
  ----------
  w : Numpy Array
      A numpy array of the portfolios weights

  R : Numpy Array
      A numpy array consiting of each stocks mean return

  

  Returns
  ------
    exp_return_list : Numpy Array
        Returns a numpy array of each portfolios expected return 
  """
  
  if not all(isinstance(x, np.ndarray) for x in (w, R)):
            raise TypeError("Input must be a Numpy Array and exp_return_1, exp_return_2 must be float or int.")
  
  else:
        if w.size == 0 or R.size == 0:
          raise ValueError("One or more of the input parameters are empty")
        
        
        else:

          exp_return_list = []
          #Looping through each portfolios weight in the weight list
          for i in range(len(w)):
            #Computing the expected return for each portfolio
            expected_return = w[i].T @ R 
            exp_return_list.append(expected_return)
          return np.array(exp_return_list)
