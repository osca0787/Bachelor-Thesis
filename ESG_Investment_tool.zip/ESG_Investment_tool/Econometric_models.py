import pandas as pd
import numpy as np

import statsmodels.api as sm
import statsmodels.formula.api as smf
from linearmodels.panel import compare
from linearmodels import PanelOLS

import seaborn as sns
import math

#%%

def POLS_reg(endog, exog, summary:True):
    """
    Performs Pooled OLS model with statmodels 
    Inputs:
        - endog: endogenous variable as a dataframe 
        - exog: exogenous variable as a dataframe 
        - multi_df: dataframe must be a multiindex with entity identifier as first level and time as second level
        - Summary: boolean to print results with summary or without
    Outputs:
        - Fixed effect model (statsmodels.regression.linear_model.OLSResults)
    """        
    #setting up variables
    y_pols = endog
    X_pols = exog
    
    #Adding constnt
    X_pols = sm.add_constant(X_pols)
    #Running Regression
    pols_ret = sm.OLS(y_pols, X_pols).fit()
    
    #Whether or not results should be with summary or not
    if summary == True:
        return pols_ret.summary()
    else:
        return pols_ret
    
#%%
def fixedEffect(endog, exog, multi_df, summary:True):
    """
    Performs Fixed effect model with statmodels 
    Inputs:
        - endog: endogenous variable as a dataframe 
        - exog: exogenous variable as a dataframe 
        - multi_df: dataframe must be a multiindex with entity identifier as first level and time as second level
    Outputs:
        - Fixed effect model (statsmodels.regression.linear_model.OLSResults)
    """    
    y = endog
    x = exog
    
    #adding constant for intercept
    x = sm.add_constant(x)
    
    #Setting up dummy variables to add entity fixed effects
    entity_dummies = pd.get_dummies(multi_df.index.get_level_values('port_id'), drop_first=True, prefix='port').astype(int)
    
    #Concatinating dummies to df
    x_fe_dum = pd.concat([x, entity_dummies], axis=1)
    
    #Regression FE model with dummies
    fe_ret = sm.OLS(y, x_fe_dum).fit()
    
    
    #Whether or not to get summary from the regression
    if summary == True:
        return  fe_ret.summary()
    else:
        return  fe_ret
#%%
def fe_lin(endog, exog):
    """
    Performs Fixed effect model with linearmodels
    Inputs:
        - endog: dependent variable as a dataframe with multiindex
        - exog: explanatory variable as a dataframe with multiindex
        - dataframe must be a multiindex with entity identifier as first level and time as second level
    Outputs:
        - Fixed effect model (linearmodels PanelOLSResults)
    """
    y = endog
    X = exog
    #add constant
    X = sm.add_constant(X)
    # Estimate fixed effects model
    model = PanelOLS(y, X, entity_effects=True).fit()
    return model

#%%
def randomEffect(depend_var, exog_var, group, data, data_multi):
    """
    Random effects model estimation.

    Inputs:
        - depend_var: Dependent variable in a DataFrame structure.
        - exog_var: Explanatory variable(s) in a DataFrame structure.
        - group: Group variable(s) in a DataFrame structure.
        - data: Pandas DataFrame containing the data.
        - data_multi: Pandas MultiIndex DataFrame containing the data with multiple levels.

    Outputs:
        - re_model: Random effects model (statsmodels.regression.linear_model.OLSResults).
    """
    n = len(group)
    T = 5
    N = n * T
    
    #calculate the number of exog. var.
    k = len(exog_var.columns)+1
    
    #Create dummies for categorical variables
    df_with_dummies =data.copy()
    entity_dummies_ols = pd.get_dummies(data_multi.index.get_level_values('port_id'), drop_first=True, prefix='port').astype(int)
    df_with_dummies = df_with_dummies.join(entity_dummies_ols) 
    
    # Create the formula for the least squares dummy variable regression (lsdv)
    lsdv_expr = 'Return' + ' ~ '
    i = 0
    for x_name in exog_var:
        if i > 0:
            lsdv_expr = lsdv_expr + ' + ' + x_name
        else:
            lsdv_expr = lsdv_expr + x_name
        i = i + 1
    for dummy_name in group[1:]:
        lsdv_expr = lsdv_expr + ' + ' + dummy_name
        
    #fit the lsdv
    lsdv_model = smf.ols(formula=lsdv_expr, data=df_with_dummies)
    lsdv_results = lsdv_model.fit()
    
    #setup to calculate theta: Wooldridge p. 470, verbeek p 348
    #sigma-square-epsilon (error variance)
    sigma2_epsilon = lsdv_results.ssr/(n*T-(n+k+1))

    #sigma-square-pols (varianve of pols)
    sigma2_pols = sm.OLS(endog=depend_var, exog=exog_var).fit().ssr/(n*T-(k+1))
    # sigma-square-u (varianve of random effects)
    sigma2_u = sigma2_pols - sigma2_epsilon
    #Calculate theta (scalar, proportion of variance attributed to the random effects))
    theta = 1 - math.sqrt(sigma2_epsilon/(sigma2_epsilon + T*sigma2_u))

    #mean for group-specific
    df_eco_copy_means = data.groupby('port_id').mean()

    df_eco_copy_means['const'] = 1.0
    
    # print(df_eco_copy_means)
    
    
    #  Quasi-demean the data by subtracting the theta group-specific means
    pols_y = pd.concat([data['port_id'], depend_var], axis=1)
    pols_X = pd.concat([data['port_id'], exog_var], axis=1)

    # For x
    group_name = ''
    for row_i, row in pols_X.iterrows():
        for column_name, column_value in row.items():
            #if column is group then extract group name and value
            if column_name == 'port_id':
                group_name = pols_X.at[row_i, column_name]
            else:
                #else calculate the mean of group and updte value by subtrating theta
                pols_X_group_mean = df_eco_copy_means.loc[group_name][column_name]
                pols_X.at[row_i, column_name] = pols_X.at[
                    row_i, column_name] - theta*pols_X_group_mean
                
    #for y
    for row_index, row in pols_y.iterrows():
        for column_name, column_value in row.items():
             #if column is group then extract group name and value
            if column_name == 'port_id':
                unit_name = pols_y.at[row_index, column_name]
            else:
                #else calculate the mean of group and updte value by subtrating theta
                pols_y_group_mean = df_eco_copy_means.loc[unit_name][column_name]
                pols_y.at[row_index, column_name] = pols_y.at[
                    row_index, column_name] - theta*pols_y_group_mean
    # Prepare the quasi-demeaned data for the model
    y_re=pols_y[list(pols_y.columns[1:])]
    x_re=pols_X[list(pols_X.columns[1:])]
    x_re= sm.add_constant(x_re)
    #Build and train the model
    re_model = sm.OLS(endog=y_re, exog=x_re).fit()
    
    
    return re_model
    