import numpy as np
def var_portfolio(weights,covar_matrix):
  # Compute portfolio variance using matrix multiplication
  empty_list = []
  for i in weights:
    # We use the variance of a portfolio formula:
    empty_list.append(i@covar_matrix@i.T)
  return np.array(empty_list)
