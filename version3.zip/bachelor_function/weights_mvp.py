def mvp_weights(a, b, c, d, inv_cov, vec_ones, mean_return, exp_return_1, exp_return_2):
    g = 1/d*(b*inv_cov@vec_ones - a*inv_cov@mean_return)
    h = 1/d*(c*inv_cov@mean_return - a*inv_cov@vec_ones)
    weight_1 = g + h * exp_return_1
    weight_2 = g + h * exp_return_2
    return weight_1, weight_2


