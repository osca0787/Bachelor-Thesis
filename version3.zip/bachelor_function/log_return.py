import pandas as pd
import numpy as np

def log_returns(stocks):
    return np.log(stocks / stocks.shift(axis=1))