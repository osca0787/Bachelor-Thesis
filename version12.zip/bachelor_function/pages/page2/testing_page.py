import dash
from dash import dcc, html
import sys
import plotly.graph_objs as go
import pandas as pd
sys.path.insert(0, r'/Users/oscaraugustinus/Desktop/bachelor_function/pages')


dash.register_page(__name__, name='Other Data')

layout = html.Div(
    [
        dcc.Markdown('# This will be the content of Page 3 and much more!'),
        
    ]
)



