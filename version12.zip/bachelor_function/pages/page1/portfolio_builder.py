import sys

sys.path.insert(0, r'/Users/oscaraugustinus/Desktop/bachelor_function')

import dash
from dash import callback
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Output, Input, State
import plotly.graph_objs as go
import pandas as pd
from filter_sp500_stocks import filter_esg_stocks
import dash_bootstrap_components as dbc
import plotly.subplots as sp
from portfolio_analysis import calculate_fundemental_functions
import plotly.express as px

logarithmic_return = pd.DataFrame([])


dataframe = pd.read_excel('data_norm.xlsx', header=[0, 1], index_col=0)


# Initialize the Dash app
app = dash.register_page(__name__, path='/', name='Build Your Portfolio') # '/' indicates that this is the homepage

# Defining the layout of the app
layout = html.Div(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        # Defining the ESG threshold widget, such that the user can filter stocks based on an ESG threshold
                        html.H3('ESG Threshold:'),
                        html.Div(id='esg-threshold-value', className="mb-3"),
                        dcc.Slider(
                            id='esg-threshold-slider',
                            className="mb-4",
                            min=dataframe['ESG']['ESG Score'].min(),
                            max=dataframe['ESG']['ESG Score'].max(),
                            step=0.1,
                            value=dataframe['ESG']['ESG Score'].min(),
                            marks={dataframe['ESG']['ESG Score'].min(): str(dataframe['ESG']['ESG Score'].min()),
                                   dataframe['ESG']['ESG Score'].max(): str(dataframe['ESG']['ESG Score'].max())}
                        )
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center'
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        dcc.Dropdown(
                            # Creating the dropdown menu, from which the user can choose between stocks to add to a portfolio
                            id='stock-dropdown',
                            # Looping through each ticker in the dataframe's index to display in the dropdown menu
                            options=[{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()],
                            multi=True,
                            placeholder='Please select stocks for your portfolio'
                        )
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center'
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        html.Button('View Your Portfolio', id='submit-button', n_clicks=0, className="mr-2"),
                        html.Button('Reset Portfolio', id='reset-button', n_clicks=0),
                    ],
                    width=6,
                    className="mt-3"
                )
            ],
            justify='center'
        ),

        dbc.Row(
            [
                dbc.Col(id='portfolio-output', className="mt-4")
            ]
        ),

        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                    dcc.Graph(id='log-return-plot', style={'backgroundColor': 'rgb(28, 32, 47)'}),
                                    width=6
                                ),
                                dbc.Col(
                                    dcc.Graph(id='histogram-plot', style={'backgroundColor': 'rgb(28, 32, 47)'}),
                                    width=6
                                ),
                            ],
                            justify='center'
                        )
                    ]
                )
            ])
    ])


# Callback function to update the dropdown menu options, stock dropdown value, and ESG threshold value
@callback(
    [Output('stock-dropdown', 'options'),
     Output('stock-dropdown', 'value'),
     Output('logarithmic_return', 'children'),
     Output('esg-threshold-value', 'children')],
    [Input('esg-threshold-slider', 'value'),
     Input('reset-button', 'n_clicks')],
    [State('stock-dropdown', 'value')]
)
def update_portfolio(esg_threshold, reset_clicks, selected_stocks):
    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # Code such that as the user changes the value of the ESG threshold, the dropdown menu is updated with stocks that fulfill the threshold
    if trigger_id == 'esg-threshold-slider':
        # Using the filter_esg_stocks function from the filter_sp500_stocks program
        filtered_df = filter_esg_stocks(dataframe, 'ESG', threshold=esg_threshold)
        # Updating stock options on the dropdown menu
        dropdown_options = [{'label': ticker, 'value': ticker} for ticker in filtered_df.index.tolist()]
        return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    elif trigger_id == 'reset-button':
        # Resetting the whole webpage to default settings if the user clicks on the Reset Portfolio button
        if reset_clicks > 0:
            # Reset the dropdown options to include all tickers
            dropdown_options = [{'label': ticker, 'value': ticker} for ticker in dataframe.index.tolist()]

            # Reset the selected stocks value to an empty list
            selected_stocks = []

            # Reset the ESG threshold value to the minimum ESG score
            esg_threshold = dataframe['ESG']['ESG Score'].min()

            return dropdown_options, selected_stocks, f'{esg_threshold:.1f}'

    # If no trigger or invalid trigger, return the initial values
    return dash.no_update, dash.no_update, dash.no_update


@callback(
    [Output('log-return-plot', 'figure'),
     Output('histogram-plot', 'figure')],
    [Input('submit-button', 'n_clicks'),
     Input('reset-button', 'n_clicks')],
    [State('stock-dropdown', 'value')]
)
def update_portfolio_output(submit_clicks, reset_clicks, selected_stocks):


    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

    if trigger_id == 'submit-button':
        if submit_clicks > 0:
            # Create an empty DataFrame to store selected stocks
            portfolio = pd.DataFrame(columns=dataframe.columns)

            # Add selected stocks to the portfolio DataFrame
            for stock in selected_stocks:
                portfolio = pd.concat([portfolio, dataframe.loc[dataframe.index == stock]])

            # Call the first function from the backend file portfolio_analysis
            # This function will calculate all the base metrics and the ESG insensitive investor
            logarithmic_return, esg_np, e_np, s_np, g_np, covariance_matrix, inverse_covariance_matrix, mean_return_of_stocks = calculate_fundemental_functions(portfolio)
            

            

            logarithmic_return.index = pd.to_datetime(logarithmic_return.index)

            # Create a line plot for each ticker
            log_return_fig = go.Figure()

            for column in logarithmic_return.columns:
                log_return_fig.add_trace(go.Scatter(
                    x=logarithmic_return.index,
                    y=logarithmic_return[column],
                    mode='lines',
                    name=column
                ))

            log_return_fig.update_layout(
                            title='Logarithmic Returns',
                            xaxis_title='Date',
                            yaxis_title='Logarithmic Return',
                            legend=dict(orientation="h"),
                            hovermode='x unified',
                            plot_bgcolor='rgb(28, 32, 47)',
                            paper_bgcolor='rgb(28, 32, 47)'
                        )

            # Plot the histogram for ESG Scores
            histogram_fig = px.histogram(portfolio, x=portfolio.index, y=portfolio['ESG']['ESG Score'])
            histogram_fig.update_layout(
                            title='ESG Scores',
                            xaxis_title='Ticker',
                            yaxis_title='ESG Score',
                            showlegend=False,
                            plot_bgcolor='rgb(28, 32, 47)',
                            paper_bgcolor='rgb(28, 32, 47)'
                        )

            return log_return_fig, histogram_fig, logarithmic_return

    elif trigger_id == 'reset-button':
        # Resetting the whole webpage to default settings if the user clicks on the Reset Portfolio button
        if reset_clicks > 0:
            empty_fig = go.Figure(data=[])
            empty_fig.update_layout(
                            legend=dict(orientation="h"),
                            hovermode='x unified',
                            plot_bgcolor='rgb(28, 32, 47)',
                            paper_bgcolor='rgb(28, 32, 47)'
                        )
            return empty_fig, empty_fig
        

    return dash.no_update, dash.no_update