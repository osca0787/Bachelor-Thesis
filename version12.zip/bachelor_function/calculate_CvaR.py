import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import quad

def plot_var_cvar_histogram(returns : pd.DataFrame, weights : np.ndarray, alpha : float, lookback_days : int):
    """Function that computes the Value-At-Risk and Conditional-Value-At-Risk for a portfolio

    Parameters
    ----------
    returns : Pandas Dataframe
        Pandas Dataframe which contains the logarithmic returns of a certain amount of stocks

    weights : Numpy Array
        Numpy Array which contains portfolio weights 

    alpha : float
        float which specifies the confidence interval

    lookback_days : int
        integer which specifies the time-frame, from which the VaR and CVaR considers

    Returns
    -------
    Plot, VaR, CVaR
        Returns a plot of the VaR and CVar with returns. Furthermore, it returns the value of VaR and CVaR
    """

    if not  isinstance(weights, np.ndarray) or not isinstance(returns, pd.DataFrame) or not isinstance(alpha, float) or not isinstance(lookback_days, int):
            raise TypeError("Input must correct data types")
        
    else:

            if weights.size == 0 or returns.empty or lookback_days == 0:
                raise ValueError("One or more of the input parameters are empty")


            else:

                def calculate_var(returns, weights, alpha, lookback_days):
                    #Calculating the portfolio returns for the a certain period
                    portfolio_returns = np.dot(returns.iloc[-lookback_days:].fillna(0.0), weights)
                    #Sorts the returns
                    sorted_returns = np.sort(portfolio_returns)
                    index = int(alpha * len(sorted_returns))
                    #Calculates the Value At risk
                    return -sorted_returns[index]

                def calculate_cvar(returns, weights, alpha, lookback_days):
                    #Defining the integral of the Acerbi CVaR
                    def integrand(u):
                        return calculate_var(returns, weights, u, lookback_days)
                    #Calculates the integral 
                    cvar, _ = quad(integrand, alpha, 1)
                    #The integral is multiplied with the rest of the formula
                    cvar *= 1 / (1 - alpha)
                    #Returning the CVaR
                    return -cvar

                #Calling the functions to plot them
                var = calculate_var(returns, weights, alpha, lookback_days)
                cvar = calculate_cvar(returns, weights, alpha, lookback_days)
                returnss = returns.iloc[-lookback_days:].fillna(0.0).dot(weights)

                plot = plt

                # Plotting the histogram with CVaR and VaR
                plot.hist(returnss[returnss > var], bins=20, label='Returns > VaR')
                plot.hist(returnss[returnss < var], bins=20, color='black', label='Returns < VaR')
                plot.axvline(x=var, color='r', linestyle='dashed', linewidth=1, label=f'VaR for Specified Alpha = {alpha}')
                plot.axvline(x=-cvar, color='r', linestyle='solid', linewidth=1, label=f'CVaR for Specified Alpha = {alpha}')
                plot.xlabel('Returns')
                plot.ylabel('Frequency')
                plot.legend()
                plot.title('Returns Distribution with VaR and CVaR')
                
                return  var, cvar, plot
