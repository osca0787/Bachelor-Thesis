from sklearn.linear_model import LinearRegression
import numpy as np
import pandas as pd

def calculate_treynor(lookback_years : int, port_returns : pd.DataFrame , weights : np.ndarray, benchmark_returns : pd.DataFrame, risk_free_rate : float):
    """Function that calculates alpha, beta and timing of a portfolio

    Parameters
    ----------
    lookback_years : int
        a int which specifies the time frame considered when calculating alpha, beta and timing

    port_returns : Pandas DataFrame
        A DataFrame containing the stocks logarithmic returns
    
    weights : Numpy Array
        the portfolio weights

    benchmark_returns : Pandas DataFrame
        A DataFrame containing the benchmark logarithmic returns (SP500)

    risk_free_rate : float
        a float that refers to the rate of return an investor expects to earn on a zero risk asse


  

    Returns
    ------
        Tuple : float
            Returns the alpha, beta and timing of a portfolio
        """

    if not isinstance(weights, np.ndarray) or not all(isinstance(i, (pd.DataFrame)) for i in (port_returns, benchmark_returns)) or not isinstance(lookback_years, int) or not isinstance(risk_free_rate, float):
            raise TypeError("Input must correct data types")
        
    else:

            if port_returns.empty or weights.size == 0 or benchmark_returns.empty:
                raise ValueError("One or more of the input parameters are empty")


            else:

                #Define the regression
                reg = LinearRegression()

                #First we find the portfolios return during x years
                portfolio_returns = port_returns.iloc[-lookback_years:].dot(weights)
                
                #Transform the portfolio returns to a numpy array
                np_portfolio_returns = np.array(portfolio_returns)

                #The dependent variable
                Y = np_portfolio_returns.reshape(-1,1) - risk_free_rate

                #Calulating the returns for the benchmark index during x years
                benchmark = benchmark_returns.to_numpy()
                X = benchmark[-lookback_years:].reshape(-1,1) - risk_free_rate


                #Calculating X squared, which is used to calculate timing
                X_square = X**2

                #Now we need to stack X and X_square
                stacked = np.hstack((X, X_square))

                #Compile the regression
                reg.fit(stacked, Y)

                return reg.intercept_[0], reg.coef_[0,0], reg.coef_[0,1]