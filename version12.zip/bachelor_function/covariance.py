import pandas as pd
import numpy as np
from sklearn.covariance import LedoitWolf

def cov_matrix(stocks : pd.DataFrame):
    """Function that computes the covariance-variance matrix

    Parameters
    ----------
    Stocks : float
        Pandas Dataframe which contains the logarithmic returns of a certain amount of stocks
    

    Returns
    -------
    Pandas Dataframe
        a Dataframe of the covariance-variance each selected stock
    """

    if not isinstance(stocks, pd.DataFrame) :
            raise TypeError("Input must be a Pandas Dataframe")
        
    else:

            if stocks.empty:
                raise ValueError("One or more of the input parameters are empty")


            else:


                # Assuming your data is stored in a numpy array called `data`
                # Instantiate the LedoitWolf estimator
                lw = LedoitWolf()

                # Fit the estimator to the data and get the shrinkage estimate of the covariance matrix
                cov_shrink = lw.fit(stocks).covariance_


                return cov_shrink