from scipy.optimize import minimize
import numpy as np
from joblib import Parallel, delayed
from expected_return import exp_return
from variance import var_portfolio
from volatility import volatility

def calculate_esg_sensitive_investor(mean_return : np.ndarray, cov_var : np.ndarray, esg_scores : np.ndarray, esg_threshold : float , target_returns : list, guess : np.ndarray):
    """Function that calculates the optimal portfolios for the ESG sensitive investor and calculates its weights, Expected return, volatility and ESG, E, S and G scores

    Parameters
    ----------
  
    mean_return : Numpy Array
        Numpy array of mean returns for each stock

    cov_var : Numpy Array
        Covariance-variance matrix for the stocks

    esg_score : Numpy Array
        an array consiting of each stocks ESG score

    esg_threshold : float
        a float, which represents the ESG threshold the investor desires

    target_return : list
        a list with the desired expected returns for the ESG efficient frontier

    guess : Numpy Array
        an array consiting of portfolio weights, that serves as a intial guess


    Returns
    ------
        Tuple : Tuple
            Returns the optimal portfolios of the ESG sensitive investor, its weights, expected return, volatility and WA ESG score.
        """    

    if not  all(isinstance(i, (np.ndarray)) for i in (mean_return, cov_var, esg_scores, guess)) or not isinstance(target_returns, list) or not isinstance(esg_threshold, float):
            raise TypeError("Input must correct data types")
        
    else:

            if mean_return.size == 0 or cov_var.size == 0 or mean_return.size == 0 or esg_scores.size == 0 or guess.size == 0 or len(target_returns) == 0:
                raise ValueError("One or more of the input parameters are empty")


            else:

                #Defining the ESG constraint
                def esg_constraint(x):
                    esg_product = np.dot(x, esg_scores)
                    return esg_product - esg_threshold


                weight_list = []

                # Define a function to be executed in parallel
                def optimize_portfolio(target_return):
                    #Objective function
                    obj_func = lambda x: np.sqrt(np.dot(x.T, np.dot(cov_var, x)))
                    #The constraints for the ESG sensitive investor
                    constraints = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1},
                                {'type': 'ineq', 'fun': lambda x: np.dot(mean_return, x) - target_return - 0.0001},
                                {'type': 'ineq', 'fun': lambda x: target_return + 0.0001 - np.dot(mean_return, x)},
                                {'type': 'ineq', 'fun': esg_constraint}]

                    #Calculating the optimal weights for the ESG sensitive investor
                    result = minimize(obj_func, x0=guess, method='SLSQP', options={'disp': False, 'maxiter' : 1000}, constraints=constraints)
                    #if np.sum(res1.x) > 0.997 and np.sum(res1.x) < 1.01:
                    #   weight_list.append(res1.x)
                    if np.sum(result.x) > 0.997 and np.sum(result.x) < 1.01:
                        return result.x

                # Using Parallel() function to speed up the process of finding the optimal weights
                n_jobs = -1  # Use all available CPU cores
                results = Parallel(n_jobs=n_jobs)(delayed(optimize_portfolio)(target_return) for target_return in target_returns)

                # Filter out any portfolios with zero weights
                weight_list = [r for r in results if np.sum(r) > 0.997 and np.sum(r) < 1.01]
                weight_list = np.array(weight_list)


                #Calculate the optimal portfolios expected return and volatility
                esg_portfolio_returns = exp_return(weight_list, mean_return)
                esg_portfolio_var = var_portfolio(weight_list, cov_var)
                esg_portfolio_vol = volatility(esg_portfolio_var)


                #Calculate the weighted average esg score for the optimal portfolios
                esg_investor_wa = weight_list@esg_scores

                return weight_list, esg_portfolio_returns, esg_portfolio_vol, esg_investor_wa