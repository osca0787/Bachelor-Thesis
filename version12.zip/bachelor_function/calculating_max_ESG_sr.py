import numpy as np
from scipy.optimize import minimize

def calculate_max_ESG_sharpe_ratio(risk_free_rate : float, mean_return : np.ndarray, cov_var : np.ndarray , esg_score : np.ndarray, e_score : np.ndarray, s_score : np.ndarray, g_score : np.ndarray, guess : np.ndarray, labels : list, esg_threshold : float):
    """Function that calculates the optimal ESG Sharpe Ratio and calculates its weights, Expected return, volatility and ESG, E, S and G scores

    Parameters
    ----------
    risk_free_rate : float
        a float that refers to the rate of return an investor expects to earn on a zero risk asset    
  
    mean_return : Numpy Array
        Numpy array of mean returns for each stock

    cov_var : Numpy Array
        Covariance-variance matrix for the stocks

    esg_score : Numpy Array
        an array consiting of each stocks ESG score

    e_score : Numpy Array
        an array consiting of each stocks E score

    s_score : Numpy Array
        an array consiting of each stocks S score

    g_score : Numpy Array
        an array consiting of each stocks G score
    
    guess : Numpy Array
        an array consiting of portfolio weights, that serves as a intial guess

    labels : Numpy Array
        used to set the bounds fot each weight in the portfolio

    esg_threshold : float
        A float, which defines the constraint the ESG Sharpe Ratio has to fulfill 


  

    Returns
    ------
        Tuple : Tuple
            Returns the Max ESG SR, its weights, expected return, volatility and WA ESG, E, S and G score.
        """

    if not  all(isinstance(i, (np.ndarray)) for i in (mean_return, cov_var, esg_score, e_score, s_score, g_score, guess)) or not isinstance(labels, list) or not isinstance(risk_free_rate, float) or not isinstance(esg_threshold, float):
            raise TypeError("Input must correct data types")
        
    else:

            if mean_return.size == 0 or cov_var.size == 0 or mean_return.size == 0 or esg_score.size == 0 or e_score.size == 0 or s_score.size == 0 or g_score.size == 0 or len(labels) == 0:
                raise ValueError("One or more of the input parameters are empty")


            else:
                
                #Helper function used as a constraint
                def checkSumToOne(w):
                    return np.sum(w)-1

                #We use a minimizer so we create this function to find the negative sharpe ratio
                def negativeSR(w):
                    w = np.array(w)
                    V = np.sqrt(w.T @ cov_var @ w)
                    R = np.sum(mean_return * w)
                    SR = R /V
                    return -1*SR
                
                #Defining a function for the ESG constraint
                def esg_constraint(x):
                    esg_product = np.dot(x, esg_score)
                    return esg_product - esg_threshold

                #Setting bounds for the weights - shorting is allowed
                constraintSet = (-1,1)
                bounds = tuple(constraintSet for asset in range(len(labels)))



                #Defining a list of constraints
                constraints_esg = [{'type':'eq', 'fun':checkSumToOne},
                                {'type': 'ineq', 'fun': esg_constraint}]
                obj_func = lambda x: negativeSR(x)
                #Minimizing the negative sharpe ratio
                w_opt_esg = minimize(negativeSR, guess, method='SLSQP', bounds=bounds, constraints=constraints_esg).x

                #Calculating the expected return and volatility of the Optimal Sharpe Ratio
                sharpe_exp_esg = w_opt_esg@mean_return
                sharpe_vol_esg = np.sqrt(w_opt_esg.T@cov_var@w_opt_esg)


                #Calculating the weighted average ESG score of the portfolio
                sr_esg_esg_score = np.dot(w_opt_esg, esg_score)
                sr_esg_e_score = np.dot(w_opt_esg, e_score)
                sr_esg_s_score = np.dot(w_opt_esg, s_score)
                sr_esg_g_score = np.dot(w_opt_esg, g_score)
                
                #Calculating the optimal Sharpe Ratio
                sr_esg = (sharpe_exp_esg - risk_free_rate) / sharpe_vol_esg



                return sr_esg, w_opt_esg, sharpe_exp_esg, sharpe_vol_esg, sr_esg_esg_score, sr_esg_e_score, sr_esg_s_score, sr_esg_g_score