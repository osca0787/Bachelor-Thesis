import pandas as pd
import numpy as np
import plotly
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import plotly.figure_factory as ff
from plotly.subplots import make_subplots

def ef_plot(tickers_list, sr_t_list, 
            ef_weights, vol, r, esg_wa, 
            esg_investor_weights, esg_portfolio_vol, esg_portfolio_returns, esg_investor_wa, 
            w_sr, vol_sr, sr_er, optimal_sharpe_ratio, sr_score,
            w_sr_esg, vol_sr_esg, sr_er_esg, optimal_sharpe_ratio_esg, sr_esg_score,
            mvp_weights, mvp_vol, mvp_er, mvp_esg_score, 
            w_sortino, vol_sortino, er_sortino, optimal_sortino_ratio, sortino_score,
            w_sortino_esg, vol_sortino_esg, er_sortino_esg, optimal_sortino_ratio_esg, sortino_score_esg,
            ratio=None):


    weights_str_sr = [f'{w*100:.2f}%' for w in w_sr]
    weights_text_sr = ', '.join(weights_str_sr)


    weights_str_sr_esg = [f'{w*100:.2f}%' for w in w_sr_esg]
    weights_text_sr_esg = ', '.join(weights_str_sr_esg)

    #SORTINO
    weights_str_sortino = [f'{w*100:.2f}%' for w in w_sortino]
    weights_text_sortino = ', '.join(weights_str_sortino)


    weights_str_sortino_esg = [f'{w*100:.2f}%' for w in w_sortino_esg]
    weights_text_sortino_esg = ', '.join(weights_str_sortino_esg)

    weights_str_mvp = [f'{w*100:.2f}%' for w in mvp_weights]
    weights_text_mvp = ', '.join(weights_str_sr)


    # Plot efficient frontier with custom tooltip
    fig = go.Figure()


    fig.add_trace(go.Scatter(
        x=vol,
        y=r,
        mode='lines',
        name = 'Efficient Frontier',
        text=[f'Weights: {", ".join([f"(Ticker: {ticker}, Weight: {w*100:.2f}%)" for ticker, w in zip(tickers, wts)])}<br>' +
            f'Volatility: {vol:.4%}<br>' +
            f'Return: {ret:.4%}<br>' +
            f'WA ESG Score: {esg:.4f}'
            for tickers, wts, vol, ret, esg in zip(tickers_list*len(ef_weights), ef_weights, vol, r, esg_wa)],
        hovertemplate='%{text}',
        hoverlabel=dict(
            font_size=8.3  # Set font size to 10
        )
    ))



    fig.add_trace(go.Scatter(
        x=esg_portfolio_vol,
        y=esg_portfolio_returns,
        mode='lines',
        name='ESG Efficient Frontier',
        text=[f'Weights: {", ".join([f"(Ticker: {ticker}, Weight: {w_esg*100:.2f}%)" for ticker, w_esg in zip(tickers, wts_esg)])}<br>' +
            f'Volatility: {vol_esg:.4%}<br>' +
            f'Return: {ret_esg:.4%}<br>' +
            f'WA ESG Score: {esg_score:.4f}'
            for tickers, wts_esg, vol_esg, ret_esg, esg_score in zip(tickers_list*len(esg_investor_weights), esg_investor_weights, esg_portfolio_vol, esg_portfolio_returns, esg_investor_wa)],
        hovertemplate='%{text}',
        hoverlabel=dict(
            font_size=8.3  # Set font size to 10
        )
        
    ))


    if ratio == 'Sharpe Ratio':

        fig.add_trace(go.Scatter(x = [vol_sr_esg], y = [sr_er_esg],
                            marker=dict(color='green', size=12), 
                            mode='markers',
                            name='ESG SR',
                            #text=['SR'],
                            text=[f'Tickers: {",".join(sr_t_list)}<br>' +
                            f'Weights: {weights_text_sr_esg}<br>' +
                            f'Volatility: {vol_sr_esg:.4%}<br>' +
                            f'Return: {sr_er_esg:.4%} <br>' +
                            f'Sharpe Ratio: {optimal_sharpe_ratio_esg:.4} <br>' +
                            f'WA ESG score: {sr_esg_score}'],
                            hovertemplate='%{text}',
                            hoverlabel=dict(
            font_size=8.3  # Set font size to 10
            )
        ))

        fig.add_trace(go.Scatter(x = [vol_sr], y = [sr_er],
                            marker=dict(color='white', size=12), 
                            mode='markers',
                            name='SR',
                            #text=['SR'],
                            text=[f'Tickers: {",".join(sr_t_list)}<br>' +
                            f'Weights: {weights_text_sr}<br>' +
                            f'Volatility: {vol_sr:.4%}<br>' +
                            f'Return: {sr_er:.4%} <br>' +
                            f'Sharpe Ratio: {optimal_sharpe_ratio:.4}<br>' +
                            f'WA ESG score: {sr_score}'],
                            hovertemplate='%{text}',
                            hoverlabel=dict(
            font_size=8.3  # Set font size to 10
            )
        ))

    elif ratio == 'Sortino Ratio':
        fig.add_trace(go.Scatter(x = [vol_sortino_esg], y = [er_sortino_esg],
                            marker=dict(color='green', size=12), 
                            mode='markers',
                            name='ESG Sortino Ratio',
                            #text=['SR'],
                            text=[f'Tickers: {",".join(sr_t_list)}<br>' +
                            f'Weights: {weights_text_sortino_esg}<br>' +
                            f'Volatility: {vol_sortino_esg:.4%}<br>' +
                            f'Return: {er_sortino_esg:.4%} <br>' +
                            f'Sortino Ratio: {optimal_sortino_ratio_esg:.4} <br>' +
                            f'WA ESG score: {sortino_score_esg}'],
                            hovertemplate='%{text}',
                            hoverlabel=dict(
            font_size=8.3  # Set font size to 10
            )
        ))

        fig.add_trace(go.Scatter(x = [vol_sortino], y = [er_sortino],
                            marker=dict(color='white', size=12), 
                            mode='markers',
                            name='Sortino Ratio',
                            #text=['SR'],
                            text=[f'Tickers: {",".join(sr_t_list)}<br>' +
                            f'Weights: {weights_text_sortino}<br>' +
                            f'Volatility: {vol_sortino:.4%}<br>' +
                            f'Return: {er_sortino:.4%} <br>' +
                            f'Sortino Ratio: {optimal_sortino_ratio:.4}<br>' +
                            f'WA ESG score: {sortino_score}'],
                            hovertemplate='%{text}',
                            hoverlabel=dict(
            font_size=8.3  # Set font size to 10
            )
            ))
    else:
        raise ValueError("Invalid score type. PLease choose to plot either Sharpe or Sortino Ratio")

    fig.add_trace(go.Scatter(x = [mvp_vol], y = [mvp_er],
                            marker=dict(color='grey', size=12), 
                            mode='markers',
                            name='MVP',
                            #text=['SR'],
                            text=[f'Tickers: {",".join(sr_t_list)}<br>' +
                            f'Weights: {weights_text_mvp}<br>' +
                            f'Volatility: {mvp_vol:.4%}<br>' +
                            f'Return: {mvp_er:.4%}<br>' +
                            f'WA ESG Score: {mvp_esg_score}'],
                            hovertemplate='%{text}', hoverlabel=dict(
            font_size=8.3  # Set font size to 10
        )
    ))


    fig.update_layout(legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1    
        ))


    # Update layout
    fig.update_layout(
        template='plotly_dark',
        title='Efficient Frontier',
        xaxis_title='Volatility',
        yaxis_title='Return',
        hovermode='closest',
        width=1000,
        height=600,
        margin=dict(l=50, r=50, b=50, t=50, pad=4)
    )

    return fig