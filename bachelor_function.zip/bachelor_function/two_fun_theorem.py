import numpy as np
def w3(weight1,weight2,alpha):
  weight3 = []
  for i in alpha:
    weight3.append(i*weight1 + (1-i)*weight2)
  return np.array(weight3)