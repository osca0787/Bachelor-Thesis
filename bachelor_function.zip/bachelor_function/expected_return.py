import numpy as np
def exp_return(w, R):
  emp_list = sum(w.T*R)
  return np.array(emp_list)
